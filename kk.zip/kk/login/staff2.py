#بِسْمِ اللهِ الرَّحْمنِ الرَّحِيمِ
# Type : SelfBot # Maker : Khie # Support : Rhyn , Rio , Mat, Agz# Remake from : Helloworld & Anbots # Ver : 9.1 # N̴̳̰̓ͬ͡ǫ̷̅̏̚ͅỗ͍̟̏͡b̴͙͙ͮ͢͜C̛͈̿ͥͣ͠ơ̡͑̈́ͩ͜d̼ͯ͋͌ͬ͡e̢̢̝̞̯̅ŗ̞̺̈̾̽ # NOT FOR SALE
from linepy  import *
#from help import *
from liff.ttypes import LiffChatContext, LiffContext, LiffSquareChatContext, LiffNoneContext, LiffViewRequest
from akad.ttypes import Message
from akad.ttypes import ContentType as Type
from akad.ttypes import TalkException
from datetime import datetime, timedelta
from time import sleep
from bs4 import BeautifulSoup as bSoup
from bs4 import BeautifulSoup
from humanfriendly import format_timespan, format_size, format_number, format_length
from gtts import gTTS
from threading import Thread
from io import StringIO
from multiprocessing import Pool
from googletrans import Translator
from urllib.parse import urlencode
from wikiapi import WikiApi
from tmp.MySplit import *
from tmp.Instagram import InstagramScraper
from py_translator import TEXTLIB
from zalgo import zalgoname
from random import randint
from shutil import copyfile
from youtube_dl import YoutubeDL
from instagram import Instagram
from Naked.toolshed.shell import execute_js
import subprocess, youtube_dl, humanize, traceback
import subprocess as cmd
import platform
import requests, json
import time, random, sys, json, null, pafy, codecs, html5lib ,shutil ,threading, glob, re, base64, string, os, requests, six, ast, pytz, wikipedia, urllib, urllib.parse, atexit, asyncio, traceback
_session = requests.session()
try:
    import urllib.request as urllib2
except ImportError:
    import urllib2
#=====================================================================
#=====================================================================
with open("token1.txt","r") as z:
    token = z.read()
noobcoder = LINE(token,appName="IOSIPAD\t11.2.5\tiPhone X\t11.2.5")
Channel(noobcoder, "1643727178").getChannelResult().channelAccessToken
waitOpen = codecs.open("khie/wait.json","r","utf-8")
settingsOpen = codecs.open("khie/temp.json","r","utf-8")
imagesOpen = codecs.open("khie/image.json","r","utf-8")
stickersOpen = codecs.open("khie/sticker.json","r","utf-8")
seensOpen = codecs.open("khie/lastseen.json","r","utf-8")
contactOpen = codecs.open("khie/contact.json","r","utf-8")
stickers1Open = codecs.open("khie/sticker1.json","r","utf-8")
stickers2Open = codecs.open("khie/sticker2.json","r","utf-8")
anumuOpen = codecs.open("khie/stickertemp.json","r","utf-8")
blockInviteOpen = codecs.open("khie/blockinvite.json","r","utf-8")
protectKickOpen = codecs.open("khie/protectkick.json","r","utf-8")
groupNameOpen = codecs.open("khie/groupname.json","r","utf-8")
groupQrOpen = codecs.open("khie/groupqr.json","r","utf-8")
textaddOpen = codecs.open("khie/text.json","r","utf-8")
notagOpen = codecs.open("khie/notag.json","r","utf-8")
noobcoderProfile = noobcoder.getProfile()
noobcoderSettings = noobcoder.getSettings()
noobcoderPoll = OEPoll(noobcoder)
noobcoderStart = time.time()
noobcoderMID = noobcoder.getProfile().mid
loop = asyncio.get_event_loop()
myAdmin = ["u2cf74acf6ed04d122def4db8ffdd2e39","u8c31fa0e60d1eee2558ee7c634614e67","ubdd00548b45a7bd26c43036e4d92dffa","u6e882277271440a7c2e8a2a0a5c38cef","u500218bb2f290d906bc4cb3fe4c9173a"]
botStart = time.time()
msg_image={}
msg_video={}
msg_sticker={}
msgdikirim = {}
msgditerima = {}
unsendchat = {}
msg_dict = {}
temp_flood = {}
groupName = {}
groupImage = {}
kuciyose = {}
wbanlist = []
wcimage = False
wait = json.load(waitOpen)
settings = json.load(settingsOpen)
images = json.load(imagesOpen)
stickers = json.load(stickersOpen)
seens = json.load(seensOpen)
contacts = json.load(contactOpen)
stickers1 = json.load(stickers1Open)
stickers2 = json.load(stickers2Open)
anumu = json.load(anumuOpen)
blockInvite = json.load(blockInviteOpen)
protectKick = json.load(protectKickOpen)
groupName = json.load(groupNameOpen)
groupQr = json.load(groupQrOpen)
textsadd = json.load(textaddOpen)
notag = json.load(notagOpen)
mulai = time.time()

# BERANTAKAN

undang = {
    "invite": False,
}

mcroom = {
    "leaveMC": False,
}

blocked = {
    "autoBlock": False,
    "pesanya": "「 AutoBlock 」\nSorry, I use Auto block ^^",
}

wmin = {
    "wMessage": False,
    "textnya": "Enjoying in this group",
}
lvin = {
    "lMessage": False,
    "textnya": "See u next time",
}

mimikin = {
    "mimic": {
        "copy": False,
        "status": False,
        "target": {
            "ub4974c6489c969402713a974b568ee9e": True
        }
    },
}

liffnya = {
        "ttt": "line://app/1643727178-0XPGAaRX?type=fotext&text=",
}

temp = {"te": "#890200","t": "#000000"}

komen = {
    "komenan": False,
}

kimak= {
    "Addaudio": False,
    "Audio": {},
    "Audios": {
     },
}

ciel = {
    "addText": {
        "statustext": True,
        "texts": "addtext adw"
        },
}

nissa = {
    "addTikel2": {
        "name": "",
        "status": False
        },
}

anyun = {
    "addTikel": {
        "name": "",
        "status": False
        },
}

chatbot = {
    "admin": [],
    "botMute": [],
    "botOff": [],
    "message": {}
}

peler = { 
    "receivercount": 0,
    "sendcount": 0
}

read = { 
    "readMember": {},
    "readPoint": {}
}

hoho = {
    "savefile": False,
    "namefile": "",
}

temptag = {
    "stealtag": False,
    "pesanya": "What's wrong , i'm busy right now",
}

wuts = {
    "wut": False,
}

tailah = {
    "siderTemp": {},
    "siderPesan": "You can join chat?",
}

apalo = {
    "Talkblacklist": {},
    "Talkwblacklist": False,
    "Talkdblacklist": False,
    "talkban": True,
}

sniffin = {
        "sniff": [],
}

tikelin = {
        "stikernya": [],
}

likers = {
    "autoLike": {
        "comment": "Hi @ This is AutoLike",
        "status": False,
    },
}

gwcool = {
    "squad": "NOOB CODER™",
}

setbot = { 
    "background": "#000000",
    "text": "#ffffff",
    "separator": "#ffffff",
    "helptext": "#00FFFF",
    "helpseparator": "#00FFFF"
}

sets = {
    "tagsticker": False,
    "addStickerz": {
        "name": "",
        "status": False,
    },
    "messageStickerz": {
        "addNamez": "",
        "addStatusz": False,
        "listStickerz": {
            "responSticker": {
                "STKID": "",
                "STKPKGID": "",
                "STKVER": ""
            },
        }
    },
}

periksa = {
    "welcomeimage": {},
}
#=====================================================================
settings["myProfile"]["displayName"] = noobcoderProfile.displayName
settings["myProfile"]["statusMessage"] = noobcoderProfile.statusMessage
settings["myProfile"]["pictureStatus"] = noobcoderProfile.pictureStatus
cont = noobcoder.getContact(noobcoderMID)
settings["myProfile"]["videoProfile"] = cont.videoProfile
coverId = noobcoder.getProfileDetail()["result"]["objectId"]
settings["myProfile"]["coverId"] = coverId
#=====================================================================
with open("khie/temp.json", "r", encoding="utf_8_sig") as f:
    anu = json.loads(f.read())
    anu.update(settings)
    settings = anu
with open("khie/wait.json", "r", encoding="utf_8_sig") as f:
    itu = json.loads(f.read())
    itu.update(wait)
    wait = itu

#=====================================================================
def delBlocklist(tar="all"):
    try:
        global blockInvite
        if tar == "all":
            blockInvite = []
        else:
            blockInvite.remove(blockInvite[int(tar) - 1])
    except Exception as error:
        logError(error)
def delNotelist(tar="all"):
    try:
        global notegroup
        if tar == "all":
            notegroup = []
        else:
            notegroup.remove(notegroup[int(tar) - 1])
    except Exception as error:
        logError(error)
def delGnamelist(tar="all"):
    try:
        global groupName
        if tar == "all":
            groupName = []
        else:
            groupName.remove(groupName[int(tar) - 1])
    except Exception as error:
        logError(error)
def delQrlist(tar="all"):
    try:
        global groupQr
        if tar == "all":
            groupQr = []
        else:
            groupQr.remove(groupQr[int(tar) - 1])
    except Exception as error:
        logError(error)
def delKicklist(tar="all"):
    try:
        global protectKick
        if tar == "all":
            protectKick = []
        else:
            protectKick.remove(protectKick[int(tar) - 1])
    except Exception as error:
        logError(error)
def delNotelist(tar="all"):
    try:
        global notegroup
        if tar == "all":
            notegroup = []
        else:
            notegroup.remove(notegroup[int(tar) - 1])
    except Exception as error:
        logError(error)
def delNotaglist(tar="all"):
    try:
        global notag
        if tar == "all":
            notag = []
        else:
            notag.remove(notag[int(tar) - 1])
    except Exception as error:
        logError(error)
#=====================================================================
def support(to):
    data={"type":"flex","altText":"NOOB CODER™","contents":{
  "type": "carousel",
  "contents": [
    {
  "type": "bubble",
  "body": {
    "type": "box",
    "layout": "vertical",
    "contents": [
      {
        "type": "box",
        "layout": "vertical",
        "contents": [
          {
            "type": "spacer"
          },
          {
            "type": "box",
            "layout": "baseline",
            "contents": [
              {
                "type": "icon",
                "url": "https://i.ibb.co/zHkYgV7/left.png",
                "offsetStart": "10px"
              },
              {
                "type": "text",
                "color": "#Ffffff",
                "text": "Friend search",
                "size": "md",
                "offsetStart": "20px"
              }
            ],
            "margin": "md"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "spacer",
                "size": "lg"
              }
            ]
          }
        ],
        "backgroundColor": "#464F69"
      },
      {
        "type": "box",
        "layout": "vertical",
        "contents": [
          {
            "type": "spacer",
            "size": "xxl"
          },
          {
            "type": "box",
            "layout": "horizontal",
            "contents": [
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "text",
                    "text": "."
                  }
                ],
                "offsetStart": "10px",
                "cornerRadius": "xl",
                "borderColor": "#adb5bd",
                "borderWidth": "6px",
                "width": "20px",
                "height": "20px"
              },
              {
                "type": "text",
                "text": "ID",
                "offsetStart": "18px"
              },
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "text",
                    "text": "."
                  }
                ],
                "width": "20px",
                "height": "20px",
                "cornerRadius": "xl",
                "borderWidth": "6px",
                "backgroundColor": "#adb5bd",
                "offsetEnd": "85px"
              },
              {
                "type": "text",
                "text": "Phone number",
                "offsetEnd": "75px"
              }
            ]
          },
          {
            "type": "spacer"
          }
        ]
      },
      {
        "type": "box",
        "layout": "horizontal",
        "contents": [
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "justanolep",
                "offsetStart": "10px",
                "size": "sm"
              }
            ],
            "borderColor": "#adb5bd",
            "borderWidth": "1px",
            "offsetStart": "10px"
          },
          {
            "type": "spacer",
            "size": "xxl"
          }
        ]
      },
      {
        "type": "box",
        "layout": "vertical",
        "contents": [
          {
            "type": "filler"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "url": "https://obs.line-scdn.net/{}".format(noobcoder.getContact('u6e882277271440a7c2e8a2a0a5c38cef').pictureStatus),
                "aspectMode": "cover",
                "size": "full"
              }
            ],
            "margin": "xxl",
            "cornerRadius": "100px",
            "height": "72px",
            "width": "72px",
            "offsetStart": "110px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "{}".format(noobcoder.getContact('u6e882277271440a7c2e8a2a0a5c38cef').displayName),
                "size": "md",
                "color": "#000000",
                "weight": "bold",
                "align": "center"
              },
              {
                "type": "box",
                "layout": "horizontal",
                "contents": [
                  {
                    "type": "filler"
                  },
                  {
                    "type": "box",
                    "layout": "vertical",
                    "contents": [
                      {
                        "type": "text",
                        "text": "Add Friend",
                        "size": "sm",
                        "color": "#Ffffff",
                        "align": "center"
                      }
                    ],
                    "borderWidth": "1px",
                    "backgroundColor": "#008000",
                    "action": {
                      "type": "uri",
                      "label": "action",
                      "uri": "http://line.me/ti/p/~justanolep"
                    }
                  },
                  {
                    "type": "filler"
                  }
                ],
                "margin": "md"
              }
            ],
            "margin": "md"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "spacer",
                "size": "xxl"
              }
            ],
            "margin": "xxl"
          }
        ],
        "margin": "xxl"
      }
    ],
    "paddingAll": "0px"
  }
},{
  "type": "bubble",
  "body": {
    "type": "box",
    "layout": "vertical",
    "contents": [
      {
        "type": "box",
        "layout": "vertical",
        "contents": [
          {
            "type": "spacer"
          },
          {
            "type": "box",
            "layout": "baseline",
            "contents": [
              {
                "type": "icon",
                "url": "https://i.ibb.co/zHkYgV7/left.png",
                "offsetStart": "10px"
              },
              {
                "type": "text",
                "color": "#Ffffff",
                "text": "Friend search",
                "size": "md",
                "offsetStart": "20px"
              }
            ],
            "margin": "md"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "spacer",
                "size": "lg"
              }
            ]
          }
        ],
        "backgroundColor": "#464F69"
      },
      {
        "type": "box",
        "layout": "vertical",
        "contents": [
          {
            "type": "spacer",
            "size": "xxl"
          },
          {
            "type": "box",
            "layout": "horizontal",
            "contents": [
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "text",
                    "text": "."
                  }
                ],
                "offsetStart": "10px",
                "cornerRadius": "xl",
                "borderColor": "#adb5bd",
                "borderWidth": "6px",
                "width": "20px",
                "height": "20px"
              },
              {
                "type": "text",
                "text": "ID",
                "offsetStart": "18px"
              },
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "text",
                    "text": "."
                  }
                ],
                "width": "20px",
                "height": "20px",
                "cornerRadius": "xl",
                "borderWidth": "6px",
                "backgroundColor": "#adb5bd",
                "offsetEnd": "85px"
              },
              {
                "type": "text",
                "text": "Phone number",
                "offsetEnd": "75px"
              }
            ]
          },
          {
            "type": "spacer"
          }
        ]
      },
      {
        "type": "box",
        "layout": "horizontal",
        "contents": [
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "aglernih",
                "offsetStart": "10px",
                "size": "sm"
              }
            ],
            "borderColor": "#adb5bd",
            "borderWidth": "1px",
            "offsetStart": "10px"
          },
          {
            "type": "spacer",
            "size": "xxl"
          }
        ]
      },
      {
        "type": "box",
        "layout": "vertical",
        "contents": [
          {
            "type": "filler"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "url": "https://obs.line-scdn.net/{}".format(noobcoder.getContact('ubdd00548b45a7bd26c43036e4d92dffa').pictureStatus),
                "aspectMode": "cover",
                "size": "full"
              }
            ],
            "margin": "xxl",
            "cornerRadius": "100px",
            "height": "72px",
            "width": "72px",
            "offsetStart": "110px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "{}".format(noobcoder.getContact('ubdd00548b45a7bd26c43036e4d92dffa').displayName),
                "size": "md",
                "color": "#000000",
                "weight": "bold",
                "align": "center"
              },
              {
                "type": "box",
                "layout": "horizontal",
                "contents": [
                  {
                    "type": "filler"
                  },
                  {
                    "type": "box",
                    "layout": "vertical",
                    "contents": [
                      {
                        "type": "text",
                        "text": "Add Friend",
                        "size": "sm",
                        "color": "#Ffffff",
                        "align": "center"
                      }
                    ],
                    "borderWidth": "1px",
                    "backgroundColor": "#008000",
                    "action": {
                      "type": "uri",
                      "label": "action",
                      "uri": "http://line.me/ti/p/~aglernih"
                    }
                  },
                  {
                    "type": "filler"
                  }
                ],
                "margin": "md"
              }
            ],
            "margin": "md"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "spacer",
                "size": "xxl"
              }
            ],
            "margin": "xxl"
          }
        ],
        "margin": "xxl"
      }
    ],
    "paddingAll": "0px"
  }
},{
  "type": "bubble",
  "body": {
    "type": "box",
    "layout": "vertical",
    "contents": [
      {
        "type": "box",
        "layout": "vertical",
        "contents": [
          {
            "type": "spacer"
          },
          {
            "type": "box",
            "layout": "baseline",
            "contents": [
              {
                "type": "icon",
                "url": "https://i.ibb.co/zHkYgV7/left.png",
                "offsetStart": "10px"
              },
              {
                "type": "text",
                "color": "#Ffffff",
                "text": "Friend search",
                "size": "md",
                "offsetStart": "20px"
              }
            ],
            "margin": "md"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "spacer",
                "size": "lg"
              }
            ]
          }
        ],
        "backgroundColor": "#464F69"
      },
      {
        "type": "box",
        "layout": "vertical",
        "contents": [
          {
            "type": "spacer",
            "size": "xxl"
          },
          {
            "type": "box",
            "layout": "horizontal",
            "contents": [
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "text",
                    "text": "."
                  }
                ],
                "offsetStart": "10px",
                "cornerRadius": "xl",
                "borderColor": "#adb5bd",
                "borderWidth": "6px",
                "width": "20px",
                "height": "20px"
              },
              {
                "type": "text",
                "text": "ID",
                "offsetStart": "18px"
              },
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "text",
                    "text": "."
                  }
                ],
                "width": "20px",
                "height": "20px",
                "cornerRadius": "xl",
                "borderWidth": "6px",
                "backgroundColor": "#adb5bd",
                "offsetEnd": "85px"
              },
              {
                "type": "text",
                "text": "Phone number",
                "offsetEnd": "75px"
              }
            ]
          },
          {
            "type": "spacer"
          }
        ]
      },
      {
        "type": "box",
        "layout": "horizontal",
        "contents": [
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "gkada.line",
                "offsetStart": "10px",
                "size": "sm"
              }
            ],
            "borderColor": "#adb5bd",
            "borderWidth": "1px",
            "offsetStart": "10px"
          },
          {
            "type": "spacer",
            "size": "xxl"
          }
        ]
      },
      {
        "type": "box",
        "layout": "vertical",
        "contents": [
          {
            "type": "filler"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "url": "https://obs.line-scdn.net/{}".format(noobcoder.getContact('ucad303333969352466bfecd62089a1b4').pictureStatus),
                "aspectMode": "cover",
                "size": "full"
              }
            ],
            "margin": "xxl",
            "cornerRadius": "100px",
            "height": "72px",
            "width": "72px",
            "offsetStart": "110px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "{}".format(noobcoder.getContact('ucad303333969352466bfecd62089a1b4').displayName),
                "size": "md",
                "color": "#000000",
                "weight": "bold",
                "align": "center"
              },
              {
                "type": "box",
                "layout": "horizontal",
                "contents": [
                  {
                    "type": "filler"
                  },
                  {
                    "type": "box",
                    "layout": "vertical",
                    "contents": [
                      {
                        "type": "text",
                        "text": "Add Friend",
                        "size": "sm",
                        "color": "#Ffffff",
                        "align": "center"
                      }
                    ],
                    "borderWidth": "1px",
                    "backgroundColor": "#008000",
                    "action": {
                      "type": "uri",
                      "label": "action",
                      "uri": "http://line.me/ti/p/~gkada.line"
                    }
                  },
                  {
                    "type": "filler"
                  }
                ],
                "margin": "md"
              }
            ],
            "margin": "md"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "spacer",
                "size": "xxl"
              }
            ],
            "margin": "xxl"
          }
        ],
        "margin": "xxl"
      }
    ],
    "paddingAll": "0px"
  }}]}}
    sendTemplate(to,data)
def helpss(to):
    ret_ = helpers(to)
    k = len(ret_)//10
    for aa in range(k+1):
        data = {
            "type": "flex",
            "altText": "Help",
            "contents": {
                "type": "carousel",
                "contents": ret_[aa*10 : (aa+1)*10]
            }
        }
        sendTemplate(to, data)
def freesb(to):
	data={"type":"flex","altText":"NOOB CODER™","contents":{
  "type": "carousel",
  "contents": [
    {
      "type": "bubble",
      "body": {
        "type": "box",
        "layout": "vertical",
        "contents": [
          {
            "type": "image",
#            "url": "https://i.ibb.co/kB76BHC/IMG-20191124-115330.jpg",
            "url": "https://obs.line-scdn.net/" + noobcoder.profile.pictureStatus,
            "size": "full",
            "aspectMode": "cover",
            "aspectRatio": "2:3",
            "gravity": "top"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "text",
                    "text": "FREE SELFBOT",
                    "size": "xl",
                    "align": "center",
                    "color": "{}".format(setbot["text"]),
                    "weight": "bold"
                  }
                ]
              },
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "spacer",
                    "size": "xxl"
                  },
                  {
                    "type": "box",
                    "layout": "vertical",
                    "contents": [
                      {
                        "type": "box",
                        "layout": "vertical",
                        "contents": [
                          {
                            "type": "spacer",
                            "size": "xxl"
                          }
                        ]
                      },
                      {
                        "type": "box",
                        "layout": "horizontal",
                        "contents": [
                          {
                            "type": "text",
                            "text": "Chatbot",
                            "size": "xs",
                            "color": "{}".format(setbot["text"]),
                            "align": "center",
                            "action": {
                              "type": "uri",
                              "label": "action",
                              "uri": "line://app/1643727178-0XPGAaRX?type=fotext&text=Chatbot"
                            }
                          },
                          {
                            "type": "text",
                            "text": "Feature",
                            "size": "xs",
                            "color": "{}".format(setbot["text"]),
                            "align": "center",
                            "action": {
                              "type": "uri",
                              "label": "action",
                              "uri": "line://app/1643727178-0XPGAaRX?type=fotext&text=Feature"
                            }
                          },
                          {
                            "type": "text",
                            "text": "Images",
                            "size": "xs",
                            "color": "{}".format(setbot["text"]),
                            "align": "center",
                            "action": {
                              "type": "uri",
                              "label": "action",
                              "uri": "line://app/1643727178-0XPGAaRX?type=fotext&text=Images"
                            }
                          }
                        ]
                      },
                      {
                        "type": "box",
                        "layout": "vertical",
                        "contents": [
                          {
                            "type": "spacer",
                            "size": "xxl"
                          }
                        ]
                      },
                      {
                        "type": "box",
                        "layout": "horizontal",
                        "contents": [
                          {
                            "type": "text",
                            "text": "Profile",
                            "size": "xs",
                            "color": "{}".format(setbot["text"]),
                            "align": "center",
                            "action": {
                              "type": "uri",
                              "label": "action",
                              "uri": "line://app/1643727178-0XPGAaRX?type=fotext&text=Profile"
                            }
                          },
                          {
                            "type": "text",
                            "text": "Protect",
                            "size": "xs",
                            "color": "{}".format(setbot["text"]),
                            "align": "center",
                            "action": {
                              "type": "uri",
                              "label": "action",
                              "uri": "line://app/1643727178-0XPGAaRX?type=fotext&text=Protect"
                            }
                          },
                          {
                            "type": "text",
                            "text": "Social",
                            "size": "xs",
                            "color": "{}".format(setbot["text"]),
                            "align": "center",
                            "action": {
                              "type": "uri",
                              "label": "action",
                              "uri": "line://app/1643727178-0XPGAaRX?type=fotext&text=Social"
                            }
                          }
                        ]
                      },
                      {
                        "type": "box",
                        "layout": "vertical",
                        "contents": [
                          {
                            "type": "spacer",
                            "size": "xxl"
                          }
                        ]
                      },
                      {
                        "type": "box",
                        "layout": "horizontal",
                        "contents": [
                          {
                            "type": "text",
                            "text": "Timeline",
                            "size": "xs",
                            "color": "{}".format(setbot["text"]),
                            "align": "center",
                            "action": {
                              "type": "uri",
                              "label": "action",
                              "uri": "line://app/1643727178-0XPGAaRX?type=fotext&text=Timeline"
                            }
                          },
                          {
                            "type": "text",
                            "text": "Translate",
                            "action": {
                              "type": "uri",
                              "label": "action",
                              "uri": "line://app/1643727178-0XPGAaRX?type=fotext&text=Translate"
                            },
                            "size": "xs",
                            "color": "{}".format(setbot["text"]),
                            "align": "center"
                          },
                          {
                            "type": "text",
                            "text": "Settings",
                            "align": "center",
                            "action": {
                              "type": "uri",
                              "label": "action",
                              "uri": "line://app/1643727178-0XPGAaRX?type=fotext&text=Settings"
                            },
                            "size": "xs",
                            "color": "{}".format(setbot["text"])
                          }
                        ]
                      },
                      {
                        "type": "box",
                        "layout": "vertical",
                        "contents": [
                          {
                            "type": "spacer",
                            "size": "xxl"
                          }
                        ]
                      }
                    ],
                    "borderColor": "{}".format(setbot["separator"]),
                    "borderWidth": "5px"
                  }
                ]
              }
            ],
            "position": "absolute",
            "offsetBottom": "0px",
            "offsetStart": "0px",
            "offsetEnd": "0px",
            "backgroundColor": "#000000cc",
            "paddingAll": "20px",
            "paddingTop": "18px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "url": "https://i.ibb.co/jrrMPdG/1553179449707.jpg"
              }
            ],
            "position": "absolute",
            "offsetTop": "50px",
            "height": "100px",
            "width": "100px",
            "borderWidth": "4px",
            "borderColor": "{}".format(setbot["separator"]),
            "cornerRadius": "100px",
            "offsetStart": "95px"
          }
        ],
        "paddingAll": "0px",
        "cornerRadius": "xl",
        "borderColor": "{}".format(setbot["separator"]),
        "borderWidth": "4px"
      }
    },
    {
      "type": "bubble",
      "body": {
        "type": "box",
        "layout": "vertical",
        "contents": [
          {
            "type": "image",
#            "url": "https://i.ibb.co/6bWK84V/Screenshot-2019-11-24-11-57-59-87.png",
            "url": "https://obs.line-scdn.net/" + noobcoder.profile.pictureStatus,
            "size": "full",
            "aspectMode": "cover",
            "aspectRatio": "2:3",
            "gravity": "top"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "text",
                    "text": "FREE SELFBOT",
                    "size": "xl",
                    "align": "center",
                    "color": "{}".format(setbot["text"]),
                    "weight": "bold"
                  }
                ]
              },
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "spacer",
                    "size": "xxl"
                  },
                  {
                    "type": "box",
                    "layout": "vertical",
                    "contents": [
                      {
                        "type": "box",
                        "layout": "vertical",
                        "contents": [
                          {
                            "type": "spacer",
                            "size": "xxl"
                          }
                        ]
                      },
                      {
                        "type": "box",
                        "layout": "horizontal",
                        "contents": [
                          {
                            "type": "text",
                            "text": "Banning",
                            "size": "xs",
                            "color": "{}".format(setbot["text"]),
                            "align": "center",
                            "action": {
                              "type": "uri",
                              "label": "action",
                              "uri": "line://app/1643727178-0XPGAaRX?type=fotext&text=Banning"
                            }
                          },
                          {
                            "type": "text",
                            "text": "Wordban",
                            "size": "xs",
                            "color": "{}".format(setbot["text"]),
                            "align": "center",
                            "action": {
                              "type": "uri",
                              "label": "action",
                              "uri": "line://app/1643727178-0XPGAaRX?type=fotext&text=Wordban"
                            }
                          },
                          {
                            "type": "text",
                            "text": "Friend",
                            "size": "xs",
                            "color": "{}".format(setbot["text"]),
                            "align": "center",
                            "action": {
                              "type": "uri",
                              "label": "action",
                              "uri": "line://app/1643727178-0XPGAaRX?type=fotext&text=Friend"
                            }
                          }
                        ]
                      },
                      {
                        "type": "box",
                        "layout": "vertical",
                        "contents": [
                          {
                            "type": "spacer",
                            "size": "xxl"
                          }
                        ]
                      },
                      {
                        "type": "box",
                        "layout": "horizontal",
                        "contents": [
                          {
                            "type": "text",
                            "text": "Self",
                            "size": "xs",
                            "color": "{}".format(setbot["text"]),
                            "align": "center",
                            "action": {
                              "type": "uri",
                              "label": "action",
                              "uri": "line://app/1643727178-0XPGAaRX?type=fotext&text=Self"
                            }
                          },
                          {
                            "type": "text",
                            "text": "Memegen",
                            "size": "xs",
                            "color": "{}".format(setbot["text"]),
                            "align": "center",
                            "action": {
                              "type": "uri",
                              "label": "action",
                              "uri": "line://app/1643727178-0XPGAaRX?type=fotext&text=Memegen"
                            }
                          },
                          {
                            "type": "text",
                            "text": "Kick",
                            "size": "xs",
                            "color": "{}".format(setbot["text"]),
                            "align": "center",
                            "action": {
                              "type": "uri",
                              "label": "action",
                              "uri": "line://app/1643727178-0XPGAaRX?type=fotext&text=Kick"
                            }
                          }
                        ]
                      },
                      {
                        "type": "box",
                        "layout": "vertical",
                        "contents": [
                          {
                            "type": "spacer",
                            "size": "xxl"
                          }
                        ]
                      },
                      {
                        "type": "box",
                        "layout": "horizontal",
                        "contents": [
                          {
                            "type": "text",
                            "text": "Utility",
                            "size": "xs",
                            "color": "{}".format(setbot["text"]),
                            "align": "center",
                            "action": {
                              "type": "uri",
                              "label": "action",
                              "uri": "line://app/1643727178-0XPGAaRX?type=fotext&text=Utility"
                            }
                          },
                          {
                            "type": "text",
                            "text": "Github",
                            "action": {
                              "type": "uri",
                              "label": "action",
                              "uri": "line://app/1643727178-0XPGAaRX?type=fotext&text=Github"
                            },
                            "size": "xs",
                            "color": "{}".format(setbot["text"]),
                            "align": "center"
                          },
                          {
                            "type": "text",
                            "text": "Maker",
                            "align": "center",
                            "action": {
                              "type": "uri",
                              "label": "action",
                              "uri": "line://app/1643727178-0XPGAaRX?type=fotext&text=Maker"
                            },
                            "size": "xs",
                            "color": "{}".format(setbot["text"])
                          }
                        ]
                      },
                      {
                        "type": "box",
                        "layout": "vertical",
                        "contents": [
                          {
                            "type": "spacer",
                            "size": "xxl"
                          }
                        ]
                      }
                    ],
                    "borderColor": "{}".format(setbot["separator"]),
                    "borderWidth": "5px"
                  }
                ]
              }
            ],
            "position": "absolute",
            "offsetBottom": "0px",
            "offsetStart": "0px",
            "offsetEnd": "0px",
            "backgroundColor": "#000000cc",
            "paddingAll": "20px",
            "paddingTop": "18px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "url": "https://i.ibb.co/jrrMPdG/1553179449707.jpg"
              }
            ],
            "position": "absolute",
            "offsetTop": "50px",
            "height": "100px",
            "width": "100px",
            "borderWidth": "4px",
            "borderColor": "{}".format(setbot["separator"]),
            "cornerRadius": "100px",
            "offsetStart": "95px"
          }
        ],
        "paddingAll": "0px",
        "cornerRadius": "xl",
        "borderColor": "{}".format(setbot["separator"]),
        "borderWidth": "4px"
      }
    },
    {
      "type": "bubble",
      "body": {
        "type": "box",
        "layout": "vertical",
        "contents": [
          {
            "type": "image",
#            "url": "https://i.ibb.co/0Y6NPwj/IMG-20191124-115313.jpg",
            "url": "https://obs.line-scdn.net/" + noobcoder.profile.pictureStatus,
            "size": "full",
            "aspectMode": "cover",
            "aspectRatio": "2:3",
            "gravity": "top"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "text",
                    "text": "FREE SELFBOT",
                    "size": "xl",
                    "align": "center",
                    "color": "{}".format(setbot["text"]),
                    "weight": "bold"
                  }
                ]
              },
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "spacer",
                    "size": "xxl"
                  },
                  {
                    "type": "box",
                    "layout": "vertical",
                    "contents": [
                      {
                        "type": "box",
                        "layout": "vertical",
                        "contents": [
                          {
                            "type": "spacer",
                            "size": "xxl"
                          }
                        ]
                      },
                      {
                        "type": "box",
                        "layout": "horizontal",
                        "contents": [
                          {
                            "type": "text",
                            "text": "Group",
                            "size": "xs",
                            "color": "{}".format(setbot["text"]),
                            "align": "center",
                            "action": {
                              "type": "uri",
                              "label": "action",
                              "uri": "line://app/1643727178-0XPGAaRX?type=fotext&text=Group"
                            }
                          },
                          {
                            "type": "text",
                            "text": "Mention",
                            "size": "xs",
                            "color": "{}".format(setbot["text"]),
                            "align": "center",
                            "action": {
                              "type": "uri",
                              "label": "action",
                              "uri": "line://app/1643727178-0XPGAaRX?type=fotext&text=Mention"
                            }
                          },
                          {
                            "type": "text",
                            "text": "Steal",
                            "size": "xs",
                            "color": "{}".format(setbot["text"]),
                            "align": "center",
                            "action": {
                              "type": "uri",
                              "label": "action",
                              "uri": "line://app/1643727178-0XPGAaRX?type=fotext&text=Steal"
                            }
                          }
                        ]
                      },
                      {
                        "type": "box",
                        "layout": "vertical",
                        "contents": [
                          {
                            "type": "spacer",
                            "size": "xxl"
                          }
                        ]
                      },
                      {
                        "type": "box",
                        "layout": "horizontal",
                        "contents": [
                          {
                            "type": "text",
                            "text": "List",
                            "size": "xs",
                            "color": "{}".format(setbot["text"]),
                            "align": "center",
                            "action": {
                              "type": "uri",
                              "label": "action",
                              "uri": "line://app/1643727178-0XPGAaRX?type=fotext&text=List"
                            }
                          },
                          {
                            "type": "text",
                            "text": "Bcast",
                            "size": "xs",
                            "color": "{}".format(setbot["text"]),
                            "align": "center",
                            "action": {
                              "type": "uri",
                              "label": "action",
                              "uri": "line://app/1643727178-0XPGAaRX?type=fotext&text=Bcast"
                            }
                          },
                          {
                            "type": "text",
                            "text": "Leave",
                            "size": "xs",
                            "color": "{}".format(setbot["text"]),
                            "align": "center",
                            "action": {
                              "type": "uri",
                              "label": "action",
                              "uri": "line://app/1643727178-0XPGAaRX?type=fotext&text=Leave"
                            }
                          }
                        ]
                      },
                      {
                        "type": "box",
                        "layout": "vertical",
                        "contents": [
                          {
                            "type": "spacer",
                            "size": "xxl"
                          }
                        ]
                      },
                      {
                        "type": "box",
                        "layout": "horizontal",
                        "contents": [
                          {
                            "type": "text",
                            "text": "Reboot",
                            "size": "xs",
                            "color": "{}".format(setbot["text"]),
                            "align": "center",
                            "action": {
                              "type": "uri",
                              "label": "action",
                              "uri": "line://app/1643727178-0XPGAaRX?type=fotext&text=Reboot"
                            }
                          },
                          {
                            "type": "text",
                            "text": "Timeleft",
                            "action": {
                              "type": "uri",
                              "label": "action",
                              "uri": "line://app/1643727178-0XPGAaRX?type=fotext&text=Timeleft"
                            },
                            "size": "xs",
                            "color": "{}".format(setbot["text"]),
                            "align": "center"
                          },
                          {
                            "type": "text",
                            "text": "Logout",
                            "align": "center",
                            "action": {
                              "type": "uri",
                              "label": "action",
                              "uri": "line://app/1643727178-0XPGAaRX?type=fotext&text=Logout"
                            },
                            "size": "xs",
                            "color": "{}".format(setbot["text"])
                          }
                        ]
                      },
                      {
                        "type": "box",
                        "layout": "vertical",
                        "contents": [
                          {
                            "type": "spacer",
                            "size": "xxl"
                          }
                        ]
                      }
                    ],
                    "borderColor": "{}".format(setbot["separator"]),
                    "borderWidth": "5px"
                  }
                ]
              }
            ],
            "position": "absolute",
            "offsetBottom": "0px",
            "offsetStart": "0px",
            "offsetEnd": "0px",
            "backgroundColor": "#000000cc",
            "paddingAll": "20px",
            "paddingTop": "18px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "url": "https://i.ibb.co/jrrMPdG/1553179449707.jpg"
              }
            ],
            "position": "absolute",
            "offsetTop": "50px",
            "height": "100px",
            "width": "100px",
            "borderWidth": "4px",
            "borderColor": "{}".format(setbot["separator"]),
            "cornerRadius": "100px",
            "offsetStart": "95px"
          }
        ],
        "paddingAll": "0px",
        "cornerRadius": "xl",
        "borderColor": "{}".format(setbot["separator"]),
        "borderWidth": "4px"
      }
    }
  ]
}}
	sendTemplate(to,data)
def helpers(to):
    ret_ = []
    ret_.append(
        {
            "styles": {"body": {"backgroundColor": "{}".format(setbot["background"])},"header": {"backgroundColor": "{}".format(setbot["background"])}},
            "type": "bubble",
            "body": {"contents": [{
                "type": "box",
                "layout": "baseline",
                "contents": [
                    {
                        "type": "spacer",
                        "size": "xxl"
                    },
                    {
                        "contents": [{
                        "url": "https://i.ibb.co/jrrMPdG/1553179449707.jpg",
                        "size": "xxs",
                        "type": "image",
                        "action": {
                        "type": "uri",
                        "uri": "line://app/1643727178-0XPGAaRX?type=fotext&text=Chatbot"
                    }
                }, {
                                                    "url": "https://i.ibb.co/jrrMPdG/1553179449707.jpg",
                                                    "size": "xxs",
                                                    "type": "image",
                                                    "action": {
                                                        "type": "uri",
                                                        "uri": "line://app/1643727178-0XPGAaRX?type=fotext&text=Feature"
                                                    }
                                                },{
                                                    "url": "https://i.ibb.co/jrrMPdG/1553179449707.jpg",
                                                    "size": "xxs",
                                                   "type": "image",
                                                    "action": {
                                                        "type": "uri",
                                                        "uri": "line://app/1643727178-0XPGAaRX?type=fotext&text=Images"
                                                    }
                                                }],
                                                "layout": "horizontal",
                                                "type": "box",
                                                "flex": 1
                                            }, 
                                                                 {
        "type": "box",
        "layout": "horizontal",
        "spacing": "xxl",       
        "contents": [
          {
            "type": "text", 
            "text": 'Chatbot',
            "color": "{}".format(setbot["text"]),
            "size": "xs",
            "align": "center",
          },
          {
            "type": "text",
            "text": 'Feature',
            "color": "{}".format(setbot["text"]),
            "size": "xs",
            "align": "center"
          },
          {
            "type": "text", 
            "text": 'Images',
            "color": "{}".format(setbot["text"]),
            "size": "xs"
          }
        ]
      },
            ],
            "type": "box",
            "spacing": "xs",
            "layout": "vertical"
          },
          {
            "contents": [
              {
       "type": "spacer",
       "size": "xl"
     },
              {
                                                "contents": [{
                                                    "url": "https://i.ibb.co/jrrMPdG/1553179449707.jpg",
                                                    "size": "xxs",
                                                    "type": "image",
                                                    "action": {
                                                        "type": "uri",
                                                        "uri": "line://app/1643727178-0XPGAaRX?type=fotext&text=Profile"
                                                    }
                                                }, {
                                                    "url": "https://i.ibb.co/jrrMPdG/1553179449707.jpg",
                                                    "size": "xxs",
                                                    "type": "image",
                                                    "action": {
                                                        "type": "uri",
                                                        "uri": "line://app/1643727178-0XPGAaRX?type=fotext&text=Protect"
                                                    }
                                                },{
                                                    "url": "https://i.ibb.co/jrrMPdG/1553179449707.jpg",
                                                    "size": "xxs",
                                                    "type": "image",
                                                    "action": {
                                                        "type": "uri",
                                                        "uri": "line://app/1643727178-0XPGAaRX?type=fotext&text=Social"
                                                    }
                                                }],
                                                "layout": "horizontal",
                                                "type": "box",
                                                "flex": 1
                                            }, 
                                                                 {
        "type": "box",
        "layout": "horizontal",
        "spacing": "xxl",
        "contents": [
          {
            "type": "text", 
            "text": 'Profile',
            "color": "{}".format(setbot["text"]),
            "size": "xs",
            "align": "center",
          },
          {
            "type": "text",
            "text": 'Protect',
            "color": "{}".format(setbot["text"]),
            "size": "xs",
            "align": "center"
          },
          {
            "type": "text", 
            "text": 'Social',
            "color": "{}".format(setbot["text"]),
            "size": "xs"
          }
        ]
      },
            ],
            "type": "box",
            "spacing": "xs",
            "layout": "vertical"
          },
          {
            "contents": [
              {
       "type": "spacer",
       "size": "xl"
     },
              {
                                                "contents": [{
                                                    "url": "https://i.ibb.co/jrrMPdG/1553179449707.jpg",
                                                    "size": "xxs",
                                                    "type": "image",
                                                    "action": {
                                                        "type": "uri",
                                                        "uri": "line://app/1643727178-0XPGAaRX?type=fotext&text=Timeline"
                                                    }
                                                }, {
                                                    "url": "https://i.ibb.co/jrrMPdG/1553179449707.jpg",
                                                    "size": "xxs",
                                                    "type": "image",
                                                    "action": {
                                                        "type": "uri",
                                                        "uri": "line://app/1643727178-0XPGAaRX?type=fotext&text=Translate"
                                                    }
                                                },{
                                                    "url": "https://i.ibb.co/jrrMPdG/1553179449707.jpg",
                                                    "size": "xxs",
                                                    "type": "image",
                                                    "action": {
                                                        "type": "uri",
                                                        "uri": "line://app/1643727178-0XPGAaRX?type=fotext&text=Settings"
                                                    }
                                                }],
                                                "layout": "horizontal",
                                                "type": "box",
                                                "flex": 1
                                            }, 
                                                                 {
        "type": "box",
        "layout": "horizontal",
        "spacing": "xxl",
        "contents": [
          {
            "type": "text", 
            "text": 'Timeline',
            "color": "{}".format(setbot["text"]),
            "size": "xs",
            "align": "center",
          },
          {
            "type": "text",
            "text": 'Translate',
            "color": "{}".format(setbot["text"]),
            "size": "xs",
            "align": "center"
          },
          {
            "type": "text", 
            "text": 'Settings',
            "color": "{}".format(setbot["text"]),
            "size": "xs"
          }
        ]
      },
            ],
            "type": "box",
            "spacing": "xs",
            "layout": "vertical"
          },
          {
            "contents": [
              {
       "type": "spacer",
       "size": "xl"
     },
],
            "type": "box",
            "spacing": "xs",
            "layout": "vertical"
          }  
        ],
        "type": "box",
        "spacing": "xs",
        "layout": "vertical",
        "cornerRadius": "xl",
        "borderWidth": "4px",
        "borderColor": "{}".format(setbot["separator"])
      }
    }
    )
    ret_.append(
        {
            "styles": {"body": {"backgroundColor": "{}".format(setbot["background"])},"header": {"backgroundColor": "{}".format(setbot["background"])}},
            "type": "bubble",
            "body": {"contents": [{
                "type": "box",
                "layout": "baseline",
                "contents": [
                    {
                        "type": "spacer",
                        "size": "xxl"
                    },
                    {
                        "contents": [{
                        "url": "https://i.ibb.co/jrrMPdG/1553179449707.jpg",
                        "size": "xxs",
                        "type": "image",
                        "action": {
                        "type": "uri",
                        "uri": "line://app/1643727178-0XPGAaRX?type=fotext&text=Banning"
                    }
                }, {
                                                    "url": "https://i.ibb.co/jrrMPdG/1553179449707.jpg",
                                                    "size": "xxs",
                                                    "type": "image",
                                                    "action": {
                                                        "type": "uri",
                                                        "uri": "line://app/1643727178-0XPGAaRX?type=fotext&text=Wordban"
                                                    }
                                                },{
                                                    "url": "https://i.ibb.co/jrrMPdG/1553179449707.jpg",
                                                    "size": "xxs",
                                                   "type": "image",
                                                    "action": {
                                                        "type": "uri",
                                                        "uri": "line://app/1643727178-0XPGAaRX?type=fotext&text=Friend"
                                                    }
                                                }],
                                                "layout": "horizontal",
                                                "type": "box",
                                                "flex": 1
                                            }, 
                                                                 {
        "type": "box",
        "layout": "horizontal",
        "spacing": "xxl",       
        "contents": [
          {
            "type": "text", 
            "text": 'Banning',
            "color": "{}".format(setbot["text"]),
            "size": "xs",
            "align": "center",
          },
          {
            "type": "text",
            "text": 'Wordban',
            "color": "{}".format(setbot["text"]),
            "size": "xs",
            "align": "center"
          },
          {
            "type": "text", 
            "text": 'Friend',
            "color": "{}".format(setbot["text"]),
            "size": "xs"
          }
        ]
      },
            ],
            "type": "box",
            "spacing": "xs",
            "layout": "vertical"
          },
          {
            "contents": [
              {
       "type": "spacer",
       "size": "xl"
     },
              {
                                                "contents": [{
                                                    "url": "https://i.ibb.co/jrrMPdG/1553179449707.jpg",
                                                    "size": "xxs",
                                                    "type": "image",
                                                    "action": {
                                                        "type": "uri",
                                                        "uri": "line://app/1643727178-0XPGAaRX?type=fotext&text=Self"
                                                    }
                                                }, {
                                                    "url": "https://i.ibb.co/jrrMPdG/1553179449707.jpg",
                                                    "size": "xxs",
                                                    "type": "image",
                                                    "action": {
                                                        "type": "uri",
                                                        "uri": "line://app/1643727178-0XPGAaRX?type=fotext&text=Memegen"
                                                    }
                                                },{
                                                    "url": "https://i.ibb.co/jrrMPdG/1553179449707.jpg",
                                                    "size": "xxs",
                                                    "type": "image",
                                                    "action": {
                                                        "type": "uri",
                                                        "uri": "line://app/1643727178-0XPGAaRX?type=fotext&text=Kick"
                                                    }
                                                }],
                                                "layout": "horizontal",
                                                "type": "box",
                                                "flex": 1
                                            }, 
                                                                 {
        "type": "box",
        "layout": "horizontal",
        "spacing": "xxl",
        "contents": [
          {
            "type": "text", 
            "text": 'Self',
            "color": "{}".format(setbot["text"]),
            "size": "xs",
            "align": "center",
          },
          {
            "type": "text",
            "text": 'Memegen',
            "color": "{}".format(setbot["text"]),
            "size": "xs",
            "align": "center"
          },
          {
            "type": "text", 
            "text": 'Kick',
            "color": "{}".format(setbot["text"]),
            "size": "xs"
          }
        ]
      },
            ],
            "type": "box",
            "spacing": "xs",
            "layout": "vertical"
          },
          {
            "contents": [
              {
       "type": "spacer",
       "size": "xl"
     },
              {
                                                "contents": [{
                                                    "url": "https://i.ibb.co/jrrMPdG/1553179449707.jpg",
                                                    "size": "xxs",
                                                    "type": "image",
                                                    "action": {
                                                        "type": "uri",
                                                        "uri": "line://app/1643727178-0XPGAaRX?type=fotext&text=Utility"
                                                    }
                                                }, {
                                                    "url": "https://i.ibb.co/jrrMPdG/1553179449707.jpg",
                                                    "size": "xxs",
                                                    "type": "image",
                                                    "action": {
                                                        "type": "uri",
                                                        "uri": "line://app/1643727178-0XPGAaRX?type=fotext&text=Github"
                                                    }
                                                },{
                                                    "url": "https://i.ibb.co/jrrMPdG/1553179449707.jpg",
                                                    "size": "xxs",
                                                    "type": "image",
                                                    "action": {
                                                        "type": "uri",
                                                        "uri": "line://app/1643727178-0XPGAaRX?type=fotext&text=About"
                                                    }
                                                }],
                                                "layout": "horizontal",
                                                "type": "box",
                                                "flex": 1
                                            }, 
                                                                 {
        "type": "box",
        "layout": "horizontal",
        "spacing": "xxl",
        "contents": [
          {
            "type": "text", 
            "text": 'Utility',
            "color": "{}".format(setbot["text"]),
            "size": "xs",
            "align": "center",
          },
          {
            "type": "text",
            "text": 'Github',
            "color": "{}".format(setbot["text"]),
            "size": "xs",
            "align": "center"
          },
          {
            "type": "text", 
            "text": 'About',
            "color": "{}".format(setbot["text"]),
            "size": "xs"
          }
        ]
      },
            ],
            "type": "box",
            "spacing": "xs",
            "layout": "vertical"
          },
          {
            "contents": [
              {
       "type": "spacer",
       "size": "xl"
     },
],
            "type": "box",
            "spacing": "xs",
            "layout": "vertical"
          }  
        ],
        "type": "box",
        "spacing": "xs",
        "layout": "vertical",
        "cornerRadius": "xl",
        "borderWidth": "4px",
        "borderColor": "{}".format(setbot["separator"])
      }
    }
    )
    ret_.append(
        {
            "styles": {"body": {"backgroundColor": "{}".format(setbot["background"])},"header": {"backgroundColor": "{}".format(setbot["background"])}},
            "type": "bubble",
            "body": {"contents": [{
                "type": "box",
                "layout": "baseline",
                "contents": [
                    {
                        "type": "spacer",
                        "size": "xxl"
                    },
                    {
                        "contents": [{
                        "url": "https://i.ibb.co/jrrMPdG/1553179449707.jpg",
                        "size": "xxs",
                        "type": "image",
                        "action": {
                        "type": "uri",
                        "uri": "line://app/1643727178-0XPGAaRX?type=fotext&text=Group"
                    }
                }, {
                                                    "url": "https://i.ibb.co/jrrMPdG/1553179449707.jpg",
                                                    "size": "xxs",
                                                    "type": "image",
                                                    "action": {
                                                        "type": "uri",
                                                        "uri": "line://app/1643727178-0XPGAaRX?type=fotext&text=Mention"
                                                    }
                                                },{
                                                    "url": "https://i.ibb.co/jrrMPdG/1553179449707.jpg",
                                                    "size": "xxs",
                                                   "type": "image",
                                                    "action": {
                                                        "type": "uri",
                                                        "uri": "line://app/1643727178-0XPGAaRX?type=fotext&text=Steal"
                                                    }
                                                }],
                                                "layout": "horizontal",
                                                "type": "box",
                                                "flex": 1
                                            }, 
                                                                 {
        "type": "box",
        "layout": "horizontal",
        "spacing": "xxl",       
        "contents": [
          {
            "type": "text", 
            "text": 'Group',
            "color": "{}".format(setbot["text"]),
            "size": "xs",
            "align": "center",
          },
          {
            "type": "text",
            "text": 'Mention',
            "color": "{}".format(setbot["text"]),
            "size": "xs",
            "align": "center"
          },
          {
            "type": "text", 
            "text": 'Steal',
            "color": "{}".format(setbot["text"]),
            "size": "xs"
          }
        ]
      },
            ],
            "type": "box",
            "spacing": "xs",
            "layout": "vertical"
          },
          {
            "contents": [
              {
       "type": "spacer",
       "size": "xl"
     },
              {
                                                "contents": [{
                                                    "url": "https://i.ibb.co/jrrMPdG/1553179449707.jpg",
                                                    "size": "xxs",
                                                    "type": "image",
                                                    "action": {
                                                        "type": "uri",
                                                        "uri": "line://app/1643727178-0XPGAaRX?type=fotext&text=List"
                                                    }
                                                }, {
                                                    "url": "https://i.ibb.co/jrrMPdG/1553179449707.jpg",
                                                    "size": "xxs",
                                                    "type": "image",
                                                    "action": {
                                                        "type": "uri",
                                                        "uri": "line://app/1643727178-0XPGAaRX?type=fotext&text=Bcast"
                                                    }
                                                },{
                                                    "url": "https://i.ibb.co/jrrMPdG/1553179449707.jpg",
                                                    "size": "xxs",
                                                    "type": "image",
                                                    "action": {
                                                        "type": "uri",
                                                        "uri": "line://app/1643727178-0XPGAaRX?type=fotext&text=Leave"
                                                    }
                                                }],
                                                "layout": "horizontal",
                                                "type": "box",
                                                "flex": 1
                                            }, 
                                                                 {
        "type": "box",
        "layout": "horizontal",
        "spacing": "xxl",
        "contents": [
          {
            "type": "text", 
            "text": 'List',
            "color": "{}".format(setbot["text"]),
            "size": "xs",
            "align": "center",
          },
          {
            "type": "text",
            "text": 'Bcast',
            "color": "{}".format(setbot["text"]),
            "size": "xs",
            "align": "center"
          },
          {
            "type": "text", 
            "text": 'Leave',
            "color": "{}".format(setbot["text"]),
            "size": "xs"
          }
        ]
      },
            ],
            "type": "box",
            "spacing": "xs",
            "layout": "vertical"
          },
          {
            "contents": [
              {
       "type": "spacer",
       "size": "xl"
     },
              {
                                                "contents": [{
                                                    "url": "https://i.ibb.co/jrrMPdG/1553179449707.jpg",
                                                    "size": "xxs",
                                                    "type": "image",
                                                    "action": {
                                                        "type": "uri",
                                                        "uri": "line://app/1643727178-0XPGAaRX?type=fotext&text=Reboot"
                                                    }
                                                }, {
                                                    "url": "https://i.ibb.co/jrrMPdG/1553179449707.jpg",
                                                    "size": "xxs",
                                                    "type": "image",
                                                    "action": {
                                                        "type": "uri",
                                                        "uri": "line://app/1643727178-0XPGAaRX?type=fotext&text=Timeleft"
                                                    }
                                                },{
                                                    "url": "https://i.ibb.co/jrrMPdG/1553179449707.jpg",
                                                    "size": "xxs",
                                                    "type": "image",
                                                    "action": {
                                                        "type": "uri",
                                                        "uri": "line://app/1643727178-0XPGAaRX?type=fotext&text=Logout"
                                                    }
                                                }],
                                                "layout": "horizontal",
                                                "type": "box",
                                                "flex": 1
                                            }, 
                                                                 {
        "type": "box",
        "layout": "horizontal",
        "spacing": "xxl",
        "contents": [
          {
            "type": "text", 
            "text": 'Reboot',
            "color": "{}".format(setbot["text"]),
            "size": "xs",
            "align": "center",
          },
          {
            "type": "text",
            "text": 'Timeleft',
            "color": "{}".format(setbot["text"]),
            "size": "xs",
            "align": "center"
          },
          {
            "type": "text", 
            "text": 'Logout',
            "color": "{}".format(setbot["text"]),
            "size": "xs"
          }
        ]
      },
            ],
            "type": "box",
            "spacing": "xs",
            "layout": "vertical"
          },
          {
            "contents": [
              {
       "type": "spacer",
       "size": "xl"
     },
],
            "type": "box",
            "spacing": "xs",
            "layout": "vertical"
          }  
        ],
        "type": "box",
        "spacing": "xs",
        "layout": "vertical",
        "cornerRadius": "xl",
        "borderWidth": "4px",
        "borderColor": "{}".format(setbot["separator"])
      }
    }
    )
    return ret_

def sendFooter(to, text):
    data = {
    "type": "flex",
    "altText": text,
    "contents": {
    "type": "bubble",
    "styles": {
    "footer": {
    "backgroundColor": "{}".format(setbot["background"])
    }
    },
    "footer": {
    "type": "box",
    "layout": "vertical",
     "cornerRadius": "xl",
    "borderWidth": "4px",
    "borderColor": "{}".format(setbot["separator"]),
    "spacing": "sm",
    "contents": [
    {
    "type": "box",
    "layout": "baseline",
    "contents": [
    {
    "type": "icon",
    "url": "https://i.ibb.co/jrrMPdG/1553179449707.jpg",
    "size": "md"
    },
    {
    "type": "text",
    "text": text,
    "color": "{}".format(setbot["text"]),
    "gravity": "center",
    "align":"center",
    "wrap": True,
    "size": "md"
    },
    {
    "type": "icon",
    "url": "https://i.ibb.co/jrrMPdG/1553179449707.jpg",
    "size": "md"
    }, 
    ]
    }
    ]
    }
    }
    }
    sendTemplate(to, data)
def sendFooter1(to, isi):
    data = {
        "type": "text",
        "text": isi,
        "sentBy": {
            "label": "FREE SELFBOT",
            "iconUrl": "https://i.ibb.co/jrrMPdG/1553179449707.jpg",
            "linkUrl": "line://nv/profilePopup/mid=u8c31fa0e60d1eee2558ee7c634614e67"
        }
    }
    sendTemplate(to, data)

def hmmk():
    spam = """
    .1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.
    .1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.
    .1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.
    .1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.
"""
    return spam

def mekz(to, isinya):
    data = {
        "type": "flex",
        "altText": "NOOB CODER™",
        "contents": {
            "type": "carousel",
            "contents": [
              {
                "type": "bubble",
                "body": {
                "type": "box",
                "layout": "vertical",
                "cornerRadius": "xl",
                "borderWidth": "4px",
                "borderColor": "#FFFFFF",
                "contents": [
                  {
                    "type": "image",
                    "url": "https://i.ibb.co/4mbftvy/IMG-20190809-211441.jpg",
                    "size": "full",
                    "aspectMode": "cover",
                    "aspectRatio": "1:1",
                    "gravity": "top"
                  },
                  {
                    "type": "box",
                    "layout": "vertical",
                    "contents": [
                      {
                        "type": "box",
                        "layout": "baseline",
                        "contents": [
                          {
                            "type": "text",
                            "text": isinya,
                            "color": "{}".format(setbot["text"]),
                            "wrap": True,
                            "size": "sm",
                            "flex": 0
                          }
                        ],
                        "spacing": "lg"
                      },
                      {
                        "type": "box",
                        "layout": "vertical",
                        "contents": [
                          {
                            "type": "filler"
                          },
                          {
                            "type": "box",
                            "layout": "baseline",
                            "contents": [
                              {
                                "type": "filler"
                              },
                              {
                                "type": "text",
                                "text": "NOOB CODER™",
                                "weight": "bold",
                                "action": {
                                  "type": "uri",
                                  "uri": "line://nv/profilePopup/mid=u481a911a50dcd7c30fb3907c8fbe31ba"
                                },
                                "color": "#ffffff",
                                "flex": 0,
                                "offsetTop": "-2px"
                              },
                              {
                                "type": "filler"
                              }
                            ],
                            "spacing": "sm"
                          },
                          {
                            "type": "filler"
                          }
                        ],
                        "borderWidth": "1px",
                        "cornerRadius": "4px",
                        "spacing": "sm",
                        "borderColor": "{}".format(setbot["separator"]),
                        "margin": "xxl",
                        "height": "40px"
                      }
                    ],
                    "position": "absolute",
                    "offsetBottom": "0px",
                    "offsetStart": "0px",
                    "offsetEnd": "0px",
                    "backgroundColor": "#000000cc",
                    "paddingAll": "20px",
                    "paddingTop": "18px"
                  }
                ],
                "paddingAll": "0px"
            }
          } 
        ]
      } 
    }
    sendTemplate(to, data)
def ub64(url):
    hasil = base64.b64encode(url.encode())
    return hasil.decode('utf-8')
def flex(to):
    data = {
                                            "type": "flex","altText": "help Message",
                                            "contents": {
                                                "type": "bubble",
                                                "styles": {
                                                        "header": {"backgroundColor": "{}".format(setbot["background"])},
                                                        "body": {"backgroundColor": "{}".format(setbot["background"]),"separator": True,"separatorColor": "{}".format(setbot["separator"])}, 
                                                        "footer": { "backgroundColor": "{}".format(setbot["background"]),"separator": True,"separatorColor": "{}".format(setbot["separator"])}},
                                                "header": {
                                                    "type": "box",
                                                    "layout": "horizontal",
                                                    "contents": [{
                                                            "type": "box",
                                                            "layout": "vertical",
                                                            "margin": "lg",
                                                            "spacing": "sm",
                                                            "contents": [{
                                                                    "type": "box",
                                                                    "layout": "baseline",
                                                                    "spacing": "sm",
                                                                    "contents": [{
                                                                            "type": "text","align": "center",
                                                                            "text": "HELP MESSAGE",
                                                                            "color": "{}".format(setbot["text"]),
                                                                            "weight": "bold",
                                                                            "wrap": True,
                                                                            "size": "xl",
                                "action" : {
  "type" : "uri", "uri" : "line://app/1643727178-0XPGAaRX?type=fotext&text=Help"}, 
                                                                            "flex": 5
                                                                        }]}]}]},
                                                "body": {"type": "box","layout": "vertical",
                                                    "contents": [{
                                                            "type": "box",
                                                            "layout": "vertical",
                                                            "margin": "lg",
                                                            "spacing": "sm",
                                                            "contents": [{
                                                                    "type": "box",
                                                                    "layout": "baseline",
                                                                    "spacing": "sm",
                                                                    "contents": [{
                                                                            "type": "text",
                                                                            "text": "Chatbot",
                                                                            "align": "center",
                                                                            "color": "{}".format(setbot["text"]),
                                                                            "wrap": True,
                                                                            "size": "sm",
                                "action" : {
  "type" : "uri", "uri" : "line://app/1643727178-0XPGAaRX?type=fotext&text=Chatbot"}, 
                                                                            "flex": 0
                                                                        },{
                                                                            "type": "text",
                                                                            "text": "Feature",
                                                                            "align": "center",
                                                                            "color": "{}".format(setbot["text"]),
                                                                            "size": "sm",
                                "action" : {
  "type" : "uri", "uri" : "line://app/1643727178-0XPGAaRX?type=fotext&text=Feature"}, 
                                                                            "flex": 5
                                                                 },{
                                                                            "type": "text",
                                                                            "text": "Images",
                                                                            "align": "center",
                                                                            "color": "{}".format(setbot["text"]),
                                                                            "size": "sm",
                                "action" : {
  "type" : "uri", "uri" : "line://app/1643727178-0XPGAaRX?type=fotext&text=Images"}, 
                                                                            "flex": 0
}]}]},
                                                        {
                                                            "type": "box",
                                                            "layout": "vertical",
                                                            "margin": "lg",
                                                            "spacing": "sm",
                                                            "contents": [{
                                                                    "type": "box",
                                                                    "layout": "baseline",
                                                                    "spacing": "sm",
                                                                    "contents": [{
                                                                            "type": "text",
                                                                            "text": "Profile",
                                                                            "align": "center",
                                                                            "color": "{}".format(setbot["text"]),
                                                                            "wrap": True,
                                                                            "size": "sm",
                                "action" : {
  "type" : "uri", "uri" : "line://app/1643727178-0XPGAaRX?type=fotext&text=Profile"}, 
                                                                            "flex": 0
                                                                        },{
                                                                            "type": "text",
                                                                            "text": "Protect",
                                                                            "align": "center",
                                                                            "color": "{}".format(setbot["text"]),
                                                                            "size": "sm",
                                "action" : {
  "type" : "uri", "uri" : "line://app/1643727178-0XPGAaRX?type=fotext&text=Protect"}, 
                                                                            "flex": 5
                                                                 },{
                                                                            "type": "text",
                                                                            "text": "Social",
                                                                            "align": "center",
                                                                            "color": "{}".format(setbot["text"]),
                                                                            "size": "sm",
                                "action" : {
  "type" : "uri", "uri" : "line://app/1643727178-0XPGAaRX?type=fotext&text=Social"}, 
                                                                            "flex": 0
}]}]},
                                                        {
                                                            "type": "box",
                                                            "layout": "vertical",
                                                            "margin": "lg",
                                                            "spacing": "sm",
                                                            "contents": [{
                                                                    "type": "box",
                                                                    "layout": "baseline",
                                                                    "spacing": "sm",
                                                                    "contents": [{
                                                                            "type": "text",
                                                                            "text": "Timeline",
                                                                            "align": "center",
                                                                            "color": "{}".format(setbot["text"]),
                                                                            "wrap": True,
                                                                            "size": "sm",
                                "action" : {
  "type" : "uri", "uri" : "line://app/1643727178-0XPGAaRX?type=fotext&text=Timeline"}, 
                                                                            "flex": 0
                                                                        },{
                                                                            "type": "text",
                                                                            "text": "Translate",
                                                                            "align": "center",
                                                                            "color": "{}".format(setbot["text"]),
                                                                            "size": "sm",
                                "action" : {
  "type" : "uri", "uri" : "line://app/1643727178-0XPGAaRX?type=fotext&text=Translate"}, 
                                                                            "flex": 5
                                                                 },{
                                                                            "type": "text",
                                                                            "text": "Settings",
                                                                            "align": "center",
                                                                            "color": "{}".format(setbot["text"]),
                                                                            "size": "sm",
                                "action" : {
  "type" : "uri", "uri" : "line://app/1643727178-0XPGAaRX?type=fotext&text=Settings"}, 
                                                                            "flex": 0
}]}]},
                                                        {
                                                            "type": "box",
                                                            "layout": "vertical",
                                                            "margin": "lg",
                                                            "spacing": "sm",
                                                            "contents": [{
                                                                    "type": "box",
                                                                    "layout": "baseline",
                                                                    "spacing": "sm",
                                                                    "contents": [{
                                                                            "type": "text",
                                                                            "text": "Banning",
                                                                            "align": "center",
                                                                            "color": "{}".format(setbot["text"]),
                                                                            "wrap": True,
                                                                            "size": "sm",
                                "action" : {
  "type" : "uri", "uri" : "line://app/1643727178-0XPGAaRX?type=fotext&text=Banning"}, 
                                                                            "flex": 0
                                                                        },{
                                                                            "type": "text",
                                                                            "text": "Wordban",
                                                                            "align": "center",
                                                                            "color": "{}".format(setbot["text"]),
                                                                            "size": "sm",
                                "action" : {
  "type" : "uri", "uri" : "line://app/1643727178-0XPGAaRX?type=fotext&text=Wordban"}, 
                                                                            "flex": 5
                                                                 },{
                                                                            "type": "text",
                                                                            "text": "Friend",
                                                                            "align": "center",
                                                                            "color": "{}".format(setbot["text"]),
                                                                            "size": "sm",
                                "action" : {
  "type" : "uri", "uri" : "line://app/1643727178-0XPGAaRX?type=fotext&text=Friend"}, 
                                                                            "flex": 0
}]}]},
                                                        {
                                                            "type": "box",
                                                            "layout": "vertical",
                                                            "margin": "lg",
                                                            "spacing": "sm",
                                                            "contents": [{
                                                                    "type": "box",
                                                                    "layout": "baseline",
                                                                    "spacing": "sm",
                                                                    "contents": [{
                                                                            "type": "text",
                                                                            "text": "Self",
                                                                            "align": "center",
                                                                            "color": "{}".format(setbot["text"]),
                                                                            "wrap": True,
                                                                            "size": "sm",
                                "action" : {
  "type" : "uri", "uri" : "line://app/1643727178-0XPGAaRX?type=fotext&text=Self"}, 
                                                                            "flex": 0
                                                                        },{
                                                                            "type": "text",
                                                                            "text": "Memegen",
                                                                            "align": "center",
                                                                            "color": "{}".format(setbot["text"]),
                                                                            "size": "sm",
                                "action" : {
  "type" : "uri", "uri" : "line://app/1643727178-0XPGAaRX?type=fotext&text=Memegen"}, 
                                                                            "flex": 5
                                                                 },{
                                                                            "type": "text",
                                                                            "text": "Kick",
                                                                            "align": "center",
                                                                            "color": "{}".format(setbot["text"]),
                                                                            "size": "sm",
                                "action" : {
  "type" : "uri", "uri" : "line://app/1643727178-0XPGAaRX?type=fotext&text=Kick"}, 
                                                                            "flex": 0
}]}]},
                                                        {
                                                            "type": "box",
                                                            "layout": "vertical",
                                                            "margin": "lg",
                                                            "spacing": "sm",
                                                            "contents": [{
                                                                    "type": "box",
                                                                    "layout": "baseline",
                                                                    "spacing": "sm",
                                                                    "contents": [{
                                                                            "type": "text",
                                                                            "text": "Utility",
                                                                            "align": "center",
                                                                            "color": "{}".format(setbot["text"]),
                                                                            "wrap": True,
                                                                            "size": "sm",
                                "action" : {
  "type" : "uri", "uri" : "line://app/1643727178-0XPGAaRX?type=fotext&text=Utility"}, 
                                                                            "flex": 0
                                                                        },{
                                                                            "type": "text",
                                                                            "text": "Github",
                                                                            "align": "center",
                                                                            "color": "{}".format(setbot["text"]),
                                                                            "size": "sm",
                                "action" : {
  "type" : "uri", "uri" : "line://app/1643727178-0XPGAaRX?type=fotext&text=Github"}, 
                                                                            "flex": 5
                                                                 },{
                                                                            "type": "text",
                                                                            "text": "About",
                                                                            "align": "center",
                                                                            "color": "{}".format(setbot["text"]),
                                                                            "size": "sm",
                                "action" : {
  "type" : "uri", "uri" : "line://app/1643727178-0XPGAaRX?type=fotext&text=About"}, 
                                                                            "flex": 0
}]}]},
                                                        {
                                                            "type": "box",
                                                            "layout": "vertical",
                                                            "margin": "lg",
                                                            "spacing": "sm",
                                                            "contents": [{
                                                                    "type": "box",
                                                                    "layout": "baseline",
                                                                    "spacing": "sm",
                                                                    "contents": [{
                                                                            "type": "text",
                                                                            "text": "Group",
                                                                            "align": "center",
                                                                            "color": "{}".format(setbot["text"]),
                                                                            "wrap": True,
                                                                            "size": "sm",
                                "action" : {
  "type" : "uri", "uri" : "line://app/1643727178-0XPGAaRX?type=fotext&text=Group"}, 
                                                                            "flex": 0
                                                                        },{
                                                                            "type": "text",
                                                                            "text": "Mention",
                                                                            "align": "center",
                                                                            "color": "{}".format(setbot["text"]),
                                                                            "size": "sm",
                                "action" : {
  "type" : "uri", "uri" : "line://app/1643727178-0XPGAaRX?type=fotext&text=Mention"}, 
                                                                            "flex": 5
                                                                 },{
                                                                            "type": "text",
                                                                            "text": "Steal",
                                                                            "align": "center",
                                                                            "color": "{}".format(setbot["text"]),
                                                                            "size": "sm",
                                "action" : {
  "type" : "uri", "uri" : "line://app/1643727178-0XPGAaRX?type=fotext&text=Steal"}, 
                                                                            "flex": 0
}]}]},
                                                        {
                                                            "type": "box",
                                                            "layout": "vertical",
                                                            "margin": "lg",
                                                            "spacing": "sm",
                                                            "contents": [{
                                                                    "type": "box",
                                                                    "layout": "baseline",
                                                                    "spacing": "sm",
                                                                    "contents": [{
                                                                            "type": "text",
                                                                            "text": "List",
                                                                            "align": "center",
                                                                            "color": "{}".format(setbot["text"]),
                                                                            "wrap": True,
                                                                            "size": "sm",
                                "action" : {
  "type" : "uri", "uri" : "line://app/1643727178-0XPGAaRX?type=fotext&text=List"}, 
                                                                            "flex": 0
                                                                        },{
                                                                            "type": "text",
                                                                            "text": "Bcast",
                                                                            "align": "center",
                                                                            "color": "{}".format(setbot["text"]),
                                                                            "size": "sm",
                                "action" : {
  "type" : "uri", "uri" : "line://app/1643727178-0XPGAaRX?type=fotext&text=Bcast"}, 
                                                                            "flex": 5
                                                                 },{
                                                                            "type": "text",
                                                                            "text": "Leave",
                                                                            "align": "center",
                                                                            "color": "{}".format(setbot["text"]),
                                                                            "size": "sm",
                                "action" : {
  "type" : "uri", "uri" : "line://app/1643727178-0XPGAaRX?type=fotext&text=Leave"}, 
                                                                            "flex": 0
}]}]},
                                                        {
                                                            "type": "box",
                                                            "layout": "vertical",
                                                            "margin": "lg",
                                                            "spacing": "sm",
                                                            "contents": [{
                                                                    "type": "box",
                                                                    "layout": "baseline",
                                                                    "spacing": "sm",
                                                                    "contents": [{
                                                                            "type": "text",
                                                                            "text": "Reboot",
                                                                            "align": "center",
                                                                            "color": "{}".format(setbot["text"]),
                                                                            "wrap": True,
                                                                            "size": "sm",
                                "action" : {
  "type" : "uri", "uri" : "line://app/1643727178-0XPGAaRX?type=fotext&text=Reboot"}, 
                                                                            "flex": 0
                                                                        },{
                                                                            "type": "text",
                                                                            "text": "Timeleft",
                                                                            "align": "center",
                                                                            "color": "{}".format(setbot["text"]),
                                                                            "size": "sm",
                                "action" : {
  "type" : "uri", "uri" : "line://app/1643727178-0XPGAaRX?type=fotext&text=Timeleft"}, 
                                                                            "flex": 5
                                                                 },{
                                                                            "type": "text",
                                                                            "text": "Logout",
                                                                            "align": "center",
                                                                            "color": "{}".format(setbot["text"]),
                                                                            "size": "sm",
                                "action" : {
  "type" : "uri", "uri" : "line://app/1643727178-0XPGAaRX?type=fotext&text=Logout"}, 
                                                                            "flex": 0
}]}]},
]},"footer": {"type": "box","layout": "vertical","spacing": "sm",
                                                    "contents": [{"type": "text","align": "center",
                                                                            "text": "USAGE : CLICK OR TYPE",
                                                                            "color": "{}".format(setbot["text"]),
                                                                            "wrap": True,
                                                                            "size": "sm",
                                "action" : {
  "type" : "uri", "uri" : "https://line.me/ti/p/~khiewuzzheree"} },{
                                                            "type": "spacer",
                                                            "size": "sm",
                                                        }],
                                                    "flex": 0
                                                }},}
    sendTemplate(to, data)
def youtubeSearchV3(to, query):
        r = requests.get("https://www.googleapis.com/youtube/v3/search?part=snippet&maxResults=10&q={}&type=video&key=AIzaSyAF-_5PLCt8DwhYc7LBskesUnsm1gFHSP8".format(query))
        data = r.text
        a = json.loads(data)
        if a["items"] != []:
            ret_ = []
            yt = []
            for music in a["items"]:
                link = music['id']['videoId']
                link = 'https://youtu.be/%s' % link
                ret_.append({
                    "type": "bubble",
                    "header": {
                      "type": "box",
                      "layout": "horizontal",
                      "contents": [{
                        "type": "text",
                        "text": "Hello World",
                        "weight": "bold",
                        "color": "#aaaaaa",
                        "size": "sm"
                      }]
                    },
                    "footer": {
                        "type": "box",
                        "contents": [{
                            "type": "text",
                            "text": "MP4",
                            "action": {
                                "type": "uri",
                                "uri": "line://app/1602687308-GXq4Vvk9?type=text&text=%s" % urllib.parse.quote('Youtubemp4 %s' % (link))
                            },
                            "wrap": True,
                            "color": "#aaaaaa",
                            "size": "xs",
                            "align": "center",
                            "weight": "bold"
                        }, {
                            "type": "separator",
                            "color": "#ffffff"
                        }, {
                            "type": "text",
                            "text": "MP3",
                            "action": {
                                "type": "uri",
                                "uri": "line://app/1602687308-GXq4Vvk9?type=text&text=%s" % urllib.parse.quote('Youtubemp3 %s' % (link))
                            },
                            "wrap": True,
                            "color": "#aaaaaa",
                            "size": "xs",
                            "align": "center",
                            "weight": "bold"
                        }],
                        "layout": "horizontal"
                    },
                    "styles": {
                        "footer": {
                            "backgroundColor": "{}".format(setbot["background"])
                        },
                        "body": {
                            "backgroundColor": "{}".format(setbot["background"])
                        },
                        "header": {
                          "backgroundColor": "{}".format(setbot["background"])
                        }
                    },
                    "hero": {
                        "type": "image",
                        "url": "https://i.ytimg.com/vi/%s/maxresdefault.jpg" % music['id']['videoId'],
                        "size": "full",
                        "aspectRatio": "4:3"
                    },
                    "body": {
                        "type": "box",
                        "spacing": "md",
                        "layout": "horizontal",
                        "contents": [{
                            "type": "box",
                            "spacing": "none",
                            "flex": 1,
                            "layout": "vertical",
                            "contents": [{
                                "type": "image",
                                "url": "https://cdn2.iconfinder.com/data/icons/social-icons-circular-color/512/youtube-512.png",
                                "aspectMode": "cover",
                                "gravity": "bottom",
                                "size": "sm",
                                "aspectRatio": "1:1",
                                "action": {
                                  "type": "uri",
                                  "uri": "https://www.youtube.com/watch?v=%s" % music['id']['videoId']
                                }
                            }]
                        }, {
                            "type": "separator",
                            "color": "#ffffff"
                        }, {
                            "type": "box",
                            "contents": [{
                                "type": "text",
                                "text": "Title",
                                "color": "#aaaaaa",
                                "size": "md",
                                "weight": "bold",
                                "flex": 1,
                                "gravity": "top"
                            }, {
                                "type": "text",
                                "text": "%s" % music['snippet']['title'],
                                "color": "#ffffff",
                                "size": "sm",
                                "weight": "bold",
                                "flex": 3,
                                "wrap": True,
                                "gravity": "top"
                            }],
                            "flex": 2,
                            "layout": "vertical"
                        }]
                    }
                  }
            )
                yt.append('https://www.youtube.com/watch?v=' +music['id']['videoId'])
            k = len(ret_)//10
            for aa in range(k+1):
                data = {
                        "type": "carousel",
                        "contents": ret_[aa*10 : (aa+1)*10]
                }
                sendFlex(to, '%s sent a youtube' % noobcoder.getContact(noobcoderMID).displayName ,data)
def sendFlex(to,altText,data):
    dataa = {
        'messages': [ 
    {
        'type': 'flex',
        'altText': altText,
        'contents': data
    }]}
    datta = json.dumps(dataa)
    xyz = LiffChatContext(to)
    xyzz = LiffContext(chat=xyz)
    view = LiffViewRequest('1602687308-GXq4Vvk9', xyzz)
    token = noobcoder.liff.issueLiffView(view)
    url = 'https://api.line.me/message/v3/share'
    headers = {
        'Content-Type': 'application/json',
        'Authorization': 'Bearer %s' % token.accessToken
    }
    return requests.post(url, data=datta, headers=headers)
def mosinglol(to, isi):
    contact = noobcoder.getContact(noobcoderMID)
    gifnya = ['#FFFFFF','#FF0032']
    true = True
    kontol = {
	    "type": "bubble",
	    "styles": {
		    "hero": {"backgroundColor":"{}".format(setbot["background"])},
		    "body": {"backgroundColor": "{}".format(setbot["background"])},
		    "header": {"backgroundColor": "#FFFFFF"},
		    "footer": {
			    "backgroundColor": "#FFFFFF",
			    "separatorColor": "{}".format(setbot["background"]),
			    "separator": True
		    }
	    },
       "body": {
            "type": "box",
            "layout": "vertical",
            "contents": [
        		{
				    "type": "box",
				    "layout": "baseline",
				    "contents": [
                       {
                          "type": "text",
                           "text": isi,
                           "wrap": True,
                           "align": "start",
                           "gravity": "center",
                           "color": "{}".format(random.choice(gifnya)),
                           "size": "sm",
                           "flex": 0
                        },
                        {
                            "type": "icon",
                            "size": "sm",
                            "url": "https://scdn.line-apps.com/n/channel_devcenter/img/fx/review_gold_star_28.png"
                        },
                        {
                            "type": "icon",
                            "size": "sm",
                            "url": "https://scdn.line-apps.com/n/channel_devcenter/img/fx/review_gold_star_28.png"
                        },
                        {
                            "type": "icon",
                            "size": "sm",
                            "url": "https://scdn.line-apps.com/n/channel_devcenter/img/fx/review_gold_star_28.png"
                        },
                        {
                            "type": "icon",
                            "size": "sm",
                            "url": "https://scdn.line-apps.com/n/channel_devcenter/img/fx/review_gold_star_28.png"
                        },
                        {
                            "type": "icon",
                            "size": "sm",
                            "url": "https://scdn.line-apps.com/n/channel_devcenter/img/fx/review_gold_star_28.png"
                        },
                        {
                            "type": "icon",
                            "size": "sm",
                            "url": "https://scdn.line-apps.com/n/channel_devcenter/img/fx/review_gray_star_28.png"
                        }
				    ]
			    }
		    ]
        },
        "footer": {
            "type": "box",
            "layout": "vertical",
            "spacing": "sm",
            "contents": [
                {
                    "type": "box",
                    "layout": "baseline",
                    "contents": [
                        {
                            "type": "icon",
                            "url": "https://i.ibb.co/jrrMPdG/1553179449707.jpg",
                            "size": "md"
                        },
                        {
                            "type": "text",
                            "text": "FREE SELFBOT",
                            "align": "center",
                            "color": "{}".format(setbot["background"]),
                            "size": "md"
                        },
                        {
                            "type": "spacer",
                            "size": "sm",
                        }
                    ]
                }
            ]
        }                         
    }
    data = {"type":"flex","altText":"KhieWasHere","contents":kontol}
    sendTemplate(to, data)

def mosing1(to, isi):
    true = True
    data = {
        "type": "flex",
        "altText": "NOOB CODER™",
        "contents": {
            "type": "bubble",
            "styles": {
                "header": {
                    "backgroundColor": "#000000",
                },
                "hero": {
                    "backgroundColor": "#000000"
                },
                "body": {
                    "backgroundColor": "#000000",
                    "separator": True,
                    "separatorColor": "#000000",
                }
            },
            "body": {
                "type": "box",
                "layout": "vertical",
                "cornerRadius": "xl",
                "borderWidth": "4px",
                "borderColor": "{}".format(setbot["separator"]),
                "contents": [
                  {
                    "type": "box",
                    "layout": "vertical",
                    "contents": [
                      {
                        "type": "image",
                        "url": "https://i.ibb.co/jrrMPdG/1553179449707.jpg",
                        "aspectMode": "cover",
                        "size": "full"
                      }
                    ],
                    "cornerRadius": "100px",
                    "width": "72px",
                    "height": "72px"
                    },
                    {
                        "type": "separator",
                        "color": "{}".format(setbot["separator"]),
                        "margin": "xxl"
                    },
                    {
                        "type": "box",
                        "layout": "vertical",
                        "margin": "xxl",
                        "spacing": "sm",
                        "contents": [
                            {                                
                                "type": "box",
                                "layout": "horizontal",
                                "contents": [
                                    {
                                        "type": "text",
                                        "text": isi,
                                        "wrap": True,
                                        "align": "start",
                                        "gravity": "center",
                                        "weight": "bold",
                                        "color": "{}".format(setbot["text"]),
                                        "size": "sm"
                                    }
                                ],
                            },
                            {
                                "type": "separator",
                                "color": "{}".format(setbot["separator"]),
                                "margin":"md"
                            }
                        ]                        
                    }
                ]
            }
        }
    }
    sendTemplate(to, data)
def mosingxx(to, isi):
    true = True
    data={"type":"flex","altText":"NOOB CODER™","contents":{
  "type": "bubble",
  "body": {
    "type": "box",
    "layout": "vertical",
    "contents": [
      {
        "type": "box",
        "layout": "vertical",
        "contents": [
          {
            "type": "box",
            "layout": "baseline",
            "contents": [
              {
                "type": "icon",
                "url": "https://scdn.line-apps.com/n/channel_devcenter/img/fx/review_gold_star_28.png",
                "offsetStart": "20px"
              },
              {
                "type": "text",
                "text": "FREE SELFBOT",
                "size": "xl",
                "color": "{}".format(setbot["text"]),
                "weight": "bold",
                "align": "center"
              },
              {
                "type": "icon",
                "url": "https://scdn.line-apps.com/n/channel_devcenter/img/fx/review_gold_star_28.png",
                "offsetEnd": "20px"
              }
            ],
            "borderColor": "{}".format(setbot["separator"]),
            "borderWidth": "2px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "spacer",
                "size": "xxl"
              }
            ]
          },
          {
            "type": "separator",
            "color": "{}".format(setbot["separator"])
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "spacer",
                "size": "xxl"
              },
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "text",
                    "text": isi,
                    "weight": "bold",
                    "align": "start",
                    "gravity": "center",
                    "wrap": true,
                    "color": "{}".format(setbot["text"]),
                    "size": "sm"
                  }
                ]
              }
            ]
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "spacer"
              }
            ]
          },
          {
            "type": "separator",
            "color": "{}".format(setbot["separator"])
          }
        ]
      }
    ],
    "cornerRadius": "xl",
    "borderColor": "{}".format(setbot["separator"]),
    "borderWidth": "4px"
  },
  "styles": {
    "body": {
      "backgroundColor":"{}".format(setbot["background"])
    }
  }
}}
    sendTemplate(to, data)
def mosing(to, isi):
    true=True
    data={"type":"flex","altText":"NOOB CODER™","contents":{
  "type": "bubble",
  "body": {
    "type": "box",
    "layout": "vertical",
    "contents": [
      {
        "type": "box",
        "layout": "horizontal",
        "contents": [
          {
            "type": "box",
            "layout": "horizontal",
            "contents": [
              {
                "type": "image",
                "url": "https://i.ibb.co/jrrMPdG/1553179449707.jpg"
              }
            ],
            "width": "40px",
            "height": "40px",
            "borderWidth": "2px",
            "borderColor": "{}".format(setbot["separator"]),
            "cornerRadius": "100px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "FREE SELFBOT",
                "weight": "bold",
                "size": "xl",
                "color": "{}".format(setbot["text"]),
                "wrap": true
              }
            ],
            "margin": "lg"
          }
        ]
      },
      {
        "type": "box",
        "layout": "vertical",
        "contents": [
          {
            "type": "spacer",
            "size": "lg"
          },
          {
            "type": "separator",
            "color": "{}".format(setbot["separator"])
          },
          {
            "type": "spacer",
            "size": "lg"
          }
        ],
        "margin": "md"
      },
      {
        "type": "box",
        "layout": "vertical",
        "contents": [
          {
            "type": "text",
            "text": isi, 
            "size": "sm",
            "weight": "bold",
            "wrap": true,
            "align": "start",
            "gravity": "center",
            "color": "{}".format(setbot["text"])
          }
        ]
      },
      {
        "type": "box",
        "layout": "vertical",
        "contents": [
          {
            "type": "spacer",
            "size": "lg"
          },
          {
            "type": "separator",
            "color": "{}".format(setbot["separator"])
          }
        ]
      }
    ],
    "borderWidth": "4px",
    "borderColor": "{}".format(setbot["separator"]),
    "cornerRadius": "xl"
  },
  "styles": {
    "body": {
      "backgroundColor":"{}".format(setbot["background"])
    }
  }
}}
    sendTemplate(to, data)

def helpalay(to):
    data={"type":"flex","altText":"NOOB CODER™","contents":{
  "type": "carousel",
  "contents": [
    {
  "type": "bubble",
  "body": {
    "type": "box",
    "layout": "vertical",
    "borderWidth": "4px",
    "borderColor": "{}".format(setbot["helpseparator"]),
    "cornerRadius": "xl",
    "contents": [
      {
        "type": "image",
        "url": "https://i.ibb.co/fYLky4k/1573042360208.png",
        "size": "full",
        "aspectMode": "cover",
        "aspectRatio": "1:1",
        "gravity": "center"
      },
      {
        "type": "box",
        "layout": "horizontal",
        "contents": [
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "text",
                    "text": "NOOB CODER™",
                    "size": "lg",
                    "color": "{}".format(setbot["text"]),
                    "weight": "bold",
                    "align": "center",
                    "offsetStart": "15px"
                  }
                ]
              },
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "text",
                    "text": "Selfbots Edition",
                    "size": "sm",
                    "color": "{}".format(setbot["text"]),
                    "weight": "bold",
                    "align": "center"
                  }
                ]
              },
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "spacer"
                  }
                ],
                "margin": "xs"
              },
              {
                "type": "box",
                "layout": "horizontal",
                "contents": [
                  {
                    "type": "filler"
                  },
                  {
                    "type": "box",
                    "layout": "vertical",
                    "contents": [
                      {
                        "type": "text",
                        "text": "Chatbot",
                        "size": "sm",
                        "color": "{}".format(setbot["helptext"]),
                        "align": "center",
                        "action": {
                          "type": "uri",
                          "label": "action",
                          "uri": "line://app/1643727178-0XPGAaRX?type=fotext&text=Feature"
                        }
                      }
                    ],
                    "offsetStart": "0px"
                  },
                  {
                    "type": "filler"
                  },
                  {
                    "type": "box",
                    "layout": "vertical",
                    "contents": [
                      {
                        "type": "text",
                        "text": "Feature",
                        "size": "sm",
                        "color": "{}".format(setbot["helptext"]),
                        "align": "center",
                        "action": {
                          "type": "uri",
                          "label": "action",
                          "uri": "line://app/1643727178-0XPGAaRX?type=fotext&text=Feature"
                        }
                      }
                    ],
                    "offsetStart": "10px"
                  },
                  {
                    "type": "filler"
                  }
                ],
                "margin": "md"
              },
              {
                "type": "box",
                "layout": "horizontal",
                "contents": [
                  {
                    "type": "filler"
                  },
                  {
                    "type": "box",
                    "layout": "vertical",
                    "contents": [
                      {
                        "type": "text",
                        "text": "Images",
                        "size": "sm",
                        "color": "{}".format(setbot["helptext"]),
                        "align": "center",
                        "action": {
                          "type": "uri",
                          "label": "action",
                          "uri": "line://app/1643727178-0XPGAaRX?type=fotext&text=Images"
                        }
                      },
                      {
                        "type": "spacer"
                      }
                    ],
                    "offsetStart": "0px"
                  },
                  {
                    "type": "filler"
                  },
                  {
                    "type": "box",
                    "layout": "vertical",
                    "contents": [
                      {
                        "type": "text",
                        "text": "Profile",
                        "size": "sm",
                        "color": "{}".format(setbot["helptext"]),
                        "align": "center",
                        "action": {
                          "type": "uri",
                          "label": "action",
                          "uri": "line://app/1643727178-0XPGAaRX?type=fotext&text=Profile"
                        }
                      }
                    ],
                    "offsetStart": "10px"
                  },
                  {
                    "type": "filler"
                  }
                ],
                "margin": "xl"
              },
              {
                "type": "box",
                "layout": "horizontal",
                "contents": [
                  {
                    "type": "filler"
                  },
                  {
                    "type": "box",
                    "layout": "vertical",
                    "contents": [
                      {
                        "type": "text",
                        "text": "Protect",
                        "size": "sm",
                        "color": "{}".format(setbot["helptext"]),
                        "align": "center",
                        "action": {
                          "type": "uri",
                          "label": "action",
                          "uri": "line://app/1643727178-0XPGAaRX?type=fotext&text=Protect"
                        }
                      }
                    ],
                    "offsetStart": "0px"
                  },
                  {
                    "type": "filler"
                  },
                  {
                    "type": "box",
                    "layout": "vertical",
                    "contents": [
                      {
                        "type": "text",
                        "text": "Social",
                        "size": "sm",
                        "color": "{}".format(setbot["helptext"]),
                        "align": "center",
                        "action": {
                          "type": "uri",
                          "label": "action",
                          "uri": "line://app/1643727178-0XPGAaRX?type=fotext&text=Social"
                        }
                      }
                    ],
                    "offsetStart": "10px"
                  },
                  {
                    "type": "filler"
                  }
                ],
                "margin": "sm"
              },
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "spacer",
                    "size": "xxl"
                  },
                  {
                    "type": "filler"
                  },
                  {
                    "type": "box",
                    "layout": "vertical",
                    "contents": [
                      {
                        "type": "text",
                        "text": "Translate",
                        "color": "{}".format(setbot["helptext"]),
                        "align": "center",
                        "action": {
                          "type": "uri",
                          "label": "action",
                          "uri": "line://app/1643727178-0XPGAaRX?type=fotext&text=Translate"
                        }
                      }
                    ],
                    "margin": "lg",
                    "offsetEnd": "20px"
                  },
                  {
                    "type": "box",
                    "layout": "horizontal",
                    "contents": [
                      {
                        "type": "filler"
                      },
                      {
                        "type": "box",
                        "layout": "vertical",
                        "contents": [
                          {
                            "type": "text",
                            "text": "Timeline",
                            "size": "sm",
                            "color": "{}".format(setbot["helptext"]),
                            "align": "center",
                            "action": {
                              "type": "uri",
                              "label": "action",
                              "uri": "line://app/1643727178-0XPGAaRX?type=fotext&text=Timeline"
                            }
                          }
                        ],
                        "offsetEnd": "20px"
                      },
                      {
                        "type": "filler"
                      },
                      {
                        "type": "box",
                        "layout": "vertical",
                        "contents": [
                          {
                            "type": "text",
                            "text": "Settings",
                            "size": "sm",
                            "color": "{}".format(setbot["helptext"]),
                            "align": "center",
                            "action": {
                              "type": "uri",
                              "label": "action",
                              "uri": "line://app/1643727178-0XPGAaRX?type=fotext&text=Settings"
                            }
                          }
                        ],
                        "offsetEnd": "40px"
                      },
                      {
                        "type": "filler"
                      }
                    ],
                    "margin": "md"
                  }
                ],
                "margin": "md"
              },
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "filler"
                  }
                ],
                "margin": "sm"
              }
            ],
            "spacing": "xs"
          }
        ],
        "position": "absolute",
        "offsetBottom": "0px",
        "offsetStart": "0px",
        "offsetEnd": "0px",
        "paddingAll": "20px"
      }
    ],
    "paddingAll": "0px"
  }
},
{

  "type": "bubble",
  "body": {
    "type": "box",
    "layout": "vertical",
    "borderWidth": "4px",
    "borderColor": "{}".format(setbot["helpseparator"]),
    "cornerRadius": "xl",
    "contents": [
      {
        "type": "image",
        "url": "https://i.ibb.co/fYLky4k/1573042360208.png",
        "size": "full",
        "aspectMode": "cover",
        "aspectRatio": "1:1",
        "gravity": "center"
      },
      {
        "type": "box",
        "layout": "horizontal",
        "contents": [
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "text",
                    "text": "NOOB CODER™",
                    "size": "lg",
                    "color": "{}".format(setbot["text"]),
                    "weight": "bold",
                    "align": "center",
                    "offsetStart": "15px"
                  }
                ]
              },
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "text",
                    "text": "Selfbots Edition",
                    "size": "sm",
                    "color": "{}".format(setbot["text"]),
                    "weight": "bold",
                    "align": "center"
                  }
                ]
              },
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "spacer"
                  }
                ],
                "margin": "xs"
              },
              {
                "type": "box",
                "layout": "horizontal",
                "contents": [
                  {
                    "type": "filler"
                  },
                  {
                    "type": "box",
                    "layout": "vertical",
                    "contents": [
                      {
                        "type": "text",
                        "text": "Banning",
                        "size": "sm",
                        "color": "{}".format(setbot["helptext"]),
                        "align": "center",
                        "action": {
                          "type": "uri",
                          "label": "action",
                          "uri": "line://app/1643727178-0XPGAaRX?type=fotext&text=Banning"
                        }
                      }
                    ],
                    "offsetStart": "0px"
                  },
                  {
                    "type": "filler"
                  },
                  {
                    "type": "box",
                    "layout": "vertical",
                    "contents": [
                      {
                        "type": "text",
                        "text": "Wordban",
                        "size": "sm",
                        "color": "{}".format(setbot["helptext"]),
                        "align": "center",
                        "action": {
                          "type": "uri",
                          "label": "action",
                          "uri": "line://app/1643727178-0XPGAaRX?type=fotext&text=Wordban"
                        }
                      }
                    ],
                    "offsetStart": "10px"
                  },
                  {
                    "type": "filler"
                  }
                ],
                "margin": "md"
              },
              {
                "type": "box",
                "layout": "horizontal",
                "contents": [
                  {
                    "type": "filler"
                  },
                  {
                    "type": "box",
                    "layout": "vertical",
                    "contents": [
                      {
                        "type": "text",
                        "text": "Friend",
                        "size": "sm",
                        "color": "{}".format(setbot["helptext"]),
                        "align": "center",
                        "action": {
                          "type": "uri",
                          "label": "action",
                          "uri": "line://app/1643727178-0XPGAaRX?type=fotext&text=Friend"
                        }
                      },
                      {
                        "type": "spacer"
                      }
                    ],
                    "offsetStart": "0px"
                  },
                  {
                    "type": "filler"
                  },
                  {
                    "type": "box",
                    "layout": "vertical",
                    "contents": [
                      {
                        "type": "text",
                        "text": "Self",
                        "size": "sm",
                        "color": "{}".format(setbot["helptext"]),
                        "align": "center",
                        "action": {
                          "type": "uri",
                          "label": "action",
                          "uri": "line://app/1643727178-0XPGAaRX?type=fotext&text=Self"
                        }
                      }
                    ],
                    "offsetStart": "10px"
                  },
                  {
                    "type": "filler"
                  }
                ],
                "margin": "xl"
              },
              {
                "type": "box",
                "layout": "horizontal",
                "contents": [
                  {
                    "type": "filler"
                  },
                  {
                    "type": "box",
                    "layout": "vertical",
                    "contents": [
                      {
                        "type": "text",
                        "text": "Memegen",
                        "size": "sm",
                        "color": "{}".format(setbot["helptext"]),
                        "align": "center",
                        "action": {
                          "type": "uri",
                          "label": "action",
                          "uri": "line://app/1643727178-0XPGAaRX?type=fotext&text=Memegen"
                        }
                      }
                    ],
                    "offsetStart": "0px"
                  },
                  {
                    "type": "filler"
                  },
                  {
                    "type": "box",
                    "layout": "vertical",
                    "contents": [
                      {
                        "type": "text",
                        "text": "Kick",
                        "size": "sm",
                        "color": "{}".format(setbot["helptext"]),
                        "align": "center",
                        "action": {
                          "type": "uri",
                          "label": "action",
                          "uri": "line://app/1643727178-0XPGAaRX?type=fotext&text=Kick"
                        }
                      }
                    ],
                    "offsetStart": "10px"
                  },
                  {
                    "type": "filler"
                  }
                ],
                "margin": "sm"
              },
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "spacer",
                    "size": "xxl"
                  },
                  {
                    "type": "filler"
                  },
                  {
                    "type": "box",
                    "layout": "vertical",
                    "contents": [
                      {
                        "type": "text",
                        "text": "Utility",
                        "color": "{}".format(setbot["helptext"]),
                        "align": "center",
                        "action": {
                          "type": "uri",
                          "label": "action",
                          "uri": "line://app/1643727178-0XPGAaRX?type=fotext&text=Utility"
                        }
                      }
                    ],
                    "margin": "lg",
                    "offsetEnd": "20px"
                  },
                  {
                    "type": "box",
                    "layout": "horizontal",
                    "contents": [
                      {
                        "type": "filler"
                      },
                      {
                        "type": "box",
                        "layout": "vertical",
                        "contents": [
                          {
                            "type": "text",
                            "text": "Github",
                            "size": "sm",
                            "color": "{}".format(setbot["helptext"]),
                            "align": "center",
                            "action": {
                              "type": "uri",
                              "label": "action",
                              "uri": "line://app/1643727178-0XPGAaRX?type=fotext&text=Github"
                            }
                          }
                        ],
                        "offsetEnd": "20px"
                      },
                      {
                        "type": "filler"
                      },
                      {
                        "type": "box",
                        "layout": "vertical",
                        "contents": [
                          {
                            "type": "text",
                            "text": "About",
                            "size": "sm",
                            "color": "{}".format(setbot["helptext"]),
                            "align": "center",
                            "action": {
                              "type": "uri",
                              "label": "action",
                              "uri": "line://app/1643727178-0XPGAaRX?type=fotext&text=About"
                            }
                          }
                        ],
                        "offsetEnd": "40px"
                      },
                      {
                        "type": "filler"
                      }
                    ],
                    "margin": "md"
                  }
                ],
                "margin": "md"
              },
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "filler"
                  }
                ],
                "margin": "sm"
              }
            ],
            "spacing": "xs"
          }
        ],
        "position": "absolute",
        "offsetBottom": "0px",
        "offsetStart": "0px",
        "offsetEnd": "0px",
        "paddingAll": "20px"
      }
    ],
    "paddingAll": "0px"
  }
},
{

  "type": "bubble",
  "body": {
    "type": "box",
    "layout": "vertical",
    "borderWidth": "4px",
    "borderColor": "{}".format(setbot["helpseparator"]),
    "cornerRadius": "xl",
    "contents": [
      {
        "type": "image",
        "url": "https://i.ibb.co/fYLky4k/1573042360208.png",
        "size": "full",
        "aspectMode": "cover",
        "aspectRatio": "1:1",
        "gravity": "center"
      },
      {
        "type": "box",
        "layout": "horizontal",
        "contents": [
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "text",
                    "text": "NOOB CODER™",
                    "size": "lg",
                    "color": "{}".format(setbot["text"]),
                    "weight": "bold",
                    "align": "center",
                    "offsetStart": "15px"
                  }
                ]
              },
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "text",
                    "text": "Selfbots Edition",
                    "size": "sm",
                    "color": "{}".format(setbot["text"]),
                    "weight": "bold",
                    "align": "center"
                  }
                ]
              },
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "spacer"
                  }
                ],
                "margin": "xs"
              },
              {
                "type": "box",
                "layout": "horizontal",
                "contents": [
                  {
                    "type": "filler"
                  },
                  {
                    "type": "box",
                    "layout": "vertical",
                    "contents": [
                      {
                        "type": "text",
                        "text": "Group",
                        "size": "sm",
                        "color": "{}".format(setbot["helptext"]),
                        "align": "center",
                        "action": {
                          "type": "uri",
                          "label": "action",
                          "uri": "line://app/1643727178-0XPGAaRX?type=fotext&text=Group"
                        }
                      }
                    ],
                    "offsetStart": "0px"
                  },
                  {
                    "type": "filler"
                  },
                  {
                    "type": "box",
                    "layout": "vertical",
                    "contents": [
                      {
                        "type": "text",
                        "text": "Mention",
                        "size": "sm",
                        "color": "{}".format(setbot["helptext"]),
                        "align": "center",
                        "action": {
                          "type": "uri",
                          "label": "action",
                          "uri": "line://app/1643727178-0XPGAaRX?type=fotext&text=Mention"
                        }
                      }
                    ],
                    "offsetStart": "10px"
                  },
                  {
                    "type": "filler"
                  }
                ],
                "margin": "md"
              },
              {
                "type": "box",
                "layout": "horizontal",
                "contents": [
                  {
                    "type": "filler"
                  },
                  {
                    "type": "box",
                    "layout": "vertical",
                    "contents": [
                      {
                        "type": "text",
                        "text": "Steal",
                        "size": "sm",
                        "color": "{}".format(setbot["helptext"]),
                        "align": "center",
                        "action": {
                          "type": "uri",
                          "label": "action",
                          "uri": "line://app/1643727178-0XPGAaRX?type=fotext&text=Steal"
                        }
                      },
                      {
                        "type": "spacer"
                      }
                    ],
                    "offsetStart": "0px"
                  },
                  {
                    "type": "filler"
                  },
                  {
                    "type": "box",
                    "layout": "vertical",
                    "contents": [
                      {
                        "type": "text",
                        "text": "List",
                        "size": "sm",
                        "color": "{}".format(setbot["helptext"]),
                        "align": "center",
                        "action": {
                          "type": "uri",
                          "label": "action",
                          "uri": "line://app/1643727178-0XPGAaRX?type=fotext&text=List"
                        }
                      }
                    ],
                    "offsetStart": "10px"
                  },
                  {
                    "type": "filler"
                  }
                ],
                "margin": "xl"
              },
              {
                "type": "box",
                "layout": "horizontal",
                "contents": [
                  {
                    "type": "filler"
                  },
                  {
                    "type": "box",
                    "layout": "vertical",
                    "contents": [
                      {
                        "type": "text",
                        "text": "Bcast",
                        "size": "sm",
                        "color": "{}".format(setbot["helptext"]),
                        "align": "center",
                        "action": {
                          "type": "uri",
                          "label": "action",
                          "uri": "line://app/1643727178-0XPGAaRX?type=fotext&text=Bcast"
                        }
                      }
                    ],
                    "offsetStart": "0px"
                  },
                  {
                    "type": "filler"
                  },
                  {
                    "type": "box",
                    "layout": "vertical",
                    "contents": [
                      {
                        "type": "text",
                        "text": "Leave",
                        "size": "sm",
                        "color": "{}".format(setbot["helptext"]),
                        "align": "center",
                        "action": {
                          "type": "uri",
                          "label": "action",
                          "uri": "line://app/1643727178-0XPGAaRX?type=fotext&text=Leave"
                        }
                      }
                    ],
                    "offsetStart": "10px"
                  },
                  {
                    "type": "filler"
                  }
                ],
                "margin": "sm"
              },
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "spacer",
                    "size": "xxl"
                  },
                  {
                    "type": "filler"
                  },
                  {
                    "type": "box",
                    "layout": "vertical",
                    "contents": [
                      {
                        "type": "text",
                        "text": "Reboot",
                        "color": "{}".format(setbot["helptext"]),
                        "align": "center",
                        "action": {
                          "type": "uri",
                          "label": "action",
                          "uri": "line://app/1643727178-0XPGAaRX?type=fotext&text=Reboot"
                        }
                      }
                    ],
                    "margin": "lg",
                    "offsetEnd": "20px"
                  },
                  {
                    "type": "box",
                    "layout": "horizontal",
                    "contents": [
                      {
                        "type": "filler"
                      },
                      {
                        "type": "box",
                        "layout": "vertical",
                        "contents": [
                          {
                            "type": "text",
                            "text": "Timeleft",
                            "size": "sm",
                            "color": "{}".format(setbot["helptext"]),
                            "align": "center",
                            "action": {
                              "type": "uri",
                              "label": "action",
                              "uri": "line://app/1643727178-0XPGAaRX?type=fotext&text=Timeleft"
                            }
                          }
                        ],
                        "offsetEnd": "20px"
                      },
                      {
                        "type": "filler"
                      },
                      {
                        "type": "box",
                        "layout": "vertical",
                        "contents": [
                          {
                            "type": "text",
                            "text": "Logout",
                            "size": "sm",
                            "color": "{}".format(setbot["helptext"]),
                            "align": "center",
                            "action": {
                              "type": "uri",
                              "label": "action",
                              "uri": "line://app/1643727178-0XPGAaRX?type=fotext&text=Logout"
                            }
                          }
                        ],
                        "offsetEnd": "40px"
                      },
                      {
                        "type": "filler"
                      }
                    ],
                    "margin": "md"
                  }
                ],
                "margin": "md"
              },
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "filler"
                  }
                ],
                "margin": "sm"
              }
            ],
            "spacing": "xs"
          }
        ],
        "position": "absolute",
        "offsetBottom": "0px",
        "offsetStart": "0px",
        "offsetEnd": "0px",
        "paddingAll": "20px"
      }
    ],
    "paddingAll": "0px"
  }
}]}}
    sendTemplate(to, data)
    
def mosings(to, isi):
    true = True
    data = {
        "type": "flex",
        "altText": "NOOB CODER™",
        "contents": {
            "type": "bubble",
            "styles": {
                "header": {
                    "backgroundColor": "#000000",
                },
                "hero": {
                    "backgroundColor": "#000000"
                },
                "body": {
                    "backgroundColor": "#000000",
                    "separator": True,
                    "separatorColor": "#000000",
                },
                "footer": {
                    "backgroundColor": "#000000",
                    "separator": True
                }
            },
            "body": {
                "type": "box",
                "layout": "vertical",
                "cornerRadius": "xl",
                "borderColor":"#FFFFFF",
                "borderColor": "{}".format(setbot["separator"]),
                "contents": [
                    {
                        "type": "image",
                        "url": "https://i.ibb.co/jrrMPdG/1553179449707.jpg",
                        "size": "full",
                        "aspectMode": "cover",
                        "aspectRatio": "1:1",
                        "gravity": "top",
                        "position": "absolute",
                        "offsetBottom": "0px",
                        "offsetStart":"0px",
                        "offsetEnd": "0px",
                    },
                    {
                        "type": "text",
                        "text": "FREE SELFBOT",
                        "weight": "bold",
                        "size": "xxl",
                        "color": "{}".format(setbot["text"]),
                        "margin": "md"
                    },
                    {
                        "type": "text",
                        "text": "Selfbots Edition",
                        "weight": "bold",
                        "size": "sm",
                        "color": "{}".format(setbot["text"]),
                        "wrap": true
                    },
                    {
                        "type": "separator",
                        "color": "{}".format(setbot["separator"]),
                        "margin": "xxl"
                    },
                    {
                        "type": "box",
                        "layout": "vertical",
                        "margin": "xxl",
                        "spacing": "sm",
                        "contents": [
                            {                                
                                "type": "box",
                                "layout": "horizontal",
                                "contents": [
                                    {
                                        "type": "text",
                                        "text": isi,
                                        "wrap": True,
                                        "align": "start",
                                        "gravity": "center",
                                        "weight": "bold",
                                        "color": "{}".format(setbot["text"]),
                                        "size": "sm"
                                    }
                                ],
                            },
                            {
                                "type": "separator",
                                "color": "{}".format(setbot["separator"]),
                                "margin":"md"
                            }
                        ]                        
                    }
                ]
            }
        }
    }
    sendTemplate(to, data)
def mosinga(to, isi):
    true = True
    data = {
        "type": "flex",
        "altText": "NOOB CODER™",
        "contents": {
            "type": "bubble",
            "styles": {
                "header": {
                    "backgroundColor": "{}".format(setbot["background"])
                },
                "hero": {
                    "backgroundColor": "{}".format(setbot["background"])
                },
                "body": {
                    "backgroundColor": "#FFFFFF",
                    "separator": True,
                    "separatorColor": "#FFFFFF"
                },
                "footer": {
                    "backgroundColor": "{}".format(setbot["background"]),
                    "separator": True
                }
            },
            "body": {
                "type": "box",
                "layout": "vertical",
                "contents": [
                    {
                        "url": "https://i.ibb.co/jrrMPdG/1553179449707.jpg",
                        "type": "image"
                    },
                    {
                        "type": "separator",
                        "margin": "xxl"
                    },
                    {
                        "type": "box",
                        "layout": "vertical",
                        "margin": "xxl",
                        "spacing": "sm",
                        "contents": [
                            {
                                "type": "box",
                                "layout": "horizontal",
                                "contents": [
                                    {
                                        "type": "text",
                                        "text": isi,
                                        "wrap": True,
                                        "align": "start",
                                        "gravity": "center",
                                        "weight": "bold",
                                        "color": "{}".format(setbot["background"]),
                                        "size": "sm"
                                    }
                                ]
                            },
                            {
                                "type": "separator",
                                "margin":"md"
                            }
                        ]
                    }
                ]
            }
        }
    }
    sendTemplate(to, data)
def sendTemplate(group, data):
    xyz = LiffChatContext(group)
    xyzz = LiffContext(chat=xyz)
    view = LiffViewRequest('1643727178-0XPGAaRX', xyzz)
    token = noobcoder.liff.issueLiffView(view)
    url = 'https://api.line.me/message/v3/share'
    headers = {
        'Content-Type': 'application/json',
        'Authorization': 'Bearer %s' % token.accessToken
    }
    data = {"messages":[data]}
    requests.post(url, headers=headers, data=json.dumps(data))
def sendTemplate(to, data):
    xyz = LiffChatContext(to)
    xyzz = LiffContext(chat=xyz)
    view = LiffViewRequest('1643727178-0XPGAaRX', xyzz)
    token = noobcoder.liff.issueLiffView(view)
    url = 'https://api.line.me/message/v3/share'
    headers = {
        'Content-Type': 'application/json',
        'Authorization': 'Bearer %s' % token.accessToken
    }
    data = {"messages":[data]}
    requests.post(url, headers=headers, data=json.dumps(data))
def flexin(to, data):
    xyz = LiffChatContext(to)
    xyzz = LiffContext(chat=xyz)
    view = LiffViewRequest('1643727178-0XPGAaRX', xyzz)
    token = noobcoder.liff.issueLiffView(view)
    url = 'https://api.line.me/message/v3/share'
    headers = {
        'Content-Type': 'application/json',
        'Authorization': 'Bearer %s' % token.accessToken
    }
    data = {"messages":[data]}
    requests.post(url, headers=headers, data=json.dumps(data))
def bcTemplate(gr, data):
    xyz = LiffChatContext(gr)
    xyzz = LiffContext(chat=xyz)
    view = LiffViewRequest('1643727178-0XPGAaRX', xyzz)
    token = noobcoder.liff.issueLiffView(view)
    url = 'https://api.line.me/message/v3/share'
    headers = {
        'Content-Type': 'application/json',
        'Authorization': 'Bearer %s' % token.accessToken
    }
    data = {"messages":[data]}
    requests.post(url, headers=headers, data=json.dumps(data))
def bcTemplate2(friend, data):
    xyz = LiffChatContext(friend)
    xyzz = LiffContext(chat=xyz)
    view = LiffViewRequest('1643727178-0XPGAaRX', xyzz)
    token = noobcoder.liff.issueLiffView(view)
    url = 'https://api.line.me/message/v3/share'
    headers = {
        'Content-Type': 'application/json',
        'Authorization': 'Bearer %s' % token.accessToken
    }
    data = {"messages":[data]}
    requests.post(url, headers=headers, data=json.dumps(data))

def sendCarousel(to, data):
    data = json.dumps(data)
    xyz = LiffChatContext(to)
    xyzz = LiffContext(chat=xyz)
    view = LiffViewRequest('1643727178-0XPGAaRX', xyzz)
    token = noobcoder.liff.issueLiffView(view)
    url = 'https://api.line.me/message/v3/share'
    headers = {
        'Content-Type': 'application/json',
        'Authorization': 'Bearer %s' % token.accessToken
    }
    return requests.post(url, data=data, headers=headers)
def nhentai(to,msg,liffnya,cmd):
    try:
        msg.text = cmd
        lururl = 'https://app-1536548990.000webhostapp.com/apis.php?images='
        if ' page ' not in msg.text:return
        if cmd.startswith('nhentai page '):
            k = cmd.split('page ')[1].split(' ')
            website = requests.get("https://nhentai.net?page={}".format(k[0]))
        else:
            h = cmd.split('page ')[0][len('nhentai '):]
            k = cmd.split('page ')[1].split(' ')
            website = requests.get("https://nhentai.net?page={}".format(h,k[0]))
        data = BeautifulSoup(website.content, "lxml")
        dataDoujins = []
        b = ' 「 Nhentai 」'
        ss = []
        hh = []
        gh = []
        gg = []
        ret_ = []
        for listAllDoujins in data.findAll("div", {"class":"container index-container"}):
            for getUrl in listAllDoujins.findAll("div", {"class":"gallery"}):
                for get in getUrl.find_all('a'):gh.append("https://nhentai.net{}".format(get.get('href')))
                for gets in getUrl.find_all('img'):
                    if 'https://t.nhentai.net/galleries/' in gets['src']:
                        gg.append(gets['src'])
                    else:
                        pass
            for getTitle in listAllDoujins.findAll("div", {"class":"caption"}):
                title = getTitle.text
                dataDoujins.append(title)
        if len(k) == 1:
            if int(k[0]) == 1:no = 0
            else:no = (int(k[0])-1)*25
            for c in range(0,len(dataDoujins)):
                no+=1
                ret_.append({"thumbnailImageUrl": lururl+gg[c],"imageSize": "contain","imageAspectRatio": "square","title": 'Rank {}'.format(no),"text": '{} '.format(dataDoujins[c][:55]),"actions": [{"type": "uri","label": "Go Page","uri": gh[c]}]})
            ks = len(ret_)//10
            for aa in range(ks+1):
                data = {"messages": [{"type": "template","altText": "Khie sent a template.","template": {"type": "carousel","columns": ret_[aa*10 : (aa+1)*10]}}]}
                aas = sendCarousel(to,data)
        if len(k) == 2:
            if int(k[0]) == 1:g = int(k[1])-1
            else:g = int(k[1])-1;g= (((int(k[0])*25-25)//(int(k[0])-1))-(-int(k[1])+25*int(k[0])))-1
            noobcoder.sendMessage(to,' 「 Nhentai 」\nStatus: Uploading Doujin {} From nhentai'.format(dataDoujins[g]))
            website = requests.get("{}1/".format(gh[g]))
            data = BeautifulSoup(website.content, "lxml")
            for getJson in data.findAll("script")[2]:
                imgs = re.search(r"gallery\s*:\s*(\{.+\}),", getJson)
                imgs = json.loads(imgs.group(1))
                idx = imgs.get("media_id")
                images = []
                cdn = lururl+"https://i.nhentai.net/galleries/"
                ext = {"j": "jpg", "p": "png", "g": "gif"}
                for n, i in enumerate(imgs.get("images", {}).get("pages", [])):
                    hh = "{}{}/{}.{}".format(cdn, idx, n + 1, ext.get(i.get("t")))
                    ret_.append({"imageUrl": lururl+hh,"action": {"type": "uri","label": "View detail","uri": hh}})
                k = len(ret_)//10
                for aa in range(k+1):
                    data = {"messages": [{"type": "template","altText": "Khie sent a template.","template": {"type": "image_carousel","columns": ret_[aa*10 : (aa+1)*10]}}]}
                    sendCarousel(to,data)
                noobcoder.sendMessage(to,' 「 Nhentai 」\nSuccess Send {} pict From Nhentai'.format(len(ret_)))
    except Exception as e:
        print(e)
#=====================================================================
def entod_in(to, mid):
    try:
        noobcoder.kickoutFromGroup(to, [mid])
        noobcoder.findAndAddContactsByMid(mid)
        noobcoder.inviteIntoGroup(to, [mid])
        noobcoder.cancelGroupInvitation(to,[mid])
    except Exception as e:
        print(e)
#=====================================================================
def restartBot():
    print ("[ INFO ] BOT RESETTED")
    backupData()
    python = sys.executable
    os.execl(python, python, *sys.argv)
#=====================================================================
def runtime(secs):
    mins, secs = divmod(secs,60)
    hours, mins = divmod(mins,60)
    days, hours = divmod(hours, 24)
    return '%02d d %02d h %02d m %02d s' % (days, hours, mins, secs)
#=====================================================================
def blekedok(t:int=None):
    r = requests.get('https://www.webtoons.com/id/genre')
    soup = BeautifulSoup(r.text,'html5lib')
    data = soup.find_all(class_='card_lst')
    return data
def WebtoonDrama(msg,liffnya,cmd):
    msg.text = cmd
    drama = msg.text.split(' ')[1]
    text = msg.text
    for a in DramaEnak(drama,text,msg.to,blekedok(drama),liffnya):sendCarousel(msg.to,a)
def webtoon(to,msg,liffnya):
    data = webtoonk(msg,liffnya)
    sendCarousel(to,data)
def webtoonk(msg,liffnya):
        data = {
                                    "messages": [
                                        {
                                            "type": "flex",
                                            "altText": "Me",
                                            "contents": {
                                                "type": "bubble",
                                                "hero": {
                                                    "type": "image",
                                                    "url": "https://webtoons-static.pstatic.net/image/pc/home/og_en.jpg?dt=2016110702",
                                                    "size": "full",
                                                    "aspectRatio": "1:1",
                                                    "aspectMode": "fit",
                                                },
                                                "body": {
                                                    "type": "box",
                                                    "layout": "vertical",
                                                    "spacing": "md",
                                                    "contents": [
                                                        {
                                                            "type": "text",
                                                            "text": "WEBTOON",
                                                            "weight": "bold",
                                                            "size": "md",
                                                            "margin": "md"
                                                        },
                                                        {
                                                            "type": "separator",
                                                            "color": "#000000",
                                                        },
                                                        {
                                                            "type": "box",
                                                            "layout": "baseline",
                                                            "margin": "md",
                                                            "contents": [
                                                                {
                                                                    "type": "text",
                                                                    "text": " ",
                                                                    "flex": 1,
                                                                    "size": "md",
                                                                    "margin": "md"
                                                                },
                                                                {
                                                                    "type": "text",
                                                                    "text": "| TYPE |",
                                                                    "weight": "bold",
                                                                    "size": "md",
                                                                    "margin": "md",
                                                                    "flex": 2,
                                                                }
                                                            ]
                                                        },
                                                        {
                                                            "type": "box",
                                                            "layout": "baseline",
                                                            "margin": "md",
                                                            "contents": [
                                                                {
                                                                    "type": "text",
                                                                    "text": "1.DRAMA",
                                                                    "flex": 1,
                                                                    "size": "md",
                                                                    "margin": "md",
                                                                    "action":   {
                                                                                    "type": "uri",
                                                                                    "uri": "{}webtoon%20drama".format(liffnya['ttt'])
                                                                                }
                                                                },
                                                                {
                                                                    "type": "text",
                                                                    "text": "4.FANTASI",
                                                                    "size": "md",
                                                                    "margin": "md",
                                                                    "flex": 1,
                                                                    "action":   {
                                                                                    "type": "uri",
                                                                                    "uri": "{}webtoon%20fantasi".format(liffnya['ttt'])
                                                                                }
                                                                }
                                                            ]
                                                        },
                                                        {
                                                            "type": "box",
                                                            "layout": "baseline",
                                                            "margin": "md",
                                                            "contents": [
                                                                {
                                                                    "type": "text",
                                                                    "text": "2.COMEDY",
                                                                    "flex": 1,
                                                                    "size": "md",
                                                                    "margin": "md",
                                                                    "action":   {
                                                                                    "type": "uri",
                                                                                    "uri": "{}webtoon%20comedy".format(liffnya['ttt'])
                                                                                }
                                                                },
                                                                {
                                                                    "type": "text",
                                                                    "text": "5.ROMANCE",
                                                                    "size": "md",
                                                                    "margin": "md",
                                                                    "flex": 1,
                                                                    "action":   {
                                                                                    "type": "uri",
                                                                                    "uri": "{}webtoon%20romance".format(liffnya['ttt'])
                                                                                }
                                                                }
                                                            ]
                                                        },
                                                        {
                                                            "type": "box",
                                                            "layout": "baseline",
                                                            "margin": "md",
                                                            "contents": [
                                                                {
                                                                    "type": "text",
                                                                    "text": "3.THRILLER",
                                                                    "flex": 1,
                                                                    "size": "md",
                                                                    "margin": "md",
                                                                    "action":   {
                                                                                    "type": "uri",
                                                                                    "uri": "{}webtoon%20thriller".format(liffnya['ttt'])
                                                                                }
                                                                },
                                                                {
                                                                    "type": "text",
                                                                    "text": "6.HORROR",
                                                                    "size": "md",
                                                                    "margin": "md",
                                                                    "flex": 1,
                                                                    "action":   {
                                                                                    "type": "uri",
                                                                                    "uri": "{}webtoon%20horror".format(liffnya['ttt'])
                                                                                }
                                                                }
                                                            ]
                                                        },
                                                        {
                                                            "type": "separator",
                                                            "color": "#000000",
                                                        },
                                                        {
                                                            "type": "box",
                                                            "layout": "baseline",
                                                            "margin": "md",
                                                            "contents": [
                                                                {
                                                                    "type": "text",
                                                                    "text": " ",
                                                                    "flex": 1,
                                                                    "size": "md",
                                                                    "margin": "md",
                                                                },
                                                                {
                                                                    "type": "text",
                                                                    "text": "| COMMAND |",
                                                                    "size": "md",
                                                                    "margin": "md",
                                                                    "flex": 3,
                                                                    "weight": "bold"
                                                                }
                                                            ]
                                                        },
                                                        {
                                                            "type": "separator",
                                                            "color": "#000000",
                                                        },
                                                        {
                                                            "type": "box",
                                                            "layout": "baseline",
                                                            "margin": "md",
                                                            "contents": [
                                                                {
                                                                    "type": "text",
                                                                    "text": "webtoon [type]",
                                                                    "flex": 0,
                                                                    "size": "md",
                                                                    "margin": "md",
                                                                },
                                                            ]
                                                        },
                                                        {
                                                            "type": "separator",
                                                            "color": "#000000",
                                                        },
                                                        {
                                                            "type": "box",
                                                            "layout": "baseline",
                                                            "margin": "md",
                                                            "contents": [
                                                                {
                                                                    "type": "text",
                                                                    "text": "IMPORTANT CLICK TYPE FOR FAST COMMAND",
                                                                    "flex": 0,
                                                                    "size": "md",
                                                                    "margin": "md",
                                                                    "weight": "bold",
                                                                    "wrap": True,
                                                                },
                                                            ]
                                                        },
                                                    ]
                                                },
                                            }
                                        }
                                    ]
                                }
        return data
def DramaEnak(drama,text,to,deff,liffnya):
        if drama in ['drama','fantasi','comedy','sol','romance','thriller','horror']:
            if drama == 'drama':drama = 0
            if drama == 'fantasi':drama = 1
            if drama == 'comedy':drama = 2
            if drama == 'sol':drama = 3
            if drama == 'romance':drama = 4
            if drama == 'thriller':drama = 5
            if drama == 'horror':drama = 6
            data = deff
            ss = []
            h = []
            if len(text.split(' ')) == 6:
                try:
                    if text.split(' ')[3].lower() != 'page':return
                    b = requests.get(data[drama].find_all('a')[int(text.split(' ')[2])-1].get('href'))
                    soup1 = BeautifulSoup(b.text,'html5lib')
                    data2 = soup1.find_all(id='_listUl')
                    data3 = data2[0].find_all('a')
                    b = requests.get(data3[int(text.split(' ')[5])-1].get('href'))
                    soup1 = BeautifulSoup(b.text,'html5lib')
                    date = soup1.select('img._images')
                    for b in range(0,len(date)):
                        url = 'https://app-1536548990.000webhostapp.com/apis.php?aas='+date[b]['data-url']
                        ss.append({
                                                        "type": "bubble",
                                                        "hero": {
                                                            "type": "image",
                                                            "url": url,
                                                            "size": "full",
                                                            "aspectRatio": "1:1",
                                                            "aspectMode": "fit",
                                                        }})
                    k = len(ss)//10
                    h = []
                    for aa in range(k+1):
                        h.append({
                                            "messages": [
                                                {
                                                    "type": "flex",
                                                    "altText": "Webtoon",
                                                    "contents": {
                                                        "type": "carousel",
                                                        "contents": ss[aa*10 : (aa+1)*10]
                                                    }
                                                }
                                            ]
                                        })
                    return h
                except:e = traceback.format_exc();open('w','w').write(str(e))
            if len(text.split(' ')) == 2:
                    date = data[drama].find_all('img')
                    datea = data[drama].find_all(class_='info')
                    for b in range(0,len(date)):
                        url = 'https://app-1536548990.000webhostapp.com/apis.php?aas='+date[b]['src']
                        ss.append({
                                                        "type": "bubble",
                                                        "hero": {
                                                            "type": "image",
                                                            "url": url,
                                                            "size": "full",
                                                            "aspectRatio": "1:1",
                                                            "aspectMode": "fit",
                                                            "action": {
                                                                "type": "uri",
                                                                "uri": "{}webtoon%20{}%20{}%20page%20{}".format(liffnya['ttt'],text.split(' ')[1],len(ss)+1,b+1)
                                                                }
                                                        },
                                                        "body": {
                                                            "type": "box",
                                                            "layout": "vertical",
                                                            "contents": [
                                                                {
                                                                    "type": "box",
                                                                    "layout": "vertical",
                                                                    "margin": "lg",
                                                                    "spacing": "sm",
                                                                    "contents": [
                                                                        {
                                                                            "type": "box",
                                                                            "layout": "baseline",
                                                                            "spacing": "sm",
                                                                            "contents": [
                                                                                {
                                                                                    "type": "text",
                                                                                    "text": "Title",
                                                                                    "color": "#aaaaaa",
                                                                                    "size": "sm",
                                                                                    "flex": 1
                                                                                },
                                                                                {
                                                                                    "type": "text",
                                                                                    "text": "{}".format(datea[b].find_all('p')[0].text),
                                                                                    "color": "#262423",
                                                                                    "wrap": True,
                                                                                    "size": "sm",
                                                                                    "flex": 4
                                                                                },
                                                                            ]
                                                                        },
                                                                        {
                                                                            "type": "box",
                                                                            "layout": "baseline",
                                                                            "spacing": "sm",
                                                                            "contents": [
                                                                                {
                                                                                    "type": "text",
                                                                                    "text": 'Author:',
                                                                                    "color": "#aaaaaa",
                                                                                    "size": "sm",
                                                                                    "flex": 1
                                                                                },
                                                                                {
                                                                                    "type": "text",
                                                                                    "text": '{}'.format(datea[b].find_all('p')[1].text),
                                                                                    "color": "#262423",
                                                                                    "wrap": True,
                                                                                    "size": "sm",
                                                                                    "flex": 4
                                                                                }
                                                                            ]
                                                                        },
                                                                        {
                                                                            "type": "box",
                                                                            "layout": "baseline",
                                                                            "spacing": "sm",
                                                                            "contents": [
                                                                                {
                                                                                    "type": "text",
                                                                                    "text": 'Likes:',
                                                                                    "color": "#aaaaaa",
                                                                                    "size": "sm",
                                                                                    "flex": 1
                                                                                },
                                                                                {
                                                                                    "type": "text",
                                                                                    "text": '{}'.format(datea[b].find_all('p')[2].find_all('em')[0].text),
                                                                                    "color": "#262423",
                                                                                    "wrap": True,
                                                                                    "size": "sm",
                                                                                    "flex": 4
                                                                                }
                                                                            ]
                                                                        }
                                                                    ]
                                                                },
                                                                {
                                                                    "type": "separator",
                                                                    "color": "#000000",
                                                                },
                                                                {
                                                                    "type": "box",
                                                                    "layout": "vertical",
                                                                    "margin": "lg",
                                                                    "spacing": "sm",
                                                                    "contents": [
                                                                        {
                                                                            "type": "text",
                                                                            "text": 'Click The Image For Cek Episode',
                                                                            "color": "#262423",
                                                                            "wrap": True,
                                                                            "size": "md",
                                                                            "weight": "bold",
                                                                        }
                                                                    ]
                                                                },
                                                            ]
                                                        }})
                    k = len(ss)//10
                    h = []
                    for aa in range(k+1):
                        h.append({
                                            "messages": [
                                                {
                                                    "type": "flex",
                                                    "altText": "Webtoon",
                                                    "contents": {
                                                        "type": "carousel",
                                                        "contents": ss[aa*10 : (aa+1)*10]
                                                    }
                                                }
                                            ]
                                        })
                    return h
            if len(text.split(' ')) == 5:
                    if text.split(' ')[3].lower() != 'page':return
                    b = requests.get(data[drama].find_all('a')[int(text.split(' ')[2])-1].get('href')+'&page='+str(int(text.split(' ')[4])))
                    soup1 = BeautifulSoup(b.text,'html5lib')
                    data11 = soup1.find_all(class_='subj')
                    data2 = soup1.find_all(id='_listUl')
                    data3 = data2[0].find_all('a')
                    data4 = data2[0].find_all('img')
                    if len(data4) == 10:jumlah = 10
                    else:jumlah = len(data4)
                    for c in range(0,jumlah):
                        print(data3[c].get('href'))
                        url = 'https://app-1536548990.000webhostapp.com/apis.php?aas='+data4[c]['src']
                        ss.append({
                                                    "type": "bubble",
                                                    "hero": {
                                                        "type": "image",
                                                        "url": url,
                                                        "size": "full",
                                                        "aspectRatio": "1:1",
                                                        "aspectMode": "fit",
                                                    },
                                                    "body": {
                                                        "type": "box",
                                                        "layout": "vertical",
                                                        "contents": [
                                                            {
                                                                "type": "box",
                                                                "layout": "vertical",
                                                                "margin": "lg",
                                                                "spacing": "sm",
                                                                "contents": [
                                                                    {
                                                                        "type": "box",
                                                                        "layout": "baseline",
                                                                        "spacing": "sm",
                                                                        "contents": [
                                                                            {
                                                                                "type": "text",
                                                                                "text": "Title",
                                                                                "color": "#aaaaaa",
                                                                                "size": "sm",
                                                                                "flex": 1
                                                                            },
                                                                            {
                                                                                "type": "text",
                                                                                "text": "{}".format(data11[c+1].text),
                                                                                "color": "#262423",
                                                                                "wrap": True,
                                                                                "size": "sm",
                                                                                "flex": 5
                                                                            }
                                                                        ]
                                                                    }
                                                                ]
                                                            }
                                                        ]
                                                    },
                                                    "footer": {
                                                        "type": "box",
                                                        "layout": "horizontal",
                                                        "contents": [
                                                            {
                                                                "type": "button",
                                                                "style": "link",
                                                                "action": {
                                                                    "type": "uri",
                                                                    "label": "Go Page",
                                                                    "uri": data3[c].get('href')
                                                                }                                                   
                                                            },
                                                            {
                                                                "type": "button",
                                                                "style": "link",
                                                                "action": {
                                                                    "type": "uri",
                                                                    "label": "Read Online",
                                                                    "uri": "{}webtoon%20{}%20{}%20page%20{}%20{}".format(liffnya['ttt'],text.split(' ')[1],text.split(' ')[2],c+6,c+1)
                                                                }
                                                            }
                                                        ],
                                                    }})
                    data = {
                                        "messages": [
                                            {
                                                "type": "flex",
                                                "altText": "Webtoon",
                                                "contents": {
                                                    "type": "carousel",
                                                    "contents": ss
                                                }
                                            }
                                        ]
                                    }
                    return [data]
def anunanu(to,s,liffnya,j=''):
    try:
        if j == '':
            data = {"messages": [{"type": "image","originalContentUrl": s,"previewImageUrl": s,"sentBy":{"label":"NoobCoder","iconUrl":"https://obs.line-scdn.net/{}".format(noobcoder.getContact(noobcoderMID).pictureStatus),"linkUrl":"https://line.me/ti/p/zMankMvx69"}}]}
        else:
            data = {"messages": [{"type": "image","originalContentUrl": s,"previewImageUrl": s,"animated":True,"extension":"gif","sentBy":{"label":"Khie","iconUrl":"https://obs.line-scdn.net/{}".format(noobcoder.getContact(noobcoderMID).pictureStatus),"linkUrl":"https://line.me/ti/p/zMankMvx69"}}]}
        sendCarousel(to,data)
    except Exception as e:
        print(e)
def anuanu(to,s,liffnya,j=''):
    try:
        if j == '':
            data = {"messages": [{"type": "video","originalContentUrl": s,"previewImageUrl": s}]}
        else:
            data = {"messages": [{"type": "video","originalContentUrl": s,"previewImageUrl": s}]}
        sendCarousel(to,data)
    except Exception as e:
        print(e)
def webtoon(to,msg,liffnya):
    data = webtoonk(msg,liffnya)
    sendCarousel(to,data)
def sendCarousel(to,col):
    col = json.dumps(col)
    xyz = LiffChatContext(to)
    xyzz = LiffContext(chat=xyz)
    view = LiffViewRequest('1643727178-0XPGAaRX', xyzz)
    token = noobcoder.issueLiffView(view)
    url = 'https://api.line.me/message/v3/share'
    headers = {
        'Content-Type': 'application/json',
        'Authorization': 'Bearer %s' % token.accessToken
    }
    return requests.post(url, data=col, headers=headers)
def picFinder(name):    
        try:
            rgram = requests.get('http://www.instagram.com/{}'.format(name))
            rgram.raise_for_status()
            selenaSoup=BeautifulSoup(rgram.text,'html.parser')
            pageJS = selenaSoup.select('script')
            for i, j in enumerate(pageJS):
                pageJS[i]=str(j)
            picInfo = sorted(pageJS,key=len, reverse=True)[0]
            allPics = json.loads(str(picInfo)[52:-10])['entry_data']['ProfilePage'][0]
            return allPics
        except requests.exceptions.HTTPError:
            return '\t \t ### ACCOUNT MISSING ###'
def instagramku(msg,liffnya,tksop,ss):
        data = {
                                    "messages": [
                                        {
                                            "type": "flex",
                                            "altText": "INSTAGRAM",
                                            "contents": {
                                                "type": "bubble",
                                                "header": {
                                                    "type": "box",
                                                    "layout": "horizontal",
                                                    "contents": [
                                                        {
                                                            "type": "text",
                                                            "text": "{}".format(ss['full_name']),
                                                            "weight": "bold",
                                                            "color": "#262423",
                                                            "size": "sm"
                                                        }
                                                    ]
                                                },
                                                "hero": {
                                                    "type": "image",
                                                    "url": "{}".format(ss['profile_pic_url_hd']),
                                                    "size": "full",
                                                    "aspectRatio": "1:1",
                                                },
                                                "body": {
                                                    "type": "box",
                                                    "layout": "vertical",
                                                    "contents": [
                                                        {
                                                            "type": "text",
                                                            "text": "INSTAGRAM PROFILE",
                                                            "weight": "bold",
                                                            "size": "md",
                                                            "margin": "md"
                                                        },
                                                        {
                                                            "type": "separator",
                                                            "color": "#000000",
                                                        },
                                                        {
                                                            "type": "box",
                                                            "layout": "vertical",
                                                            "margin": "lg",
                                                            "spacing": "sm",
                                                            "contents": [
                                                                {
                                                                    "type": "box",
                                                                    "layout": "baseline",
                                                                    "spacing": "sm",
                                                                    "contents": [
                                                                        {
                                                                            "type": "text",
                                                                            "text": "Nama",
                                                                            "color": "#aaaaaa",
                                                                            "size": "sm",
                                                                            "flex": 3
                                                                        },
                                                                        {
                                                                            "type": "text",
                                                                            "text": "{}".format(ss['full_name']),
                                                                            "color": "#262423",
                                                                            "size": "sm",
                                                                            "wrap": True,
                                                                            "flex": 5
                                                                        }
                                                                    ]
                                                                },
                                                                {
                                                                    "type": "box",
                                                                    "layout": "baseline",
                                                                    "spacing": "sm",
                                                                    "contents": [
                                                                        {
                                                                            "type": "text",
                                                                            "text": "Username",
                                                                            "color": "#aaaaaa",
                                                                            "size": "sm",
                                                                            "flex": 3
                                                                        },
                                                                        {
                                                                            "type": "text",
                                                                            "text": "{}".format(tksop),
                                                                            "color": "#262423",
                                                                            "size": "sm",
                                                                            "wrap": True,
                                                                            "flex": 5
                                                                        }
                                                                    ]
                                                                },
                                                                {
                                                                    "type": "box",
                                                                    "layout": "baseline",
                                                                    "spacing": "sm",
                                                                    "contents": [
                                                                        {
                                                                            "type": "text",
                                                                            "text": "Bio",
                                                                            "color": "#aaaaaa",
                                                                            "size": "sm",
                                                                            "flex": 3
                                                                        },
                                                                        {
                                                                            "type": "text",
                                                                            "text": "{}".format(ss['biography']),
                                                                            "color": "#262423",
                                                                            "wrap": True,
                                                                            "size": "sm",
                                                                            "flex": 5
                                                                        }
                                                                    ]
                                                                },
                                                                {
                                                                    "type": "box",
                                                                    "layout": "baseline",
                                                                    "spacing": "sm",
                                                                    "contents": [
                                                                        {
                                                                            "type": "text",
                                                                            "text": "Private",
                                                                            "color": "#aaaaaa",
                                                                            "size": "sm",
                                                                            "flex": 3
                                                                        },
                                                                        {
                                                                            "type": "text",
                                                                            "text": "{}".format(ss['is_private']),
                                                                            "color": "#262423",
                                                                            "wrap": True,
                                                                            "size": "sm",
                                                                            "flex": 5
                                                                        }
                                                                    ]
                                                                },
                                                                {
                                                                    "type": "box",
                                                                    "layout": "baseline",
                                                                    "spacing": "sm",
                                                                    "contents": [
                                                                        {
                                                                            "type": "text",
                                                                            "text": "Followers",
                                                                            "color": "#aaaaaa",
                                                                            "size": "sm",
                                                                            "flex": 3
                                                                        },
                                                                        {
                                                                            "type": "text",
                                                                            "text": "{}".format(humanize.intcomma(ss['edge_followed_by']['count'])),
                                                                            "color": "#262423",
                                                                            "wrap": True,
                                                                            "size": "sm",
                                                                            "flex": 5
                                                                        }
                                                                    ]
                                                                },
                                                                {
                                                                    "type": "box",
                                                                    "layout": "baseline",
                                                                    "spacing": "sm",
                                                                    "contents": [
                                                                        {
                                                                            "type": "text",
                                                                            "text": "Following",
                                                                            "color": "#aaaaaa",
                                                                            "size": "sm",
                                                                            "flex": 3
                                                                        },
                                                                        {
                                                                            "type": "text",
                                                                            "text": "{}".format(humanize.intcomma(ss['edge_follow']['count'])),
                                                                            "color": "#262423",
                                                                            "wrap": True,
                                                                            "size": "sm",
                                                                            "flex": 5
                                                                        }
                                                                    ]
                                                                },
                                                                {
                                                                    "type": "box",
                                                                    "layout": "baseline",
                                                                    "spacing": "sm",
                                                                    "contents": [
                                                                        {
                                                                            "type": "text",
                                                                            "text": "Post",
                                                                            "color": "#aaaaaa",
                                                                            "size": "sm",
                                                                            "flex": 3
                                                                        },
                                                                        {
                                                                            "type": "text",
                                                                            "text": "{}".format(humanize.intcomma(ss['edge_owner_to_timeline_media']['count'])),
                                                                            "color": "#262423",
                                                                            "wrap": True,
                                                                            "size": "sm",
                                                                            "flex": 5
                                                                        }
                                                                    ]
                                                                }
                                                            ]
                                                        }
                                                    ]
                                                },
                                                "footer": {
                                                    "type": "box",
                                                    "layout": "vertical",
                                                    "contents": [{
                                                        "type": "box",
                                                        "layout": "horizontal",
                                                        "contents": [{
                                                            "type": "button",
                                                            "flex": 2,
                                                            "style": "primary",
                                                            "color": "#FF2B00",
                                                            "height": "sm",
                                                            "action": {
                                                                "type": "uri",
                                                                "label": "POST",
                                                                "uri": "{}instagram%20post%20{}".format(liffnya['ttt'],tksop)
                                                            }
                                                        }, {
                                                            "flex": 3,
                                                            "type": "button",
                                                            "margin": "sm",
                                                            "style": "primary",
                                                            "color": "#097500",
                                                            "height": "sm",
                                                            "action": {
                                                                "type": "uri",
                                                                "label": "STORY",
                                                                "uri": '{}instagram%20story%20{}'.format(liffnya['ttt'],tksop)
                                                            }
                                                            }]
                                                        }, {
                                                        "type": "button",
                                                        "margin": "sm",
                                                        "style": "primary",
                                                        "color": "#0874DE",
                                                        "height": "sm",
                                                        "action": {
                                                            "type": "uri",
                                                            "label": "GO TO PAGE",
                                                            "uri": 'https://www.instagram.com/{}'.format(tksop)
                                                        }
                                                    }]
                                                }
                                            }
                                        }
                                    ]
                                }
        return data
def igsearch(msg,liffnya,cmd):
        to = msg.to
        msg.text = msg.text
        text = msg.text.split(' ')[1]
        data = picFinder(text)
        if len(msg.text.split(' ')) == 2:
            try:
                asd = data['graphql']['user']
                data = instagramku(msg,liffnya,text,asd)
                sendCarousel(msg.to,data)
            except:
                text = traceback.format_exc()
                return noobcoder.sendMessage(to,"Status: 404\nReason: Instagram {}".format(text))
        if len(cmd.split(' ')) == 3:
            if 'https' in msg.text:
                print(msg.text)
                a = msg.text.split(' ')[2]
                print(a)
                url = requests.get(a)
                soup = BeautifulSoup(url.text, 'html.parser')
                z = soup.find('body')
                y = z.find('script')
                v = y.text.strip().replace('window._sharedData =', '').replace(';', '')
                d = json.loads(v)
                ret_ = []
                e = d['entry_data']['PostPage'][0]['graphql']['shortcode_media']
                if 'edge_sidecar_to_children' in e:
                    like = e['edge_media_preview_like']['count']
                    caption = e['edge_media_to_caption']['edges']
                    for zz in caption:
                        anu = zz['node']['text']
                    comment = e['edge_media_to_comment']['count']
                    bla = e['edge_media_to_comment']
                    for ib in bla['edges']:
                        komen = ib['node']['text']
                        usrname = ib['node']['owner']['username']
                    for a in e['edge_sidecar_to_children']['edges']:
                        if a['node']['is_video'] == True:
                            prev = a['node']['display_url']
                            vid = a['node']['video_url']
                            view = a['node']['video_view_count']
                        else:
                            pict = a['node']['display_url']
                        try:
                            ret_.append({"type": "bubble","header": {"type": "box","layout": "vertical","contents": [{"type": "text","text": "INSTAGRAM POST","weight": "bold"}]},"footer": {"type": "box","layout": "vertical","spacing": "sm","contents": [{"type": "button","style": "link","height": "sm","action": {"type": "uri","label": "Send Video","uri": "line://app/1643727178-0XPGAaRX?type=video&ocu={}&piu={}".format(vid,prev)}},]},"hero": {"type": "image","url": prev,"size": "full","aspectRatio": "1:1","aspectMode": "fit"},"body": {"type": "box","layout": "vertical","contents": [{"type": "text","text": "POST INFO","weight": "bold","size":"md","margin":"md"},{"type":"separator","color":"#000000"},{"type": "box","layout": "vertical","margin": "lg","spacing": "sm","contents": [{"type": "box","layout": "baseline","spacing": "sm","contents": [{"type": "text","text": "Caption","color": "#aaaaaa","size": "sm","flex": 3},{"type": "text","text": "{}".format(anu),"color": "#262423","size": "sm","wrap": True,"flex": 5}]},{"type": "box","layout": "baseline","spacing": "sm","contents": [{"type": "text","text": "Likes","color": "#aaaaaa","size": "sm","flex": 3},{"type": "text","text": "{}".format(humanize.intcomma(like)),"color": "#262423","size": "sm","flex": 5}]},{"type": "box","layout": "baseline","spacing": "sm","contents": [{"type": "text","text": "Comment","color": "#aaaaaa","size": "sm","flex": 3},{"type": "text","text": "{}".format(humanize.intcomma(comment)),"color": "#262423","wrap": True,"size": "sm","flex": 5}]},{"type": "box","layout": "baseline","spacing": "sm","contents": [{"type": "text","text": "From","color": "#aaaaaa","size": "sm","flex": 3},{"type": "text","text": "@{}".format(usrname),"color": "#262423","wrap": True,"size": "sm","flex": 5}]},{"type": "box","layout": "baseline","spacing": "sm","contents": [{"type": "text","text": "Text","color": "#aaaaaa","size": "sm","flex": 3},{"type": "text","text": "{}".format(komen),"color": "#262423","wrap": True,"size": "sm","flex": 5}]},{"type": "box","layout": "baseline","spacing": "sm","contents": [{"type": "text","text": "View count","color": "#aaaaaa","size": "sm","flex": 3},{"type": "text","text": "{}".format(humanize.intcomma(view)),"color": "#262423","wrap": True,"size": "sm","flex": 5}]}]}]}})
                        except:
                            ret_.append({"type": "bubble","header": {"type": "box","layout": "vertical","contents": [{"type": "text","text": "INSTAGRAM POST","weight": "bold"}]},"footer": {"type": "box","layout": "vertical","spacing": "sm","contents": [{"type": "button","style": "link","height": "sm","action": {"type": "uri","label": "Send Image","uri": "line://app/1643727178-0XPGAaRX?type=image&img={}".format(pict)}},]},"hero": {"type": "image","url": pict,"size": "full","aspectRatio": "1:1","aspectMode": "fit"},"body": {"type": "box","layout": "vertical","contents": [{"type": "text","text": "POST INFO","weight": "bold","size":"md","margin":"md"},{"type":"separator","color":"#000000"},{"type": "box","layout": "vertical","margin": "lg","spacing": "sm","contents": [{"type": "box","layout": "baseline","spacing": "sm","contents": [{"type": "text","text": "Caption","color": "#aaaaaa","size": "sm","flex": 3},{"type": "text","text": "{}".format(anu),"color": "#262423","size": "sm","wrap": True,"flex": 5}]},{"type": "box","layout": "baseline","spacing": "sm","contents": [{"type": "text","text": "Likes","color": "#aaaaaa","size": "sm","flex": 3},{"type": "text","text": "{}".format(humanize.intcomma(like)),"color": "#262423","size": "sm","flex": 5}]},{"type": "box","layout": "baseline","spacing": "sm","contents": [{"type": "text","text": "Comment","color": "#aaaaaa","size": "sm","flex": 3},{"type": "text","text": "{}".format(humanize.intcomma(comment)),"color": "#262423","wrap": True,"size": "sm","flex": 5}]},{"type": "box","layout": "baseline","spacing": "sm","contents": [{"type": "text","text": "From","color": "#aaaaaa","size": "sm","flex": 3},{"type": "text","text": "@{}".format(usrname),"color": "#262423","wrap": True,"size": "sm","flex": 5}]},{"type": "box","layout": "baseline","spacing": "sm","contents": [{"type": "text","text": "Text","color": "#aaaaaa","size": "sm","flex": 3},{"type": "text","text": "{}".format(komen),"color": "#262423","wrap": True,"size": "sm","flex": 5}]}]}]}})
                    k = len(ret_)//10
                    for aa in range(k+1):
                        data = {"messages": [{"type": "flex","altText": "Khie sent a flex.","contents": {"type": "carousel","contents": ret_[aa*10 : (aa+1)*10]}}]}
                        sendCarousel(to,data)
                else:
                    like = e['edge_media_preview_like']['count']
                    caption = e['edge_media_to_caption']['edges']
                    for zz in caption:
                        anu = zz['node']['text']
                    comment = e['edge_media_to_comment']['count']
                    bla = e['edge_media_to_comment']
                    for ib in bla['edges']:
                        komen = ib['node']['text']
                        usrname = ib['node']['owner']['username']
                    if e['is_video'] == True:
                        durasi = e['video_duration']
                        view = e['video_view_count']
                        ret_.append({"type": "bubble","header": {"type": "box","layout": "vertical","contents": [{"type": "text","text": "INSTAGRAM POST","weight": "bold"}]},"footer": {"type": "box","layout": "vertical","spacing": "sm","contents": [{"type": "button","style": "link","height": "sm","action": {"type": "uri","label": "Send Video","uri": "line://app/1643727178-0XPGAaRX?type=video&ocu={}&piu={}".format(e['video_url'],e['display_url'])}},]},"hero": {"type": "image","url": e['display_url'],"size": "full","aspectRatio": "1:1","aspectMode": "fit"},"body": {"type": "box","layout": "vertical","contents": [{"type": "text","text": "POST INFO","weight": "bold","size":"md","margin":"md"},{"type":"separator","color":"#000000"},{"type": "box","layout": "vertical","margin": "lg","spacing": "sm","contents": [{"type": "box","layout": "baseline","spacing": "sm","contents": [{"type": "text","text": "Caption","color": "#aaaaaa","size": "sm","flex": 3},{"type": "text","text": "{}".format(anu),"color": "#262423","size": "sm","wrap": True,"flex": 5}]},{"type": "box","layout": "baseline","spacing": "sm","contents": [{"type": "text","text": "Likes","color": "#aaaaaa","size": "sm","flex": 3},{"type": "text","text": "{}".format(humanize.intcomma(like)),"color": "#262423","size": "sm","flex": 5}]},{"type": "box","layout": "baseline","spacing": "sm","contents": [{"type": "text","text": "Comment","color": "#aaaaaa","size": "sm","flex": 3},{"type": "text","text": "{}".format(humanize.intcomma(comment)),"color": "#262423","wrap": True,"size": "sm","flex": 5}]},{"type": "box","layout": "baseline","spacing": "sm","contents": [{"type": "text","text": "From","color": "#aaaaaa","size": "sm","flex": 3},{"type": "text","text": "@{}".format(usrname),"color": "#262423","wrap": True,"size": "sm","flex": 5}]},{"type": "box","layout": "baseline","spacing": "sm","contents": [{"type": "text","text": "Text","color": "#aaaaaa","size": "sm","flex": 3},{"type": "text","text": "{}".format(komen),"color": "#262423","wrap": True,"size": "sm","flex": 5}]},{"type": "box","layout": "baseline","spacing": "sm","contents": [{"type": "text","text": "View count","color": "#aaaaaa","size": "sm","flex": 3},{"type": "text","text": "{}".format(humanize.intcomma(view)),"color": "#262423","wrap": True,"size": "sm","flex": 5}]},{"type": "box","layout": "baseline","spacing": "sm","contents": [{"type": "text","text": "Duration","color": "#aaaaaa","size": "sm","flex": 3},{"type": "text","text": "{} Second".format(humanize.intcomma(durasi)),"color": "#262423","wrap": True,"size": "sm","flex": 5}]}]}]}})
                    else:
                        ret_.append({"type": "bubble","header": {"type": "box","layout": "vertical","contents": [{"type": "text","text": "INSTAGRAM POST","weight": "bold"}]},"footer": {"type": "box","layout": "vertical","spacing": "sm","contents": [{"type": "button","style": "link","height": "sm","action": {"type": "uri","label": "Send Image","uri": "line://app/1643727178-0XPGAaRX?type=image&img={}".format(e['display_url'])}},]},"hero": {"type": "image","url": e['display_url'],"size": "full","aspectRatio": "1:1","aspectMode": "fit"},"body": {"type": "box","layout": "vertical","contents": [{"type": "text","text": "POST INFO","weight": "bold","size":"md","margin":"md"},{"type":"separator","color":"#000000"},{"type": "box","layout": "vertical","margin": "lg","spacing": "sm","contents": [{"type": "box","layout": "baseline","spacing": "sm","contents": [{"type": "text","text": "Caption","color": "#aaaaaa","size": "sm","flex": 3},{"type": "text","text": "{}".format(anu),"color": "#262423","size": "sm","wrap": True,"flex": 5}]},{"type": "box","layout": "baseline","spacing": "sm","contents": [{"type": "text","text": "Likes","color": "#aaaaaa","size": "sm","flex": 3},{"type": "text","text": "{}".format(humanize.intcomma(like)),"color": "#262423","size": "sm","flex": 5}]},{"type": "box","layout": "baseline","spacing": "sm","contents": [{"type": "text","text": "Comment","color": "#aaaaaa","size": "sm","flex": 3},{"type": "text","text": "{}".format(humanize.intcomma(comment)),"color": "#262423","wrap": True,"size": "sm","flex": 5}]},{"type": "box","layout": "baseline","spacing": "sm","contents": [{"type": "text","text": "From","color": "#aaaaaa","size": "sm","flex": 3},{"type": "text","text": "@{}".format(usrname),"color": "#262423","wrap": True,"size": "sm","flex": 5}]},{"type": "box","layout": "baseline","spacing": "sm","contents": [{"type": "text","text": "Text","color": "#aaaaaa","size": "sm","flex": 3},{"type": "text","text": "{}".format(komen),"color": "#262423","wrap": True,"size": "sm","flex": 5}]}]}]}})
                    k = len(ret_)//10
                    for aa in range(k+1):
                        data = {"messages": [{"type": "flex","altText": "Khie sent a flex.","contents": {"type": "carousel","contents": ret_[aa*10 : (aa+1)*10]}}]}
                        sendCarousel(to,data)
            else:
                k = InstagramScraper()
                results = k.profile_page_recent_posts('https://www.instagram.com/{}/?hl=id'.format(msg.text.split(' ')[2]))
                try:
                    ret_ = []
                    for i in results:
                        url = i['thumbnail_src']
                        ret_.append({"type": "bubble","hero": {"type": "image","url": url,"size": "full","aspectRatio": "1:1","aspectMode": "fit",},"footer": {"type": "box","layout": "vertical","spacing": "sm","contents": [{"type": "button","style": "link","height": "sm","action": {"type": "uri","label": "Post Detail","uri": "{}instagram%20post%20{}%20{}".format(liffnya["ttt"],msg.text.split(" ")[2],len(ret_))}},],}})
                    k = len(ret_)//10
                    for aa in range(k+1):
                        data = {"messages": [{"type": "flex","altText": "Khie sent a flex.","contents": {"type": "carousel","contents": ret_[aa*10 : (aa+1)*10]}}]}
                        sendCarousel(to,data)
                except Exception as e:
                    traceback.print_tb(e.__traceback__)
        if(cmd.startswith('instagram post ') and len(cmd.split(' ')) == 4):
            k = InstagramScraper()
            results = k.profile_page_recent_posts('https://www.instagram.com/{}/?hl=id'.format(msg.text.split(' ')[2]))
            ret = []
            no = 0
            for i in results:
                no += 1
                ret.append(i['shortcode'])
            url = requests.get('https://www.instagram.com/p/{}'.format(ret[int(msg.text.split(' ')[3])]))
            soup = BeautifulSoup(url.text, 'html.parser')
            z = soup.find('body')
            y = z.find('script')
            v = y.text.strip().replace('window._sharedData =', '').replace(';', '')
            d = json.loads(v)
            ret_ = []
            e = d['entry_data']['PostPage'][0]['graphql']['shortcode_media']
            if 'edge_sidecar_to_children' in e:
                like = e['edge_media_preview_like']['count']
                caption = e['edge_media_to_caption']['edges']
                for zz in caption:
                    anu = zz['node']['text']
                comment = e['edge_media_to_comment']['count']
                bla = e['edge_media_to_comment']
                for ib in bla['edges']:
                    komen = ib['node']['text']
                    usrname = ib['node']['owner']['username']
                for a in e['edge_sidecar_to_children']['edges']:
                    if a['node']['is_video'] == True:
                        prev = a['node']['display_url']
                        vid = a['node']['video_url']
                        view = a['node']['video_view_count']
                    else:
                        pict = a['node']['display_url']
                    try:
                        ret_.append({"type": "bubble","header": {"type": "box","layout": "vertical","contents": [{"type": "text","text": "INSTAGRAM POST","weight": "bold"}]},"footer": {"type": "box","layout": "vertical","spacing": "sm","contents": [{"type": "button","style": "link","height": "sm","action": {"type": "uri","label": "Send Video","uri": "line://app/1643727178-0XPGAaRX?type=video&ocu={}&piu={}".format(vid,prev)}},]},"hero": {"type": "image","url": prev,"size": "full","aspectRatio": "1:1","aspectMode": "fit"},"body": {"type": "box","layout": "vertical","contents": [{"type": "text","text": "POST INFO","weight": "bold","size":"md","margin":"md"},{"type":"separator","color":"#000000"},{"type": "box","layout": "vertical","margin": "lg","spacing": "sm","contents": [{"type": "box","layout": "baseline","spacing": "sm","contents": [{"type": "text","text": "Caption","color": "#aaaaaa","size": "sm","flex": 3},{"type": "text","text": "{}".format(anu),"color": "#262423","size": "sm","wrap": True,"flex": 5}]},{"type": "box","layout": "baseline","spacing": "sm","contents": [{"type": "text","text": "Likes","color": "#aaaaaa","size": "sm","flex": 3},{"type": "text","text": "{}".format(humanize.intcomma(like)),"color": "#262423","size": "sm","flex": 5}]},{"type": "box","layout": "baseline","spacing": "sm","contents": [{"type": "text","text": "Comment","color": "#aaaaaa","size": "sm","flex": 3},{"type": "text","text": "{}".format(humanize.intcomma(comment)),"color": "#262423","wrap": True,"size": "sm","flex": 5}]},{"type": "box","layout": "baseline","spacing": "sm","contents": [{"type": "text","text": "From","color": "#aaaaaa","size": "sm","flex": 3},{"type": "text","text": "@{}".format(usrname),"color": "#262423","wrap": True,"size": "sm","flex": 5}]},{"type": "box","layout": "baseline","spacing": "sm","contents": [{"type": "text","text": "Text","color": "#aaaaaa","size": "sm","flex": 3},{"type": "text","text": "{}".format(komen),"color": "#262423","wrap": True,"size": "sm","flex": 5}]},{"type": "box","layout": "baseline","spacing": "sm","contents": [{"type": "text","text": "View count","color": "#aaaaaa","size": "sm","flex": 3},{"type": "text","text": "{}".format(humanize.intcomma(view)),"color": "#262423","wrap": True,"size": "sm","flex": 5}]}]}]}})
                    except:
                        ret_.append({"type": "bubble","header": {"type": "box","layout": "vertical","contents": [{"type": "text","text": "INSTAGRAM POST","weight": "bold"}]},"footer": {"type": "box","layout": "vertical","spacing": "sm","contents": [{"type": "button","style": "link","height": "sm","action": {"type": "uri","label": "Send Image","uri": "line://app/1643727178-0XPGAaRX?type=image&img={}".format(pict)}},]},"hero": {"type": "image","url": pict,"size": "full","aspectRatio": "1:1","aspectMode": "fit"},"body": {"type": "box","layout": "vertical","contents": [{"type": "text","text": "POST INFO","weight": "bold","size":"md","margin":"md"},{"type":"separator","color":"#000000"},{"type": "box","layout": "vertical","margin": "lg","spacing": "sm","contents": [{"type": "box","layout": "baseline","spacing": "sm","contents": [{"type": "text","text": "Caption","color": "#aaaaaa","size": "sm","flex": 3},{"type": "text","text": "{}".format(anu),"color": "#262423","size": "sm","wrap": True,"flex": 5}]},{"type": "box","layout": "baseline","spacing": "sm","contents": [{"type": "text","text": "Likes","color": "#aaaaaa","size": "sm","flex": 3},{"type": "text","text": "{}".format(humanize.intcomma(like)),"color": "#262423","size": "sm","flex": 5}]},{"type": "box","layout": "baseline","spacing": "sm","contents": [{"type": "text","text": "Comment","color": "#aaaaaa","size": "sm","flex": 3},{"type": "text","text": "{}".format(humanize.intcomma(comment)),"color": "#262423","wrap": True,"size": "sm","flex": 5}]},{"type": "box","layout": "baseline","spacing": "sm","contents": [{"type": "text","text": "From","color": "#aaaaaa","size": "sm","flex": 3},{"type": "text","text": "@{}".format(usrname),"color": "#262423","wrap": True,"size": "sm","flex": 5}]},{"type": "box","layout": "baseline","spacing": "sm","contents": [{"type": "text","text": "Text","color": "#aaaaaa","size": "sm","flex": 3},{"type": "text","text": "{}".format(komen),"color": "#262423","wrap": True,"size": "sm","flex": 5}]}]}]}})
                k = len(ret_)//10
                for aa in range(k+1):
                    data = {"messages": [{"type": "flex","altText": "Khie sent a flex.","contents": {"type": "carousel","contents": ret_[aa*10 : (aa+1)*10]}}]}
                    sendCarousel(to,data)
            else:
                like = e['edge_media_preview_like']['count']
                caption = e['edge_media_to_caption']['edges']
                for zz in caption:
                    anu = zz['node']['text']
                comment = e['edge_media_to_comment']['count']
                bla = e['edge_media_to_comment']
                for ib in bla['edges']:
                    komen = ib['node']['text']
                    usrname = ib['node']['owner']['username']
                if e['is_video'] == True:
                    durasi = e['video_duration']
                    view = e['video_view_count']
                    ret_.append({"type": "bubble","header": {"type": "box","layout": "vertical","contents": [{"type": "text","text": "INSTAGRAM POST","weight": "bold"}]},"footer": {"type": "box","layout": "vertical","spacing": "sm","contents": [{"type": "button","style": "link","height": "sm","action": {"type": "uri","label": "Send Video","uri": "line://app/1643727178-0XPGAaRX?type=video&ocu={}&piu={}".format(e['video_url'],e['display_url'])}},]},"hero": {"type": "image","url": e['display_url'],"size": "full","aspectRatio": "1:1","aspectMode": "fit"},"body": {"type": "box","layout": "vertical","contents": [{"type": "text","text": "POST INFO","weight": "bold","size":"md","margin":"md"},{"type":"separator","color":"#000000"},{"type": "box","layout": "vertical","margin": "lg","spacing": "sm","contents": [{"type": "box","layout": "baseline","spacing": "sm","contents": [{"type": "text","text": "Caption","color": "#aaaaaa","size": "sm","flex": 3},{"type": "text","text": "{}".format(anu),"color": "#262423","size": "sm","wrap": True,"flex": 5}]},{"type": "box","layout": "baseline","spacing": "sm","contents": [{"type": "text","text": "Likes","color": "#aaaaaa","size": "sm","flex": 3},{"type": "text","text": "{}".format(humanize.intcomma(like)),"color": "#262423","size": "sm","flex": 5}]},{"type": "box","layout": "baseline","spacing": "sm","contents": [{"type": "text","text": "Comment","color": "#aaaaaa","size": "sm","flex": 3},{"type": "text","text": "{}".format(humanize.intcomma(comment)),"color": "#262423","wrap": True,"size": "sm","flex": 5}]},{"type": "box","layout": "baseline","spacing": "sm","contents": [{"type": "text","text": "From","color": "#aaaaaa","size": "sm","flex": 3},{"type": "text","text": "@{}".format(usrname),"color": "#262423","wrap": True,"size": "sm","flex": 5}]},{"type": "box","layout": "baseline","spacing": "sm","contents": [{"type": "text","text": "Text","color": "#aaaaaa","size": "sm","flex": 3},{"type": "text","text": "{}".format(komen),"color": "#262423","wrap": True,"size": "sm","flex": 5}]},{"type": "box","layout": "baseline","spacing": "sm","contents": [{"type": "text","text": "View count","color": "#aaaaaa","size": "sm","flex": 3},{"type": "text","text": "{}".format(humanize.intcomma(view)),"color": "#262423","wrap": True,"size": "sm","flex": 5}]},{"type": "box","layout": "baseline","spacing": "sm","contents": [{"type": "text","text": "Duration","color": "#aaaaaa","size": "sm","flex": 3},{"type": "text","text": "{} Second".format(humanize.intcomma(durasi)),"color": "#262423","wrap": True,"size": "sm","flex": 5}]}]}]}})
                else:
                    ret_.append({"type": "bubble","header": {"type": "box","layout": "vertical","contents": [{"type": "text","text": "INSTAGRAM POST","weight": "bold"}]},"footer": {"type": "box","layout": "vertical","spacing": "sm","contents": [{"type": "button","style": "link","height": "sm","action": {"type": "uri","label": "Send Image","uri": "line://app/1643727178-0XPGAaRX?type=image&img={}".format(e['display_url'])}},]},"hero": {"type": "image","url": e['display_url'],"size": "full","aspectRatio": "1:1","aspectMode": "fit"},"body": {"type": "box","layout": "vertical","contents": [{"type": "text","text": "POST INFO","weight": "bold","size":"md","margin":"md"},{"type":"separator","color":"#000000"},{"type": "box","layout": "vertical","margin": "lg","spacing": "sm","contents": [{"type": "box","layout": "baseline","spacing": "sm","contents": [{"type": "text","text": "Caption","color": "#aaaaaa","size": "sm","flex": 3},{"type": "text","text": "{}".format(anu),"color": "#262423","size": "sm","wrap": True,"flex": 5}]},{"type": "box","layout": "baseline","spacing": "sm","contents": [{"type": "text","text": "Likes","color": "#aaaaaa","size": "sm","flex": 3},{"type": "text","text": "{}".format(humanize.intcomma(like)),"color": "#262423","size": "sm","flex": 5}]},{"type": "box","layout": "baseline","spacing": "sm","contents": [{"type": "text","text": "Comment","color": "#aaaaaa","size": "sm","flex": 3},{"type": "text","text": "{}".format(humanize.intcomma(comment)),"color": "#262423","wrap": True,"size": "sm","flex": 5}]},{"type": "box","layout": "baseline","spacing": "sm","contents": [{"type": "text","text": "From","color": "#aaaaaa","size": "sm","flex": 3},{"type": "text","text": "@{}".format(usrname),"color": "#262423","wrap": True,"size": "sm","flex": 5}]},{"type": "box","layout": "baseline","spacing": "sm","contents": [{"type": "text","text": "Text","color": "#aaaaaa","size": "sm","flex": 3},{"type": "text","text": "{}".format(komen),"color": "#262423","wrap": True,"size": "sm","flex": 5}]}]}]}})
                k = len(ret_)//10
                for aa in range(k+1):
                    data = {"messages": [{"type": "flex","altText": "Khie sent a flex.","contents": {"type": "carousel","contents": ret_[aa*10 : (aa+1)*10]}}]}
                    sendCarousel(to,data)
        if(cmd.startswith('instagram story ')):
            a = requests.get("https://rest.farzain.com/api/ig_story.php?id={}&apikey=aguzzzz748474848&beta".format(msg.text.split(' ')[2])).text
            a = json.loads(a)
            ret_ = []
            s = [c for c in a['pict_url']]
            for b in a['video_url']:
                print(b)
                if b == 'None':
                    pass
                ret_.append({"type": "bubble","hero": {"type": "image","url": "https://boteater.vip/jpg-5quup28a.jpg","size": "full","aspectRatio": "1:1","aspectMode": "fit",},"footer": {"type": "box","layout": "vertical","spacing": "sm","contents": [{"type": "button","style": "link","height": "sm","action": {"type": "uri","label": "Send Video","uri": "line://app/1643727178-0XPGAaRX?type=video&ocu={}&piu=https://image.freepik.com/free-vector/instagram-icon_1057-2227.jpg".format(b)}},],}})
            k = len(ret_)//10
            for aa in range(k+1):
                data = {"messages": [{"type": "flex","altText": "Khie sent a flex.","contents": {"type": "carousel","contents": ret_[aa*10 : (aa+1)*10]}}]}
                sendCarousel(to,data)

def cytmp4(url):
    import pafy
    vid = pafy.new(url,basic=False)
    result = vid.streams[-1]
    return result.url
def cytmp3(url):
    import pafy
    vid = pafy.new(url,basic=False)
    result = vid.audiostreams[-1]
    return result.url

def YoutubeTempat(liffnya,to,meta,dfghj,links,linkss):
    return {"messages": [{"type": "flex","altText": "Youtube","contents": {"type": "bubble","header": {"type": "box","layout": "horizontal","contents": [{"type": "text","text": "Youtube","weight": "bold","color": "#aaaaaa","size": "sm"}]},"hero": {"type": "image","url": meta['thumbnail'],"size": "full","aspectRatio": "20:13","aspectMode": "fit","action": {"type": "uri","uri": dfghj}},"body": {"type": "box","layout": "vertical","contents": [{"type": "box","layout": "vertical","margin": "lg","spacing": "sm","contents": [{"type": "box","layout": "baseline","spacing": "sm","contents": [{"type": "text","text": "Title","color": "#aaaaaa","size": "sm","flex": 1},{"type": "text","text": "{}".format(meta['title']),"color": "#262423","wrap": True,"size": "sm","flex": 5}]}]}]},"footer": {"type": "box","layout": "horizontal","spacing": "sm","contents": [{"type": "button","style": "link","height": "sm","action": {"type": "uri","label": "Send Video","uri": "line://app/1643727178-0XPGAaRX?type=video&ocu={}&piu={}".format(links,meta['thumbnail'])}},{"type": "button","style": "link","height": "sm","action": {"type": "uri","label": "Send Audio","uri": "line://app/1643727178-0XPGAaRX?type=audio&link={}".format(linkss)}}],"flex": 0}}}]}

def imagegoogle(to,liffnya,cmd):
    a = image_search(noobcoder.adityasplittext(cmd))
    b = random.choice([a[:10],a[10:20],a[20:30],a[30:40],a[40:50],a[50:60],a[60:70],a[70:80]])
    a = b
    ret_ = []
    gimagesa(a,ret_)
    k = len(ret_)//10
    for aa in range(k+1):
        data = {"messages": [{"type": "flex","altText": "image","contents": {"type": "carousel","contents": ret_[aa*10 : (aa+1)*10]}}]}
        h = sendCarousel(to,data)
    return h
def image_search(query):
    images = noobcoder.adityarequestweb('https://api.eater.pw/googleimg?search={}'.format(query))
    return images["result"]
def gimagesa(a,ret_):
        for i in a:
            if '.gif' in i['img']:
                links = 'line://app/1606644641-DAwvRm5p?type=images&imgs='
            else:
                links = 'line://app/1606644641-DAwvRm5p?type=image&img='
            ret_.append({
                                                "type": "bubble",
                                                "hero": {
                                                    "type": "image",
                                                    "url": i,
                                                    "size": "full",
                                                    "aspectRatio": "1:1",
                                                    "aspectMode": "fit",
                                                },
                                                "footer": {
                                                    "type": "box",
                                                    "layout": "vertical",
                                                    "spacing": "sm",
                                                    "contents": [
                                                        {
                                                            "type": "button",
                                                            "style": "link",
                                                            "height": "sm",
                                                            "action": {
                                                                "type": "uri",
                                                                "label": "Send Image",
                                                                "uri": "{}{}".format(links,i)
                                                            }                                                   
                                                        },
                                                    ],
                                                }})
        return ret_
#=====================================================================
def NoteCreate(to,cmd,msg):
    h = []
    s = []
    if cmd == 'mentionnote':
        sakui = noobcoder.getProfile()
        group = noobcoder.getGroup(msg.to);nama = [contact.mid+'||//{}'.format(contact.displayName) for contact in group.members];nama.remove(sakui.mid+'||//{}'.format(sakui.displayName))
        data = nama
        k = len(data)//20
        for aa in range(k+1):
            nos = 0
            if aa == 0:dd = '╭「 Mention Note 」─';no=aa
            else:dd = '├「 Mention Note 」─';no=aa*20
            msgas = dd
            for i in data[aa*20 : (aa+1)*20]:
                no+=1
                if no == len(data):msgas+='\n╰{}. @'.format(no)
                else:msgas+='\n│{}. @'.format(no)
            msgas = msgas
            for i in data[aa*20 : (aa+1)*20]:
                gg = []
                dd = ''
                for ss in msgas:
                    if ss == '@':
                        dd += str(ss)
                        gg.append(dd.index('@'))
                        dd = dd.replace('@',' ')
                    else:
                        dd += str(ss)
                s.append({'type': "RECALL", 'start': gg[nos], 'end': gg[nos]+1, 'mid': str(i.split('||//')[0])})
                nos +=1
            h = noobcoder.createPostGroup(msgas,msg.to,holdingTime=None,textMeta=s)
    else:
        cmd = cmd.replace(msg.text[:12],'')
        if 'MENTION' in msg.contentMetadata.keys()!= None:
            mention = ast.literal_eval(msg.contentMetadata['MENTION'])
            mentionees = mention['MENTIONEES']
            no = 0
            for mention in mentionees:
                ask = no
                nama = str(noobcoder.getContact(mention["M"]))
                h.append(str(cmd.replace('@{}'.format(nama),'@')))
                for b in h:
                    cmd = str(b)
                gg = []
                dd = ''
                for ss in cmd:
                    if ss == '@':
                        dd += str(ss)
                        gg.append(dd.index('@'))
                        dd = dd.replace('@',' ')
                    else:
                        dd += str(ss)
                s.append({'type': "RECALL", 'start': gg[no], 'end': gg[no]+1, 'mid': str(mention["M"])})
                no +=1
        h = noobcoder.createPostGroup(cmd,msg.to,holdingTime=None,textMeta=s)
#=====================================================
def sendMessageCustom(to, text, icon , name):
    annda = {'MSG_SENDER_ICON': icon,
        'MSG_SENDER_NAME':  name,
    }
    noobcoder.sendMessage(to, text, contentMetadata=annda)
def sendMessageCustomContact(to, icon, name, mid):
    annda = { 'mid': mid,
    'MSG_SENDER_ICON': icon,
    'MSG_SENDER_NAME':  name,
    }
    noobcoder.sendMessage(to, '', annda, 13)    
def sendMention(to, mid, firstmessage='', lastmessage=''):
    try:
        arrData = ""
        text = "%s " %(str(firstmessage))
        arr = []
        mention = "@x "
        slen = str(len(text))
        elen = str(len(text) + len(mention) - 1)
        arrData = {'S':slen, 'E':elen, 'M':mid}
        arr.append(arrData)
        text += mention + str(lastmessage)
        try:
            noobcoder.sendMessage(to, text, {'MSG_SENDER_NAME': noobcoder.getContact(mid).displayName,'MSG_SENDER_ICON': "http://dl.profile.line-cdn.net/" + noobcoder.getContact(mid).pictureStatus,'MENTION': str('{"MENTIONEES":' + json.dumps(arr) + '}')}, 0)
        except Exception as e:
            noobcoder.sendMessage(to, text, {'MSG_SENDER_NAME': noobcoder.getContact("u085311ecd9e3e3d74ae4c9f5437cbcb5").displayName,'MSG_SENDER_ICON': 'http://dl.profile.line-cdn.net/' + noobcoder.getContact("u085311ecd9e3e3d74ae4c9f5437cbcb5").pictureStatus,'MENTION': str('{"MENTIONEES":' + json.dumps(arr) + '}')}, 0)
    except Exception as error:
        print(error)
#=====================================================
def fileYtMp4(to, link):
    subprocess.getoutput('youtube-dl --format mp4 --output FileYoutube.mp4 {}'.format(link))
    try:
        noobcoder.sendFile(to, "FileYoutube.mp4")
        time.sleep(2)
        os.remove('FileYoutube.mp4')
    except Exception as e:
        noobcoder.sendMessage(to, ' 「 ERROR 」')
def fileYtMp3(to, link):
    subprocess.getoutput('youtube-dl --extract-audio --audio-format mp3 --output FileYoutube.mp3 {}'.format(link))
    try:
        noobcoder.sendFile(to, 'FileYoutube.mp3')
        time.sleep(2)
        os.remove('FileYoutube.mp3')
    except Exception as e:
        noobcoder.sendMessage(to, ' 「 ERROR 」')
def changeVideoAndPictureProfile(pict, vids):
    try:
        files = {'file': open(vids, 'rb')}
        obs_params = noobcoder.genOBSParams({'oid': noobcoderMID, 'ver': '2.0', 'type': 'video', 'cat': 'vp.mp4'})
        data = {'params': obs_params}
        r_vp = noobcoder.server.postContent('{}/talk/vp/upload.nhn'.format(str(noobcoder.server.LINE_OBS_DOMAIN)), data=data, files=files)
        if r_vp.status_code != 201:
            return "Failed update profile"
        noobcoder.updateProfilePicture(pict, 'vp')
        return "Success update profile"
    except Exception as e:
        raise Exception("Error change video and picture profile {}".format(str(e)))
def youtubeMp4(to, link):
    subprocess.getoutput('youtube-dl --format mp4 --output TeamAnuBot.mp4 {}'.format(link))
    try:
        noobcoder.sendVideo(to, "TeamAnuBot.mp4")
        time.sleep(2)
        os.remove('TeamAnuBot.mp4')
    except Exception as e:
        sendFooter(to, ' 「 ERROR 」\nMungkin Link Nya Salah GaN~')
def youtubeMp3(to, link):
    subprocess.getoutput('youtube-dl --extract-audio --audio-format mp3 --output TeamAnuBot.mp3 {}'.format(link))
    try:
        noobcoder.sendAudio(to, 'TeamAnuBot.mp3')
        time.sleep(2)
        os.remove('TeamAnuBot.mp3')
    except Exception as e:
        sendFooter(to, ' 「 ERROR 」\nMungkin Link Nya Salah GaN~')
def google_url_shorten(url):
    req_url = 'https://www.googleapis.com/urlshortener/v1/url?key=AIzaSyAzrJV41pMMDFUVPU0wRLtxlbEU-UkHMcI'
    payload = {'longUrl': url}
    headers = {'content-type': 'application/json'}
    r = requests.post(req_url, data=json.dumps(payload), headers=headers)
    resp = json.loads(r.text)
    return resp['id'].replace("https://","")
#=====================================================================
def sendMentionFooter(to, mid, firstmessage, lastmessage):
    try:
        arrData = ""
        text = "%s " %(str(firstmessage))
        arr = []
        mention = "@LopeAgri"
        slen = str(len(text))
        elen = str(len(text) + len(mention))
        arrData = {'S':slen, 'E':elen, 'M':mid}
        arr.append(arrData)
        text += mention + str(lastmessage)
        nama = "{}".format(noobcoder.getContact(noobcoderMID).displayName)
        img = "http://dl.profile.line-cdn.net/{}".format(noobcoder.getContact(noobcoderMID).pictureStatus)
        ticket = "https://line.me/ti/p/{}".format(noobcoder.getUserTicket().id)
        noobcoder.sendMessage(to, text, {'AGENT_LINK': ticket, 'AGENT_ICON': img, 'AGENT_NAME': nama, 'MENTION': str('{"MENTIONEES":' + json.dumps(arr) + '}')}, 0)
    except Exception as error:
        logError(error)
        noobcoder.sendMessage(to, "[ INFO ] Error :\n" + str(error))
#=====================================================================
def getTimeLine(to, mid):
        data = noobcoder.getHomeProfile(mid)
        if data['result'] != []:
            try:
                no = 1
                a = " 「 Timeline 」\nCreated by : @!"#+str(data['result']['homeInfo']['userInfo']['nickname'])
                for i in data['result']['feeds']:
                    gtime = i['post']['postInfo']['createdTime']
                    timeCreated = []
                    timeCreated.append(time.strftime("%d-%m-%Y [ %H:%M:%S ]", time.localtime(int(gtime) / 1000)))
                    try:
                        desc ="\n\n" + str(no) + ". Text : "+str(i['post']['contents']['text'])
                    except:
                        desc ="\n\n" + str(no) + ". Text : None"
                    a += str(desc)
                    a +="\n    Total Like : "+str(i['post']['postInfo']['likeCount'])
                    a +="\n    Total Comment : "+str(i['post']['postInfo']['commentCount'])
                    a +="\n    Created on : "+str(timeCreated[0])+"\n"
                    no = (no+1)
                a +="\n\nTotal Post : "+str(data['result']['homeInfo']['postCount'])+" Post."
                return mentions(to,str(a), [mid])
            except:
                return mentions(to, "@! not have timeline", [mid])
#=====================================================================
def mentions(to, text="", mids=[]):
    arrData = ""
    arr = []
    mention = "@KhieGans  "
    if mids == []:
        raise Exception("Invalid mids")
    if "@!" in text:
        if text.count("@!") != len(mids):
            raise Exception("Invalid mids")
        texts = text.split("@!")
        textx = ""
        for mid in mids:
            textx += str(texts[mids.index(mid)])
            slen = len(textx)
            elen = len(textx) + 15
            arrData = {'S':str(slen), 'E':str(elen - 4), 'M':mid}
            arr.append(arrData)
            textx += mention
        textx += str(texts[len(mids)])
    else:
        textx = ""
        slen = len(textx)
        elen = len(textx) + 15
        arrData = {'S':str(slen), 'E':str(elen - 4), 'M':mids[0]}
        arr.append(arrData)
        textx += mention + str(text)
    noobcoder.sendMessage(to, textx, {'AGENT_NAME':'LINE OFFICIAL', 'AGENT_LINK': 'line://ti/p/~{}'.format(noobcoder.getProfile().userid), 'AGENT_ICON': "http://dl.profile.line-cdn.net/" + noobcoder.getContact("u085311ecd9e3e3d74ae4c9f5437cbcb5").picturePath, 'MENTION': str('{"MENTIONEES":' + json.dumps(arr) + '}')}, 0)
#=====================================================================
def load():
    global images
    global stickers
    with open("khie/image.json","r") as fp:
        images = json.load(fp)
    with open("khie/sticker.json","r") as fp:
        stickers = json.load(fp)
def sendStickers(to, sver, spkg, sid):
    contentMetadata = {
        'STKVER': sver,
        'STKPKGID': spkg,
        'STKID': sid
    }
    noobcoder.sendMessage(to, '', contentMetadata, 7)
def sendSticker(to, mid, sver, spkg, sid):
    contentMetadata = {
        'MSG_SENDER_NAME': noobcoder.getContact(mid).displayName,
        'MSG_SENDER_ICON': 'http://dl.profile.line-cdn.net/' + noobcoder.getContact(mid).pictureStatus,
        'STKVER': sver,
        'STKPKGID': spkg,
        'STKID': sid
    }
    noobcoder.sendMessage(to, '', contentMetadata, 7)
def sendImage(to, path, name="image"):
    try:
        if settings["server"] == "VPS":
            noobcoder.sendImageWithURL(to, str(path))
    except Exception as error:
        logError(error)
#=====================================================================
def cloneProfile(mid):
    contact = noobcoder.getContact(mid)
    if contact.videoProfile == None:
        profile = noobcoder.getProfile()
        profile.displayName, profile.statusMessage = contact.displayName, contact.statusMessage
        noobcoder.updateProfile(profile)
        pict = noobcoder.downloadFileURL('http://dl.profile.line-cdn.net/' + contact.pictureStatus, saveAs="tmp/pict.bin")
        noobcoder.updateProfilePicture(pict)
    else:
        profile = noobcoder.getProfile()
        profile.displayName, profile.statusMessage = contact.displayName, contact.statusMessage
        noobcoder.updateProfile(profile)
        pict = noobcoder.downloadFileURL('http://dl.profile.line-cdn.net/' + contact.pictureStatus, saveAs="tmp/pict.bin")
        vids = noobcoder.downloadFileURL( 'http://dl.profile.line-cdn.net/' + contact.pictureStatus + '/vp', saveAs="tmp/video.bin")
        changeVideoAndPictureProfile(pict, vids)
    coverId = noobcoder.getProfileDetail(mid)['result']['objectId']
    noobcoder.updateProfileCoverById(coverId)
def backupProfile():
    profile = noobcoder.getContact(noobcoderMID)
    if settings['myProfile']['videoProfile'] == None:
        settings['myProfile']['displayName'] = profile.displayName
        settings['myProfile']['pictureStatus'] = profile.pictureStatus
        settings['myProfile']['statusMessage'] = profile.statusMessage
        coverId = noobcoder.getProfileDetail()['result']['objectId']
        settings['myProfile']['coverId'] = str(coverId)
        pict = noobcoder.downloadFileURL('http://dl.profile.line-cdn.net/' + profile.pictureStatus, saveAs="tmp/pict.bin")
        noobcoder.updateProfilePicture(pict)
    else:
        settings['myProfile']['displayName'] = profile.displayName
        settings['myProfile']['pictureStatus'] = profile.pictureStatus
        settings['myProfile']['statusMessage'] = profile.statusMessage
        settings['myProfile']['videoProfile'] = profile.videoProfile
        coverId = indonesiandefacer.getProfileDetail()['result']['objectId']
        settings['myProfile']['coverId'] = str(coverId)
def restoreProfile():
    profile = noobcoder.getProfile()
    profile.displayName = settings['myProfile']['displayName']
    profile.statusMessage = settings['myProfile']['statusMessage']
    if settings['myProfile']['videoProfile'] == None:
        pict = noobcoder.downloadFileURL('http://dl.profile.line-cdn.net/' + settings['myProfile']['pictureStatus'], saveAs="tmp/pict.bin")
        noobcoder.updateProfilePicture(pict)
        noobcoder.updateProfile(profile)
    else:
        noobcoder.updateProfile(profile)
        pict = noobcoder.downloadFileURL('http://dl.profile.line-cdn.net/' + settings['myProfile']['pictureStatus'], saveAs="tmp/pict.bin")
        vids = noobcoder.downloadFileURL( 'http://dl.profile.line-cdn.net/' + settings['myProfile']['pictureStatus'] + '/vp', saveAs="tmp/video.bin")
        changeVideoAndPictureProfile(pict, vids)
    coverId = settings['myProfile']['coverId']
    noobcoder.updateProfileCoverById(coverId)
def changeProfileVideo(to):
    if settings['changeProfileVideo']['picture'] == None:
        return noobcoder.sendMessage(to, "Foto tidak ditemukan")
    elif settings['changeProfileVideo']['video'] == None:
        return noobcoder.sendMessage(to, "Video tidak ditemukan")
    else:
        path = settings['changeProfileVideo']['video']
        files = {'file': open(path, 'rb')}
        obs_params = noobcoder.genOBSParams({'oid': noobcoder.getProfile().mid, 'ver': '2.0', 'type': 'video', 'cat': 'vp.mp4'})
        data = {'params': obs_params}
        r_vp = noobcoder.server.postContent('{}/talk/vp/upload.nhn'.format(str(noobcoder.server.LINE_OBS_DOMAIN)), data=data, files=files)
        if r_vp.status_code != 201:
            return noobcoder.sendMessage(to, "Gagal update profile")
        path_p = settings['changeProfileVideo']['picture']
        settings['changeProfileVideo']['status'] = False
        noobcoder.updateProfilePicture(path_p, 'vp')
def backProfileVideo():
    path = settings['changeProfileVideo']['video']
    files = {'file': open(path, 'rb')}
    obs_params = noobcoder.genOBSParams({'oid': noobcoder.getProfile().mid, 'ver': '2.0', 'type': 'video', 'cat': 'vp.mp4'})
    data = {'params': obs_params }
    r_vp = noobcoder.server.postContent('{}/talk/vp/upload.nhn'.format(str(noobcoder.server.LINE_OBS_DOMAIN)), data=data, files=files)
    if r_vp.status_code != 201:
        return noobcoder.sendMessage(to, "Failed")
    path_p = settings['changeProfileVideo']['picture']
    noobcoder.updateProfilePicture(path_p, 'vp')
def lol(to,hehe):
    data = {"messages": [{"type": "text","text": hehe,"sentBy":{"label":"Khie","iconUrl":"https://obs.line-scdn.net/{}".format(noobcoder.getContact(noobcoderMID).pictureStatus),"linkUrl":"https://line.me/ti/p/~khiewuzzheree"}}]}
    sendCarousel(to,data)
def pendekin(to,url):
    req_url = 'https://www.googleapis.com/urlshortener/v1/url?key=AIzaSyAzrJV41pMMDFUVPU0wRLtxlbEU-UkHMcI'
    payload = {'longUrl': url}
    headers = {'content-type': 'application/json'}
    r = requests.post(req_url, data=json.dumps(payload), headers=headers)
    resp = json.loads(r.text)
    return resp['id']
#=====================================================================
def speedtest(secs):
    mins, secs = divmod(secs,60)
    hours, mins = divmod(mins,60)
    days, hours = divmod(hours,24)
    weaks, days = divmod(days,7)
    if days == 0:
        return '%02d' % (secs)
    elif days > 0 and weaks == 0:
        return '%02d' %(secs)
    elif days > 0 and weaks > 0:
        return '%02d' %(secs)
#=====================================================================
def change(url):
	import base64
	return base64.b64encode(url.encode()).decode()
#=====================================================================
def tagdia(to, text="",ps='', mids=[]):
        arrData = ""
        arr = []
        mention = "@MentionOrang "
        if mids == []:
            raise Exception("Invalid mids")
        if "@!" in text:
            if text.count("@!") != len(mids):
                raise Exception("Invalid mids")
            texts = text.split("@!")
            textx = ''
            h = ''
            for mid in range(len(mids)):
                h+= str(texts[mid].encode('unicode-escape'))
                textx += str(texts[mid])
                if h != textx:slen = len(textx)+h.count('U0');elen = len(textx)+h.count('U0') + 13
                else:slen = len(textx);elen = len(textx) + 13
                arrData = {'S':str(slen), 'E':str(elen), 'M':mids[mid]}
                arr.append(arrData)
                textx += mention
            textx += str(texts[len(mids)])
        else:
            textx = ''
            slen = len(textx)
            elen = len(textx) + 18
            arrData = {'S':str(slen), 'E':str(elen - 4), 'M':mids[0]}
            arr.append(arrData)
            textx += mention + str(text)
        noobcoder.sendMessage(to, textx, {'MSG_SENDER_NAME': noobcoder.getContact(ps).displayName,'MSG_SENDER_ICON': "http://dl.profile.line-cdn.net/" + noobcoder.getContact(ps).pictureStatus,'MENTION': str('{"MENTIONEES":' + json.dumps(arr) + '}')}, 0)
#=====================================================================
def timeChange(secs):
    mins, secs = divmod(secs,60)
    hours, mins = divmod(mins,60)
    days, hours = divmod(hours,24)
    weeks, days = divmod(days,7)
    months, weeks = divmod(weeks,4)
    text = ""
    if months != 0: text += "%02d Month" % (months)
    if weeks != 0: text += " %02d Week" % (weeks)
    if days != 0: text += " %02d Day" % (days)
    if hours !=  0: text +=  " %02d Hours" % (hours)
    if mins != 0: text += " %02d Minute" % (mins)
    if secs != 0: text += " %02d Seconds" % (secs)
    if text[0] == " ":
        text = text[1:]
    return text

def debug():
    get_profile_time_start = time.time()
    get_profile = noobcoder.getProfile()
    get_profile_time = time.time() - get_profile_time_start
    return " 「  Time  」\n %.5f" % (get_profile_time)
#=====================================================================
def autoresponuy(to,msg,wait):
    to = msg.to
    if msg.to not in wait["GROUP"]['AR']['AP']:
        return
    if msg.to in wait["GROUP"]['AR']['S']:
        noobcoder.sendMessage(msg.to,text=None,contentMetadata=wait["GROUP"]['AR']['S'][msg.to]['Sticker'], contentType=7)
    if(wait["GROUP"]['AR']['P'][msg.to] in [""," ","\n",None]):
        return
    if '@!' not in wait["GROUP"]['AR']['P'][msg.to]:
        wait["GROUP"]['AR']['P'][msg.to] = '@!'+wait["GROUP"]['AR']['P'][msg.to]
    nama = noobcoder.getGroup(msg.to).name
    sd = noobcoder.waktunjir()
    noobcoder.sendMention(msg.to,wait["GROUP"]['AR']['P'][msg.to].replace('greeting',sd).replace(';',nama),'',[msg._from]*wait["GROUP"]['AR']['P'][msg.to].count('@!'))
def anulurk(to, wait):
    moneys = {}
    for a in wait["setTime"][to].items():
        moneys[a[1]] = [a[0]] if a[1] is not None else idnya
    sort = sorted(moneys)
    sort = sort[0:]
    k = len(sort)//100
    for a in range(k+1):
        if a == 0:no= a;msgas = '╭「 Lurkers 」─'
        else:no = a*100;msgas = '├「 Lurkers 」─'
        h = []
        for i in sort[a*100 : (a+1)*100]:
            h.append(moneys[i][0])
            no+=1
            a = '{}'.format(humanize.naturaltime(datetime.fromtimestamp(i/1000)))
            if no == len(sort):msgas+='\n│{}. @!\n╰    「 {} 」'.format(no,a)
            else:msgas+='\n│{}. @!\n│    「 {} 」'.format(no,a)
        mentions(to, msgas, h)
def logError(text):
    noobcoder.log("ERROR 404 !\n" + str(text))
    tz = pytz.timezone("Asia/Jakarta")
    timeNow = datetime.now(tz=tz)
    timeHours = datetime.strftime(timeNow,"(%H:%M)")
    day = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday","Friday", "Saturday"]
    hari = ["Minggu", "Senin", "Selasa", "Rabu", "Kamis", "Jumat", "Sabtu"]
    bulan = ["Januari", "Februari", "Maret", "April", "Mei", "Juni", "Juli", "Agustus", "September", "Oktober", "November", "Desember"]
    inihari = datetime.now(tz=tz)
    hr = inihari.strftime('%A')
    bln = inihari.strftime('%m')
    for i in range(len(day)):
        if hr == day[i]: hasil = hari[i]
    for k in range(0, len(bulan)):
        if bln == str(k): bln = bulan[k-1]
    time = hasil + ", " + inihari.strftime('%d') + " - " + bln + " - " + inihari.strftime('%Y') + " | " + inihari.strftime('%H:%M:%S')
    with open("khie/errorLog.txt","a") as error:
        error.write("\n[%s] %s" % (str(time), text))
#=====================================================================
#def delExpire():
#    if temp_flood != {}:
#        for tmp in temp_flood:
#            if temp_flood[tmp]["expire"] == True:
#                if time.time() - temp_flood[tmp]["time"] >= 3*10:
#                    temp_flood[tmp]["expire"] = False
#                    temp_flood[tmp]["time"] = time.time()
#                    try:
#                        noobcoder.sendMessage(tmp, "「 Detect Flood 」\nSelfBot has been Enabled ♪")
#                    except Exception as error:
#                        logError(error)
#=====================================================================
def command(text):
    pesan = text.lower()
    if settings["setKey"] == True:
        if pesan.startswith(settings["keyCommand"]):
            cmd = pesan.replace(settings["keyCommand"],"")
        else:
            cmd = "Undefined command"
    else:
        cmd = text.lower()
    return cmd
#=====================================================================
def removeCmd(cmd, text):
	key = settings["keyCommand"]
	if settings["setKey"] == False: key = ''
	rmv = len(key + cmd) + 1
	return text[rmv:]
#=====================================================================
def backupData():
    try:
        backup = settings
        f = codecs.open('khie/temp.json','w','utf-8')
        json.dump(backup, f, sort_keys=True, indent=4, ensure_ascii=False)
        backup = stickers
        f = codecs.open('khie/sticker.json','w','utf-8')
        json.dump(backup, f, sort_keys=True, indent=4, ensure_ascii=False)
        backup = images
        f = codecs.open('khie/image.json','w','utf-8')
        json.dump(backup, f, sort_keys=True, indent=4, ensure_ascii=False)
        backup = seens
        f = codecs.open('khie/lastseen.json','w','utf-8')
        json.dump(backup, f, sort_keys=True, indent=4, ensure_ascii=False)
        backup = wait
        f = codecs.open('khie/wait.json','w','utf-8')
        json.dump(backup, f, sort_keys=True, indent=4, ensure_ascii=False)
        backup = contacts
        f = codecs.open('khie/contact.json','w','utf-8')
        json.dump(backup, f, sort_keys=True, indent=4, ensure_ascii=False)
        backup = stickers1
        f = codecs.open('khie/sticker1.json','w','utf-8')
        json.dump(backup, f, sort_keys=True, indent=4, ensure_ascii=False)
        backup = stickers2
        f = codecs.open('khie/sticker2.json','w','utf-8')
        json.dump(backup, f, sort_keys=True, indent=4, ensure_ascii=False)
        backup = anumu
        f = codecs.open('khie/stickertemp.json','w','utf-8')
        json.dump(backup, f, sort_keys=True, indent=4, ensure_ascii=False)
        backup = groupName
        f = codecs.open('khie/groupname.json','w','utf-8')
        json.dump(backup, f, sort_keys=True, indent=4, ensure_ascii=False)
        backup = groupQr
        f = codecs.open('khie/groupqr.json','w','utf-8')
        json.dump(backup, f, sort_keys=True, indent=4, ensure_ascii=False)
        backup = protectKick
        f = codecs.open('khie/protectkick.json','w','utf-8')
        json.dump(backup, f, sort_keys=True, indent=4, ensure_ascii=False)
        backup = blockInvite
        f = codecs.open('khie/blockinvite.json','w','utf-8')
        json.dump(backup, f, sort_keys=True, indent=4, ensure_ascii=False)
        backup = notag
        f = codecs.open('khie/notag.json','w','utf-8')
        json.dump(backup, f, sort_keys=True, indent=4, ensure_ascii=False)
        return True
    except Exception as error:
        logError(error)
        return False
#=====================================================================
async def noobcoderBot(op):
    try:
        if settings["restartPoint"] != None:
            noobcoder.sendMessage(settings["restartPoint"], 'Activated♪')
            settings["restartPoint"] = None
        if op.type == 0:
            return
        if op.type == 5:
            print ("[ 5 ] NOTIFIED AUTO BLOCK CONTACT")
            if blocked["autoBlock"]:
                noobcoder.blockContact(op.param1)
                noobcoder.sendMessage(op.param1, blocked["pesanya"])
        if op.type == 5:
            if(settings["addPesan"] in [""," ","\n",None]):
                return
            if '@!' not in settings["addPesan"]:
                settings["addPesan"] = '@!'+settings["addPesan"]
            sd = noobcoder.waktunjir()
            noobcoder.sendMention(op.param1,settings["addPesan"].replace('greeting',sd),' 「 Autoadd 」\n',[op.param1]*settings["addPesan"].count('@!'))
            msgSticker = settings["messageSticker"]["listSticker"]["addSticker"]
            if msgSticker != None:
                sid = msgSticker["STKID"]
                spkg = msgSticker["STKPKGID"]
                sver = msgSticker["STKVER"]
                sendSticker(op.param1, op.param1, sver, spkg, sid)
            if settings["autoAdd"] == True:noobcoder.findAndAddContactsByMid(op.param1)
#=====================================================================
        if op.type == 11:
            print ("[ 11 ] NOTIFIED UPDATE GROUP")
            if op.param3 == "1" and op.param1 in groupName:
                if op.param2 not in noobcoderMID:
                    try:
                        sendFooter1(op.param1,"Don't change name group")
                        try: noobcoder.kickoutFromGroup(op.param1,[op.param2])
                        except: sendFooter(op.param1, "Limeted")
                        G = noobcoder.getGroup(op.param1)
                        G.name = groupName[op.param1]
                        noobcoder.updateGroup(G)
                    except:
                        pass
            if op.param3 == "4" and op.param1 in groupQr:
                if op.param2 not in noobcoderMID:
                    try:
                        sendFooter1(op.param1,"Don't playing code QR")
                        try: noobcoder.kickoutFromGroup(op.param1,[op.param2])
                        except: sendFooter1(op.param1, "Limeted")
                        group = noobcoder.getGroup(op.param1)
                        group.preventedJoinByTicket = True
                        contact = noobcoder.getContact(op.param2)
                        noobcoder.updateGroup(group)
                    except:
                        pass
#=====================================================================
        if op.type == 13:
            if noobcoder.getProfile().mid in op.param3:
                G = noobcoder.getCompactGroup(op.param1)
                if settings["autoJoin"] == True:
                    if len(G.members) <= wait["Members"]:
                        noobcoder.acceptGroupInvitation(op.param1)
#                        mentions(op.param1,"Hallo @! You Are Not My Author\nI Leave , See ya",[op.param2])
                        noobcoder.leaveGroup(op.param1)
                    else:
                        noobcoder.acceptGroupInvitation(op.param1)
                if len(G.members) <= wait["Members"]:
                    noobcoder.rejectGroupInvitation(op.param1)
                else:
                    if admin in op.param2:
                        noobcoder.acceptGroupInvitation(op.param1)
            else:pass
#=====================================================================
        if op.type == 13:
            print (">OP 13<")
            if op.param1 in blockInvite:
                if op.param2 not in noobcoderMID:
                    group = noobcoder.getCompactGroup(op.param1)
                    targets = [contact.mid for contact in group.invitee]
                    for target in targets:
                        if target in op.param3:
                            try:
                                try:
                                    noobcoder.cancelGroupInvitation(op.param1,[target])
                                    noobcoder.kickoutFromGroup(op.param1,[op.param2])
                                except:
                                    noobcoder.kickoutFromGroup(op.param1,[target])
                                    noobcoder.kickoutFromGroup(op.param1,[op.param2])
                            except:
                                pass
#=====================================================================
        if op.type == 15:
            if op.param1 in wait["GROUP"]['LM']['AP']:
                if op.param1 in wait["GROUP"]['LM']['S']:
                    noobcoder.sendMessage(op.param2,text=None,contentMetadata=wait["GROUP"]['LM']['S'][op.param1]['Sticker'], contentType=7)
                noobcoder.sendMention(op.param2, "{}".format(wait["GROUP"]['LM']['P'][op.param1].replace('|',' @!')),' 「 Leave Detect 」\n',[op.param2])
#=====================================================================
        if op.type == 15:
            print ("[ 15 ] NOTIFIED LEAVE GROUP")
            if lvin["lMessage"] == True:
                mat = noobcoder.getContact(op.param2)
                fit = noobcoder.getCompactGroup(op.param1)
                pesanya = lvin["textnya"]
                data={"type":"flex","altText":"NOOB CODER™","contents":{
  "type": "bubble",
  "body": {
    "type": "box",
    "layout": "vertical",
    "contents": [
      {
        "type": "text",
        "text": "LEAVE MESSAGE",
        "size": "md",
        "color": "{}".format(setbot["text"]),
        "weight": "bold",
        "align": "center"
      },
      {
        "type": "box",
        "layout": "vertical",
        "contents": [
          {
            "type": "spacer"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "separator",
                "color": "{}".format(setbot["separator"]),
                "margin": "md"
              },
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "image",
                    "url": "https://obs.line-scdn.net/{}".format(mat.pictureStatus),
                    "align": "center",
                    "size": "xxl",
                    "aspectMode": "fit",
                    "aspectRatio": "2:1",
                    "action": {
                      "type": "uri",
                      "label": "action",
                      "uri": "line://ti/p/~khiewuzzheree"
                    }
                  },
                  {
                    "type": "separator",
                    "color": "{}".format(setbot["background"]),
                    "margin": "lg"
                  },
                  {
                    "type": "box",
                    "layout": "horizontal",
                    "contents": [
                      {
                        "type": "text",
                        "text": "Bye bye {}".format(str(mat.displayName)),
                        "size": "sm",
                        "color": "{}".format(setbot["text"]),
                        "weight": "bold",
                        "flex": 0,
                        "align": "center",
                        "wrap": True
                      }
                    ],
                    "spacing": "sm"
                  },
                  {
                    "type": "box",
                    "layout": "horizontal",
                    "contents": [
                      {
                        "type": "text",
                        "text": "{}".format(pesanya),
                        "size": "sm",
                        "color": "{}".format(setbot["text"]),
                        "weight": "bold",
                        "flex": 0,
                        "align": "center",
                        "wrap": True
                      }
                    ],
                    "spacing": "sm"
                  }
                ]
              },
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "separator",
                    "color": "{}".format(setbot["separator"]),
                    "margin": "lg"
                  },
                  {
                    "type": "box",
                    "layout": "horizontal",
                    "contents": [
                      {
                        "type": "box",
                        "layout": "horizontal",
                        "contents": [
                          {
                            "type": "image",
                            "url": "https://i.ibb.co/4mbftvy/IMG-20190809-211441.jpg",
                            "size": "xxs",
                            "align": "start"
                          }
                        ],
                        "width": "25px",
                        "height": "25px",
                        "borderWidth": "2px",
                        "borderColor": "{}".format(setbot["separator"]),
                        "cornerRadius": "xl"
                      },
                      {
                        "type": "box",
                        "layout": "vertical",
                        "spacing": "sm",
                        "contents": [
                          {
                            "type": "text",
                            "text": "FREE SELFBOT",
                            "size": "md",
                            "color": "{}".format(setbot["text"]),
                            "align": "center",
                            "margin": "sm",
                            "action": {
                              "type": "uri",
                              "label": "action",
                              "uri": "https://line.me/ti/p/~" + noobcoder.profile.userid
                            }
                          }
                        ]
                      }
                    ],
                    "margin": "lg"
                  }
                ],
                "spacing": "sm",
                "margin": "md"
              }
            ]
          }
        ],
        "margin": "sm"
      }
    ],
    "borderColor": "{}".format(setbot["separator"]),
    "cornerRadius": "xl",
    "borderWidth": "4px"
  },
  "styles": {
    "body": {
      "backgroundColor": "{}".format(setbot["background"])
    }
  }
}}
                sendTemplate(op.param1,data)
#=====================================================================
        if op.type == 17:
            print ("[ 17 ] NOTIFIED INVITE INTO GROUP")
            if wmin["wMessage"] == True:
                mat = noobcoder.getContact(op.param2)
                fit = noobcoder.getCompactGroup(op.param1)
                pesanya = wmin["textnya"]
                data={"type":"flex","altText":"NOOB CODER™","contents":{
  "type": "bubble",
  "body": {
    "type": "box",
    "layout": "vertical",
    "contents": [
      {
        "type": "text",
        "text": "WELCOME MESSAGE",
        "size": "md",
        "color": "{}".format(setbot["text"]),
        "weight": "bold",
        "align": "center"
      },
      {
        "type": "box",
        "layout": "vertical",
        "contents": [
          {
            "type": "spacer"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "separator",
                "color": "{}".format(setbot["separator"]),
                "margin": "md"
              },
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "image",
                    "url": "https://obs.line-scdn.net/{}".format(mat.pictureStatus),
                    "align": "center",
                    "size": "xxl",
                    "aspectMode": "fit",
                    "aspectRatio": "2:1",
                    "action": {
                      "type": "uri",
                      "label": "action",
                      "uri": "line://ti/p/~khiewuzzheree"
                    }
                  },
                  {
                    "type": "separator",
                    "color": "{}".format(setbot["background"]),
                    "margin": "lg"
                  },
                  {
                    "type": "box",
                    "layout": "horizontal",
                    "contents": [
                      {
                        "type": "text",
                        "text": "Hello {}".format(str(mat.displayName)),
                        "size": "sm",
                        "color": "{}".format(setbot["text"]),
                        "weight": "bold",
                        "flex": 0,
                        "align": "center",
                        "wrap": True
                      }
                    ],
                    "spacing": "sm"
                  },
                  {
                    "type": "box",
                    "layout": "horizontal",
                    "contents": [
                      {
                        "type": "text",
                        "text": "Welcome to {}".format(str(fit.name)),
                        "size": "sm",
                        "color": "{}".format(setbot["text"]),
                        "weight": "bold",
                        "flex": 0,
                        "align": "center",
                        "wrap": True
                      }
                    ],
                    "spacing": "sm"
                  },
                  {
                    "type": "box",
                    "layout": "horizontal",
                    "contents": [
                      {
                        "type": "text",
                        "text": "{}".format(pesanya),
                        "size": "sm",
                        "color": "{}".format(setbot["text"]),
                        "weight": "bold",
                        "flex": 0,
                        "align": "center",
                        "wrap": True
                      }
                    ],
                    "spacing": "sm"
                  }
                ]
              },
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "separator",
                    "color": "{}".format(setbot["separator"]),
                    "margin": "lg"
                  },
                  {
                    "type": "box",
                    "layout": "horizontal",
                    "contents": [
                      {
                        "type": "box",
                        "layout": "horizontal",
                        "contents": [
                          {
                            "type": "image",
                            "url": "https://i.ibb.co/4mbftvy/IMG-20190809-211441.jpg",
                            "size": "xxs",
                            "align": "start"
                          }
                        ],
                        "width": "25px",
                        "height": "25px",
                        "borderWidth": "2px",
                        "borderColor": "{}".format(setbot["separator"]),
                        "cornerRadius": "xl"
                      },
                      {
                        "type": "box",
                        "layout": "vertical",
                        "spacing": "sm",
                        "contents": [
                          {
                            "type": "text",
                            "text": "FREE SELFBOT",
                            "size": "md",
                            "color": "{}".format(setbot["text"]),
                            "align": "center",
                            "margin": "sm",
                            "action": {
                              "type": "uri",
                              "label": "action",
                              "uri": "https://line.me/ti/p/~" + noobcoder.profile.userid
                            }
                          }
                        ]
                      }
                    ],
                    "margin": "lg"
                  }
                ],
                "spacing": "sm",
                "margin": "md"
              }
            ]
          }
        ],
        "margin": "sm"
      }
    ],
    "borderColor": "{}".format(setbot["separator"]),
    "cornerRadius": "xl",
    "borderWidth": "4px"
  },
  "styles": {
    "body": {
      "backgroundColor": "{}".format(setbot["background"])
    }
  }
}}
                sendTemplate(op.param1,data)
#=====================================================================
        if op.type == 17:
            if op.param1 in wait["GROUP"]['WM']['AP']:
                if op.param1 in wait["GROUP"]['WM']['S']:
                    noobcoder.sendMessage(op.param1,text=None,contentMetadata=wait["GROUP"]['WM']['S'][op.param1]['Sticker'], contentType=7)
                if(wait["GROUP"]['WM']['P'][op.param1] in [""," ","\n",None]):
                    return
                if '@!' not in wait["GROUP"]['WM']['P'][op.param1]:
                    wait["GROUP"]['WM']['P'][op.param1] = '@!'+wait["GROUP"]['WM']['P'][op.param1]
                nama = noobcoder.getGroup(op.param1).name
                sd = noobcoder.waktunjir()
                noobcoder.sendMention(op.param1,wait["GROUP"]['WM']['P'][op.param1].replace('greeting',sd).replace('Greeting',sd).replace(';',nama),' 「 Welcome Message 」\n',[op.param2]*wait["GROUP"]['WM']['P'][op.param1].count('@!'))
        if op.type == 17:
            if op.param2 in wait["blacklist"]:
                try:
                    group = noobcoder.getGroup(op.param1)
                    group.preventedJoinByTicket = True
                    noobcoder.updateGroup(group)
                    noobcoder.kickoutFromGroup(op.param1,[op.param2])
                    group.preventedJoinByTicket = True
                    noobcoder.updateGroup(group)
                except Exception as e:
                    group = noobcoder.getGroup(op.param1)
                    group.preventedJoinByTicket = True
                    noobcoder.kickoutFromGroup(op.param1,[op.param2])
                    noobcoder.updateGroup(group)
#=====================================================================
        if op.type == 19:
            if op.param1 in protectKick:
                if op.param2 not in noobcoderMID:
                    try:
                        noobcoder.sendMessage(op.param1, "Kick Detected , Protection on in this Group")
                        try: noobcoder.kickoutFromGroup(op.param1,[op.param2])
                        except: noobcoder.sendMessage(op.param1, "Limited")
                        noobcoder.sendContact(op.param1, op.param2)
                    except:
                        pass
#=====================================================================
        if op.type in [22,24]:
#    	if noobcoder.getProfile().mid in op.param3:
            if mcroom["leaveMC"] == True:
                noobcoder.sendMessage(op.param1,"See yaa !")
                noobcoder.leaveRoom(op.param1)
        if op.type == 26:
            print ("[ 26 ] RECEIVE MESSAGE")
            msg = op.message
            text = str(msg.text)
            msg_id = msg.id
            receiver = msg.to
            sender = msg._from
            to = msg.to
            cmd = command(text)
            isValid = True
            setKey = settings["keyCommand"].title()
            if settings["setKey"] == False: setKey = ''
            if isValid != False:
                if msg.contentType == 0 and sender not in noobcoderMID and msg.toType == 2:
                    if 'MENTION' in msg.contentMetadata.keys() != None:
                        if sets["tagsticker"] == True:
                            name = re.findall(r'@(\w+)', msg.text)
                            mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                            mentionees = mention['MENTIONEES']
                            for mention in mentionees:
                                 if noobcoderMID in mention["M"]:
                                      msg = sets["messageStickerz"]["listStickerz"]["responSticker"]
                                      if msg != None:
                                          contact = noobcoder.getContact(noobcoderMID)
                                          sid = msg['STKID']
                                          spkg = msg['STKPKGID']
                                          a = noobcoder.shop.getProduct(packageID=int(spkg), language='ID', country='ID')
                                          if a.hasAnimation == True:data = {"type": "template","altText": "{} sent a sticker.".format(noobcoder.getProfile().displayName),"template": {"type": "image_carousel","columns": [{"imageUrl": "https://stickershop.line-scdn.net/stickershop/v1/sticker/{}/IOS/sticker_animation@2x.png".format(sid),"size": "full","action": {"type": "uri","uri": "http://line.me/S/sticker/{}".format(spkg)}}]}}
                                          else:data = {"type": "template","altText": "{} sent a sticker.".format(noobcoder.getProfile().displayName),"template": {"type": "image_carousel","columns": [{"imageUrl": "https://stickershop.line-scdn.net/stickershop/v1/sticker/{}/IOS/sticker@2x.png".format(sid),"size": "full","action": {"type": "uri","uri": "http://line.me/S/sticker/{}".format(spkg)}}]}}
                                          sendTemplate(to, data)
                                      else:
                                          contact = noobcoder.getContact(noobcoderMID)
                                          sid = msg['STKID']
                                          spkg = msg['STKPKGID']
                                          a = noobcoder.shop.getProduct(packageID=int(spkg), language='ID', country='ID')
                                          if a.hasAnimation == True:data = {"type": "template","altText": "{} sent a sticker.".format(noobcoder.getProfile().displayName),"template": {"type": "image_carousel","columns": [{"imageUrl": "https://stickershop.line-scdn.net/stickershop/v1/sticker/{}/IOS/sticker_animation@2x.png".format(sid),"size": "full","action": {"type": "uri","uri": "http://line.me/S/sticker/{}".format(spkg)}}]}}
                                          else:data = {"type": "template","altText": "{} sent a sticker.".format(noobcoder.getProfile().displayName),"template": {"type": "image_carousel","columns": [{"imageUrl": "https://stickershop.line-scdn.net/stickershop/v1/sticker/{}/IOS/sticker@2x.png".format(sid),"size": "full","action": {"type": "uri","uri": "http://line.me/S/sticker/{}".format(spkg)}}]}}
                                          sendTemplate(to, data)
#=====================================================================
        if op.type in [25, 26]:
            if op.type == 25: print ("[ 25 ] KHIE SEND MESSAGE")
            else: print ("[ 26 ] KHIE RECEIVE MESSAGE")
            msg = op.message
            text = str(msg.text)
            msg_id = msg.id
            receiver = msg.to
            sender = msg._from
            to = msg.to
            cmd = command(text)
            isValid = True
            setKey = settings["keyCommand"].title()
            if settings["setKey"] == False: setKey = ''
            if isValid != False:
                if msg.toType == 0 and sender != noobcoderMID: to = sender
                else: to = receiver
            if komen["komenan"] == True:
                if msg.contentType == 16:
                    try:
                        purl = msg.contentMetadata["postEndUrl"].split('userMid=')[1].split('&postId=')
                        if purl[1] not in wait['postId']:
                            noobcoder.likePost(purl[0], purl[1], random.choice([1001,1002,1003,1004,1005]))
                            sendFooter(to, "Your post has been liked")
                            noobcoder.createComment(purl[0], purl[1], settings["commentPost"])
                            wait['postId'].append(purl[1])
                        else:
                            pass
                    except Exception as e:
                        purl = msg.contentMetadata['postEndUrl'].split('homeId=')[1].split('&postId=')
                        if purl[1] not in wait['postId']:
                            noobcoder.likePost(msg._from, purl[1], random.choice([1001,1002,1003,1004,1005]))
                            sendFooter(to, "Your post has been liked")
                            noobcoder.createComment(msg._from, purl[1], settings["commentPost"])
                            wait['postId'].append(purl[1])
                        else:pass
#=====================================================================
        if op.type in [25, 26]:
            if op.type == 25: print ("[ 25 ] SEND MESSAGE")
            else: print ("[ 26 ] RECEIVE MESSAGE")
            msg = op.message               
            text = msg.text
            msg_id = msg.id
            receiver = msg.to             
            sender = msg._from
            s = noobcoder.getProfile().mid
            setKey = settings["keyCommand"].title()
            if settings["setKey"] == False:
               setKey = ''
            if msg.toType == 0 or msg.toType == 1 or msg.toType == 2:
                if msg.toType == 0:                    	
                    if sender != noobcoder.profile.mid:
                        to = sender
                    else:
                        to = receiver
                elif msg.toType == 1:
                    to = receiver
                elif msg.toType == 2:
                    to = receiver
                if msg.contentType == 0:
                    if text is None:
                        return
                    else:
                        cmd = command(text)
                        if sender != s:
                	        peler["receivercount"] += 1
                        if sender == s:
                	        peler["sendcount"] += 1
                elif msg.contentType == 7: # Content type is sticker
                    if to in tikelin["stikernya"]:
                        if 'STKOPT' in msg.contentMetadata:
                            contact = noobcoder.getContact(sender)
                            A = contact.displayName
                            stk = msg.contentMetadata['STKID']
                            spk = msg.contentMetadata['STKPKGID']
                            data={'type':'template','altText': str(A)+' send a sticker','template':{'type':'image_carousel','columns':[{'imageUrl':'https://stickershop.line-scdn.net/stickershop/v1/sticker/{}/IOS/sticker_animation@2x.png'.format(stk),'action':{'type':'uri','uri':'https://line.me/S/sticker/{}'.format(spk)}}]}}
                            sendTemplate(to, data)
                        else:
                            contact = noobcoder.getContact(sender)
                            A = contact.displayName
                            stk = msg.contentMetadata['STKID']
                            spk = msg.contentMetadata['STKPKGID']
                            data={'type':'template','altText': str(A)+' send a sticker','template':{'type':'image_carousel','columns':[{'imageUrl':'https://stickershop.line-scdn.net/stickershop/v1/sticker/{}/IOS/sticker@2x.png'.format(stk),'action':{'type':'uri','uri':'https://line.me/S/sticker/{}'.format(spk)}}]}}
                            sendTemplate(to, data)
                    if sender in mimikin["mimic"]["target"] and mimikin["mimic"]["status"] == True and mimikin["mimic"]["target"][sender] == True:
                        if 'STKOPT' in msg.contentMetadata:
                            contact = noobcoder.getContact(sender)
                            A = contact.displayName
                            stk = msg.contentMetadata['STKID']
                            spk = msg.contentMetadata['STKPKGID']
                            data={'type':'template','altText': str(A)+' send a sticker','template':{'type':'image_carousel','columns':[{'imageUrl':'https://stickershop.line-scdn.net/stickershop/v1/sticker/{}/IOS/sticker_animation@2x.png'.format(stk),'action':{'type':'uri','uri':'https://line.me/S/sticker/{}'.format(spk)}}]}}
                            sendTemplate(to, data)
                        else:
                            contact = noobcoder.getContact(sender)
                            A = contact.displayName
                            stk = msg.contentMetadata['STKID']
                            spk = msg.contentMetadata['STKPKGID']
                            data={'type':'template','altText': str(A)+' send a sticker','template':{'type':'image_carousel','columns':[{'imageUrl':'https://stickershop.line-scdn.net/stickershop/v1/sticker/{}/IOS/sticker@2x.png'.format(stk),'action':{'type':'uri','uri':'https://line.me/S/sticker/{}'.format(spk)}}]}}
                            sendTemplate(to, data)
                elif msg.contentType == 13:
                    if settings["checkContact"] == True:
                        try:
                            contact = noobcoder.getContact(msg.contentMetadata["mid"])
                            if client != None:
                                cover = noobcoder.getProfileCoverURL(msg.contentMetadata["mid"])
                            else:
                                cover = "Tidak dapat masuk di line channel"
                            path = "http://dl.profile.line-cdn.net/{}".format(str(contact.pictureStatus))
                            try:
                                noobcoder.sendImageWithURL(to, str(path))
                            except:
                                pass
                            ret_ = "「 Detail Contact 」\n"
                            ret_ += "\nName : {}".format(str(contact.displayName))
                            ret_ += "\nMID : {}".format(str(msg.contentMetadata["mid"]))
                            ret_ += "\nBio : {}".format(str(contact.statusMessage))
                            ret_ += "\nImage Profile : http://dl.profile.line-cdn.net/{}".format(str(contact.pictureStatus))
                            ret_ += "\nImage Cover : {}".format(str(cover))
                            sendFooter(to, str(ret_))
                        except:
                            sendFooter(to, "Kontak tidak valid")
        if op.type in (25,26):
          if to in sniffin["sniff"]:
            try:
                print(msg.contentMetadata)
                msg = op.message
                text = str(msg.text)
                msg_id = msg.id
                receiver = msg.to
                sender = msg._from
                if msg.toType == 0 or msg.toType == 1 or msg.toType == 2:
                    if msg.toType == 0:
                        if sender != noobcoder.profile.mid:
                            to = sender
                        else:
                            to = receiver
                    elif msg.toType == 1:
                        to = receiver
                    elif msg.toType == 2:
                        to = receiver
                        if msg.contentMetadata in ({},{'EMTVER': '4'}):
                            pass
                        else:
                            noobcoder.sendMessage(to, str(msg.contentMetadata))
            except Exception as error:
                logError(error)
#=====================================================================
        if op.type == 26:
            print ("[ 26 ] RECEIVE MESSAGE")
            msg = op.message
            text = str(msg.text)
            msg_id = msg.id
            receiver = msg.to
            sender = msg._from
            to = msg.to
            cmd = command(text)
            isValid = True
            setKey = settings["keyCommand"].title()
            if settings["setKey"] == False: setKey = ''
            if isValid != False:
                if msg.toType == 0 and sender != noobcoderMID: to = sender
                else: to = receiver
                if msg.contentType == 6:
                    try:
                        contact = noobcoder.getContact(sender)
                        if msg.toType == 2:
                            anu = noobcoder.getGroup(to)
                            if msg.contentMetadata['GC_EVT_TYPE'] == 'S' and msg.contentMetadata['GC_MEDIA_TYPE'] == 'LIVE':
                                anu = msg.contentMetadata={'GC_EVT_TYPE': 'S', 'GC_CHAT_MID': to, 'RESULT': 'INFO', 'SKIP_BADGE_COUNT': 'false', 'GC_IGNORE_ON_FAILBACK': 'false', 'TYPE': 'G', 'DURATION': '0', 'GC_MEDIA_TYPE': 'VIDEO', 'VERSION': 'X', 'CAUSE': '16'}
                    except Exception as e:
                        noobcoder.sendMessage(to, str(e))
#=====================================================================
        if op.type == 26:
            print ("[ 26 ] RECEIVE MESSAGE")
            msg = op.message
            text = str(msg.text)
            msg_id = msg.id
            receiver = msg.to
            sender = msg._from
            cmd = command(text)
            setKey = settings["keyCommand"].title()
            if settings["setKey"] == False: setKey = ""
            isValid = True
            if isValid != False:
                if msg.toType == 0 and sender != noobcoderMID: to = sender
                else: to = receiver
                if msg.toType == 0 and settings["autoReply"] and sender != noobcoderMID:
                    contact = noobcoder.getContact(sender)
                    if contact.attributes != 32 and "[ auto reply ]" not in text.lower():
                        msgSticker = settings["messageSticker"]["listSticker"]["replySticker"]
                        if msgSticker != None:
                            sid = msgSticker["STKID"]
                            spkg = msgSticker["STKPKGID"]
                            sver = msgSticker["STKVER"]
                            sendSticker(to, sver, spkg, sid)
                        if "@!" in settings["replyPesan"]:
                            msg_ = settings["replyPesan"].split("@!")
                            sendMention(to, sender, "「Sleep Mode」\n" + msg_[0], msg_[1])
                        sendMention(to, sender, "「Sleep Mode」\nHalo", settings["replyPesan"])
#=====================================================================
        if op.type == 26:
            print ("[ 26 ] RECEIVE MESSAGE")
            msg = op.message
            text = str(msg.text)
            msg_id = msg.id
            receiver = msg.to
            sender = msg._from
            to = msg.to
            cmd = command(text)
            noobcoder.ReceiveMessage(msg, settings, chatbot)
            isValid = True
            setKey = settings["keyCommand"].title()
            if settings["setKey"] == False: setKey = ''
            if isValid != False:
                if msg.toType == 0 and sender != noobcoderMID: to = sender
                else: to = receiver
                if msg.contentType == 0 and sender not in noobcoderMID:
                    if 'MENTION' in msg.contentMetadata.keys()!= None:
                        mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                        mentionees = mention['MENTIONEES']
                        for mention in mentionees:
                            if noobcoderMID in mention["M"]:
                                if to not in wait['ROM']:
                                    wait['ROM'][to] = {}
                                if msg._from not in wait['ROM'][to]:
                                    wait['ROM'][to][msg._from] = {}
                                if 'msg.id' not in wait['ROM'][to][msg._from]:
                                    wait['ROM'][to][msg._from]['msg.id'] = []
                                if 'waktu' not in wait['ROM'][to][msg._from]:
                                    wait['ROM'][to][msg._from]['waktu'] = []
                                wait['ROM'][to][msg._from]['msg.id'].append(msg.id)
                                wait['ROM'][to][msg._from]['waktu'].append(msg.createdTime)
                                autoresponuy(to,msg,wait)
                                break
                if msg._from not in noobcoderMID:
                  if apalo["talkban"] == True:
                    if msg._from in apalo["Talkblacklist"]:
                        noobcoder.sendMention(to, "I said the fuck up @!:)","",[msg._from])
                        noobcoder.kickoutFromGroup(msg.to, [msg._from])
                if 'MENTION' in msg.contentMetadata.keys() != None:
                    if settings["notag"] == True:
                        name = re.findall(r'@(\w+)', msg.text)
                        mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                        mentionees = mention['MENTIONEES']
                        for mention in mentionees:
                            if noobcoderMID in mention["M"]:
                               noobcoder.sendMention(to, "I said the fuck up @!:)","",[msg._from])
                               noobcoder.kickoutFromGroup(msg.to, [msg._from])
                               break
                if to in notag:
                    try:
                        noobcoder.sendMention(to, "I said the fuck up @!:)","",[msg._from])
                        noobcoder.kickoutFromGroup(msg.to, [msg._from])
                    except: pass
                else: pass
                if 'MENTION' in msg.contentMetadata.keys() != None:
                    if wuts["wut"] == True:
                        name = re.findall(r'@(\w+)', msg.text)
                        mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                        mentionees = mention['MENTIONEES']
                        for mention in mentionees:
                            if noobcoderMID in mention["M"]:                      	
                                data = {
                                    "type": "template",
                                    "altText": "whut ?",
                                    "template": {
                                        "type": "image_carousel",
                                        "columns": [
                                            {
                                                "imageUrl": "https://stickershop.line-scdn.net/stickershop/v1/sticker/2172521/IOS/sticker@2x.png",
                                                "size": "full",
                                                "action": {
                                                    "type": "uri",
                                                    "uri": "line://ti/p/~khiewuzzheree"
                                                }
                                            }
                                        ]
                                    }
                                }
                                sendTemplate(to, data)
                if 'MENTION' in msg.contentMetadata.keys() != None:
                    if temptag["stealtag"] == True:
                        name = re.findall(r'@(\w+)', msg.text)
                        mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                        mentionees = mention['MENTIONEES']
                        for mention in mentionees:
                            if noobcoderMID in mention["M"]:                      	
                                contact = noobcoder.getContact(sender)
                                textnya = temptag["pesanya"]
                                data={"type":"flex","altText":"NOOB CODER™","contents":{
  "type": "bubble",
  "body": {
    "type": "box",
    "layout": "vertical",
    "contents": [
      {
        "type": "box",
        "layout": "horizontal",
        "contents": [
          {
            "type": "image",
            "url":"https://obs.line-scdn.net/{}".format(contact.pictureStatus),
            "flex": 0,
            "size": "sm",
            "aspectRatio": "1:1",
            "aspectMode": "cover",
            "gravity": "bottom"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "AUTO RESPON",
                "wrap": True, 
                "align": "center",
                "color": "{}".format(setbot["text"]),
                "size": "md",
                "weight": "bold"
              }
            ]
          }
        ]
      },
      {
        "type": "box",
        "layout": "vertical",
        "contents": [
          {
            "type": "separator",
            "color": "{}".format(setbot["background"])
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text":"Hello , {}".format(contact.displayName),
                "size": "md",
                "color": "{}".format(setbot["text"]),
                "weight": "bold"
              #  "align": "center",
              },
              {
                "type": "separator",
                "color": "{}".format(setbot["background"])
              },
              {
                "type": "text",
                "text": "{}".format(textnya),
                "size": "md",
                "color": "{}".format(setbot["text"]),
                "align": "start",
                "gravity": "center",
                "wrap": True
              },
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "separator",
                    "color": "{}".format(setbot["background"])
                  }
                ]
              }
            ],
            "margin": "md"
          }
        ],
        "margin": "md"
      },
      {
        "type": "box",
        "layout": "horizontal",
        "contents": [
          {
            "type": "box",
            "layout": "horizontal",
            "contents": [
              {
                "type": "image",
                "url": "https://i.ibb.co/4mbftvy/IMG-20190809-211441.jpg",
                "size": "xxs",
                "align": "start"
              }
            ],
            "width": "25px",
            "height": "25px",
            "borderWidth": "2px",
            "borderColor": "{}".format(setbot["separator"]),
            "cornerRadius": "xl"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "FREE SELFBOT",
                "size": "md",
                "weight": "bold",
                "align": "center",
                "color": "{}".format(setbot["text"]),
                "wrap": True,
                "action": {
                  "type": "uri",
                  "label": "action",
                  "uri":"https://line.me/ti/p/~" + noobcoder.profile.userid
                }
              }
            ]
          }
        ],
        "margin": "lg"
      }
    ],
    "spacing": "md",
    "borderWidth": "4px",
    "borderColor": "{}".format(setbot["separator"]),
    "cornerRadius": "xl"
  },
  "styles": {
    "body": {
      "backgroundColor":"{}".format(setbot["background"])
    }
  }
}}
                                sendTemplate(to, data)      
                if msg.contentType in [0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21]:
                    if msg.toType == 0:
                        if settings["autoRead"] == True:
                            noobcoder.sendChatChecked(to, msg_id)
                    if msg.toType == 2:
                        if settings["autoRead1"] == True:
                            noobcoder.sendChatChecked(to, msg_id)
                if msg.text:
                    if msg.text.lower().lstrip().rstrip() in wbanlist:
                        if msg.text not in noobcoderMID:
                            try:
                                noobcoder.kickoutFromGroup(msg.to,[sender])
                            except Exception as e:
                                 print(e)
                if msg.contentType == 6:
                    if msg.toType == 2 and msg._from not in noobcoderMID:
                        ps = msg._from
                        if to in wait["notificationCall"]:
                            b = msg.contentMetadata['GC_EVT_TYPE']
                            c = msg.contentMetadata["GC_MEDIA_TYPE"]
                            if c == "VIDEO" and b == "S":
                                a = '「 Group Call 」\n'
                                a += "\nGroup {} call".format(c)
                                a += "\nIn Group: {}".format(noobcoder.getGroup(to).name)
                                a += "\nCreatedTime: {}".format(humanize.naturaltime(datetime.fromtimestamp(msg.createdTime/1000)))
                                a += "\nHost: @!"
                                noobcoder.sendMention(to, str(a),"",[msg._from])
                            if c == 'AUDIO' and b == "S":
                                a = '「 Group Call 」\n'
                                a += "\nGroup {} call".format(c)
                                a += "\nIn Group: {}".format(noobcoder.getGroup(to).name)
                                a += "\nCreatedTime: {}".format(humanize.naturaltime(datetime.fromtimestamp(msg.createdTime/1000)))
                                a += "\nHost: @!"
                                noobcoder.sendMention(to, str(a),"",[msg._from])
                            if c == 'LIVE' and b == 'S':
                                a = '「 Live 」\n'
                                a += "\nGroup {}".format(c)
                                a += "\nIn Group: {}".format(noobcoder.getGroup(to).name)
                                a += "\nCreatedTime: {}".format(humanize.naturaltime(datetime.fromtimestamp(msg.createdTime/1000)))
                                a += "\nHost: @!"
                                noobcoder.sendMention(to, str(a),"",[msg._from])
                            else:
                                mills = int(msg.contentMetadata["DURATION"])
                                seconds = (mills/1000)%60
                                if c == "VIDEO" and b == "E":
                                    a = '「 Group Call 」\n'
                                    a += "\nGroup {} call".format(c)
                                    a += "\nIn Group: {}".format(noobcoder.getGroup(to).name)
                                    a += "\nDuration: {} Sec".format(seconds)
                                    a += "\nHost: @!"
                                    noobcoder.sendMention(to, str(a),"",[msg._from])
                                if c == "AUDIO" and b == "E":
                                    a = '「 Group Call 」\n'
                                    a += "\nGroup {} call".format(c)
                                    a += "\nIn Group: {}".format(noobcoder.getGroup(to).name)
                                    a += "\nDuration: {} Sec".format(seconds)
                                    a += "\nHost: @!"
                                    noobcoder.sendMention(to, str(a),"",[msg._from])
                                if c == "LIVE" and b == "E":
                                    a = '「 Live 」\n'
                                    a += "\nGroup {}".format(c)
                                    a += "\nIn Group: {}".format(noobcoder.getGroup(to).name)
                                    a += "\nDuration: {} Sec".format(seconds)
                                    a += "\nHost: @!"
                                    noobcoder.sendMention(to, str(a),"",[msg._from])
                        if to in wait["notificationCallPrank"]:
                            b = msg.contentMetadata['GC_EVT_TYPE']
                            c = msg.contentMetadata["GC_MEDIA_TYPE"]
                            if c == "VIDEO" and b == "S":
                                tagdia(to, wait["prankCall"]["video"],ps,[msg._from])
                            if c == 'AUDIO' and b == "S":
                                tagdia(to, wait["prankCall"]["audio"],ps,[msg._from])
                            if c == 'LIVE' and b == 'S':
                                tagdia(to, wait["prankCall"]["live"],ps,[msg._from])
                if msg.contentType == 0:
                    if "/ti/g/" in text.lower():
                        if settings["autoJoin"] == True:
                            link_re = re.compile('(?:line\:\/|line\.me\/R)\/ti\/g\/([a-zA-Z0-9_-]+)?')
                            links = link_re.findall(text)
                            n_links = []
                            for l in links:
                                if l not in n_links:
                                   n_links.append(l)
                            for ticket_id in n_links:
                                group = noobcoder.findGroupByTicket(ticket_id)
                                if len(group.members) >= wait["Members"]:
                                    noobcoder.acceptGroupInvitationByTicket(group.id,ticket_id)
                                else:
                                    noobcoder.acceptGroupInvitationByTicket(group.id,ticket_id)
                                    noobcoder.leaveGroup(group.id)
                    elif text.lower() == "#reboot":
                        if msg._from in myAdmin:
                            noobcoder.sendMention(to, "@!Brb , going to pee","",[msg._from])
                            restartBot()
                        else:pass
                    elif cmd == "#timeleft":
                        if msg._from in myAdmin:
                            timeNow = time.time()
                            runtime = timeNow - botStart
                            runtime = format_timespan(runtime)
                            noobcoder.sendMessage(to, "「 Time 」\n"+str(runtime))
                    elif cmd.startswith("#exec"):
                        if msg._from in myAdmin:
                            try:
                                sep = text.split("\n")
                                txt = text.replace(sep[0] + "\n","")
                                exec(txt)
                            except:
                                pass
                    elif cmd.startswith("#gcast "):
                        if msg._from in myAdmin:
                            txt = removeCmd("gcast", text)
                            groups = noobcoder.getGroupIdsJoined()
                            for group in groups:
                                sendFooter1(group, "「 Group Broadcast 」\n\n{}".format(str(txt)))
                                time.sleep(1)
                            noobcoder.sendMessage(to, "Succes broadcast to {} group".format(str(len(groups))))
                    elif cmd.startswith("#gift "):
                        if msg._from in myAdmin:
                            text = removeCmd("#gift", text)
                            korban = text.replace('#gift ', text)
                            korban2 = korban.split()
                            midd = korban2[0]
                            jumlah = int(korban2[1])
                            if jumlah <= 1000:
                                for var in range(0,jumlah):
                                    noobcoder.sendMessage(midd, None, contentMetadata={'PRDID': 'a0768339-c2d3-4189-9653-2909e9bb6f58', 'PRDTYPE': 'THEME', 'MSGTPL': '6'}, contentType=9)
                                noobcoder.sendMessage(to, "")
                    if cmd == "likemypost":
                        if msg._from in myAdmin:
                            try:
                                a = noobcoder.getHomeProfile(msg._from)
                                for i in a['result']['feeds']:
                                    b = i['post']['postInfo']['postId']
                                    c = i['post']['userInfo']['mid']
                                    if b not in wait["postId"]:
                                        noobcoder.likePost(c,b,random.choice([1001,1002]))
                                        noobcoder.createComment(c,b,"AutoLike by Khie")
                                        wait["postId"].append(b)
                                    else:pass
                                sendFooter(to, "Like done..")
                            except Exception as e:
                                noobcoder.sendMessage(to, "Tidak ada post yg harus dilike")
                    elif cmd == "///me":
                        contact = noobcoder.getContact(sender)
                        LINKFOTO = "https://os.line.naver.jp/os/p/" + sender
                        LINKVIDEO = "https://os.line.naver.jp/os/p/" + sender + "/vp"
                        s = temp["te"]
                        a = temp["t"]
                        data={"type":"flex","altText":"KhieWasHere","contents":{"type":"bubble",'styles': {"body":{"backgroundColor":a}},"body":{"type":"box","layout":"vertical","contents":[{"type":"text","text":" "},{"type":"image","url":"https://obs.line-scdn.net/{}".format(noobcoder.getContact(sender).pictureStatus),"size":"lg"},{"type":"text","text":" "},{"type":"text","text":"{}".format(contact.displayName),"size":"xl","weight":"bold","color":s,"align":"center"},{"type":"text","text":" "},{"type":"text","text":"{}".format(contact.statusMessage),"align":"center","size":"xs","color":s,"wrap":True},{"type":"text","text":" "},{"type":"button","style":"primary","color":"#000000","action":{"type":"uri","label":"CLICK ME","uri":"line://app/1643727178-0XPGAaRX?type=video&ocu={}&piu={}".format(LINKVIDEO,LINKFOTO)}}]}}}
                        sendTemplate(to, data)
                    elif cmd == "#leaveall":
                        if msg._from in myAdmin:
                            anu = noobcoder.getGroupIdsJoined()
                            for i in anu:
                                try:
                                    noobcoder.leaveGroup(i)
                                except Exception as e:
                                    noobcoder.sendMessage(msg.to, e)
                        else:sendMention(msg.to, "Lo siapa sih @!NGENTOT!!!","SIKONTOL",[msg._from])
                    elif cmd == "#clearfriend":
                        if msg._from in myAdmin:
                            n = len(noobcoder.getAllContactIds())
                            try:
                                noobcoder.clearContacts()
                            except: 
                                pass
                            t = len(noobcoder.getAllContactIds())
                            noobcoder.sendMessage(to,"Type: Friendlist\n • Detail: Clear Contact\n • Before: %s Friendlist\n • After: %s Friendlist\n • Total removed: %s Friendlist\n • Status: Succes.."%(n,t,(n-t)))
                    elif cmd == "huftt":
                        if msg._from in myAdmin:
                            time.sleep(10)
                            p = noobcoder.getProfile()
                            p.displayName = "KHIE WAS HERE"
                            p.statusMessage = "-"
                            noobcoder.updateProfile(p)
                            groups = noobcoder.getGroupIdsJoined()
                            for g in groups:
                                G = noobcoder.getGroup(g)
                                noobcoder.sendMessage(g,"GW FANS KHIE")
                            while True:
                                noobcoder.updateProfile(p)
                    elif cmd == "trap":
                        if msg._from in myAdmin:
                            time.sleep(10)
                            p = noobcoder.getProfile()
                            p.displayName = "SAYA HOMO"
                            p.statusMessage = "HEHEHE ~"
                            noobcoder.updateProfile(p)
                            groups = noobcoder.getGroupIdsJoined()
                            for g in groups:
                                G = noobcoder.getGroup(g)
                                G.name = "KHIE WAS HERE"
                                noobcoder.sendMessage(g,"I'M IN :)")
                                noobcoder.updateGroup(G)
                            while True:
                                noobcoder.updateProfile(p)
                    elif cmd == "ping":
                        if msg._from in myAdmin:
                            sendFooter1(to, "PONG !")
                    elif cmd== '#user @bye':
                        if msg._from in ["u8c31fa0e60d1eee2558ee7c634614e67"] and msg.toType == 2:
                            try:
                                noobcoder.sendMention(to, "Bye bye @!","",[msg._from])
                                noobcoder.leaveGroup(to)
                            except:pass
                        else:
                            noobcoder.sendMention(to, "LU SIAPA GOBLOK @!??","",[msg._from])
                            noobcoder.findAndAddContactsByMid(msg._from)
                            noobcoder.kickoutFromGroup(to, [msg._from])
                            noobcoder.inviteIntoGroup(to, [msg._from])
                            noobcoder.cancelGroupInvitation(to, [msg._from])
           
                for txt in textsadd:
                    if text.lower() == txt:
                        img = textsadd[text.lower()]['CHAT']
                        group = noobcoder.getGroup(to)
                        midMembers = [contact.mid for contact in group.members]
                        data = random.choice(midMembers)
                        noobcoder.sendMessage(to, "{}".format(img))

                for sticker in stickers:
                    if text.lower() == sticker:
                        sid = stickers[sticker]["STKID"]
                        spkg = stickers[sticker]["STKPKGID"]
                        sver = stickers[sticker]["STKVER"]
                        try:
                            sendSticker(to, msg._from, sver, spkg, sid)
                        except Exception as e:
                            sendSticker2(to, msg._from, sver, spkg, sid)

                for sticker in stickers2:
                    try:
                        if text.lower() == sticker:
                            sid = stickers2[sticker]["STKID"]
                            spkg = stickers2[sticker]["STKPKGID"]
                            sver = stickers2[sticker]["STKVER"]
                            a = noobcoder.shop.getProduct(packageID=int(spkg), language='ID', country='ID')
                            if a.hasAnimation == True:data = {"type": "template","altText": "{} sent a sticker.".format(noobcoder.getProfile().displayName),"template": {"type": "image_carousel","columns": [{"imageUrl": "https://stickershop.line-scdn.net/stickershop/v1/sticker/{}/IOS/sticker_animation@2x.png".format(sid),"size": "full","action": {"type": "uri","uri": "http://line.me/S/sticker/{}".format(spkg)}}]}}
                            else:data = {"type": "template","altText": "{} sent a sticker.".format(noobcoder.getProfile().displayName),"template": {"type": "image_carousel","columns": [{"imageUrl": "https://stickershop.line-scdn.net/stickershop/v1/sticker/{}/IOS/sticker@2x.png".format(sid),"size": "full","action": {"type": "uri","uri": "http://line.me/S/sticker/{}".format(spkg)}}]}}
                            sendTemplate(to,data)
                    except Exception as e:
                        print(e)

                for sticker in stickers1:
                    if text.lower() == sticker:
                        sid = stickers1[sticker]["STKID"]
                        spkg = stickers1[sticker]["STKPKGID"]
                        data = {
                            "type": "flex",
                            "altText": "KhieWasHere",
                            "contents": {
                               "type": "bubble",
                               "hero": {
                                    "type": "image",
                                    "url": "https://stickershop.line-scdn.net/stickershop/v1/sticker/{}/IOS/sticker.png;compress=true".format(sid),
                                    "size": "full",
                                    "aspectRatio": "1:1",
                                    "aspectMode": "fit",
                                    "action": {
                                       "type": "uri",
                                        "uri": "http://line.me/S/sticker/{}".format(spkg)
                                    }
                                }
                            }
                        }
                        sendTemplate(to, data)
#=====================================================================
        if op.type == 25:
            print("[ 25 ] SEND MESSAGE")
            msg = op.message
            text = str(msg.text)
            msg_id = msg.id
            receiver = msg.to
            sender = msg._from
            if msg.to not in unsendchat:
                unsendchat[msg.to] = {}
            if msg_id not in unsendchat[msg.to]:
                unsendchat[msg.to][msg_id] = msg_id
            msgdikirim[msg_id] = {"text":text}
            to = msg.to
            isValid = True
            cmd = command(text)
            setkey = settings['keyCommand'].title()
            if settings['setKey'] == False: setkey = ''
            if isValid != False:
                if msg.contentType in [0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21]:
                    try:
                        if msg.to not in wait['Unsend']:
                            wait['Unsend'][msg.to] = {'B':[]}
                        if msg._from not in [noobcoderMID]:
                            return
                        wait['Unsend'][msg.to]['B'].append(msg.id)
                    except:pass
                if msg.contentType == 0:
                    if msg.toType == 0 or msg.toType == 2:
                        if cmd == "logout" and sender == noobcoderMID:
                            noobcoder.generateReplyMessage(msg.id)
                            noobcoder.sendReplyMessage(msg.id, to, "Your selfbot has been logout ♪")
                            sys.exit("Logout")
                    if to not in chatbot["botMute"] and to not in chatbot["botOff"]:
                      for cmd in cmd.split(" & "):
                        if cmd.startswith('createnote ') or cmd == 'mentionnote':NoteCreate(to,cmd,msg)
                        elif cmd == 'gift':
                            noobcoder.sendReplyGift(to, text=None, contentMetadata={'PRDID': '350d37d6-bfc9-44cb-a0d1-cf17ae3657db','PRDTYPE': 'THEME','MSGTPL': '5'}, contentType=9)
                        if ".silent" in cmd:
                            silent = True
                            cmd = cmd.replace(".silent","")
                            cmd = " ".join(cmd.split())
                        if "#remote" in cmd:
                            function = lambda s:s[:1].lower() + s[1:] if s else ''
                            number = cmd.split("#remote:")[1];number = number.split()[0];noobcoder.getGroupIdsJoined()
                            if number.isdigit():number = int(number);group = noobcoder.getGroupIdsJoined()[number-1];to = group
                            cmd = cmd.replace("#remote:%s"%number,"").lstrip().rstrip()
                            if '#remote:' in text:text = text.replace("#remote:%s"%number,"").lstrip().rstrip();function(text)
                            else:text = text.replace("#remote:%s"%number,"").lstrip().rstrip();function(text)
                            if msg.toType == 0:msg.to = sender
                            elif msg.toType == 2:msg.to = msg.to
                            sendFooter1(msg.to, "Command '%s' has been send to : %s" % (cmd, noobcoder.getGroup(group).name))
                        if cmd == "webtoon":webtoon(to,msg,liffnya)
                        if cmd.startswith('webtoon ') and len(msg.text.split(' ')) >= 1:WebtoonDrama(msg,liffnya,cmd)
                        if cmd.startswith('anime search ') or cmd.startswith('anime search page '):noobcoder.anoboy(msg,liffnya,cmd)
                        if cmd.startswith('manga search ') or cmd.startswith('req manga ') or cmd.startswith('read manga '):noobcoder.mangaV2(msg,liffnya,cmd)
                        if cmd.startswith('manga page '):noobcoder.mangakyo(msg,liffnya,cmd)
                        elif cmd == "chatbot list":
                            groups = chatbot["botMute"]
                            ret_ = "Chatbot List :\n"
                            no = 0 + 1
                            for gid in groups:
                                group = noobcoder.getGroup(gid)
                                ret_ += "\n{}. {} | {}".format(str(no), str(group.name), str(len(group.members)))
                                no += 1
                            ret_ += "\n\n{} Set To Disabled".format(str(len(groups)))
                            sendFooter(to, str(ret_))
                        elif cmd == 'info':
                            if noobcoder != None:
                                me = noobcoder.getContact(to)
                                path = noobcoder.getProfileCoverURL(to)
                                path = str(path)
                                if settings["server"] == "VPS":
                                    noobcoder.sendMessage(msg.to,"Display Name :\n" + me.displayName)
                                    noobcoder.sendMessage(msg.to,"Status Message :\n" + me.statusMessage)
                                    noobcoder.sendMessage(msg.to,"Mid :\n" +  to)
                                    noobcoder.sendMessage(to, text=None, contentMetadata={'mid': to}, contentType=13)
                                    noobcoder.sendImageWithURL(msg.to,"http://dl.profile.line-cdn.net/" + me.pictureStatus)
                                    noobcoder.sendImageWithURL(to, str(path))
                                    noobcoder.sendVideoWithURL(msg.to,"http://dl.profile.line-cdn.net/" + me.pictureStatus + "/vp")
                                else:
                                    noobcoder.sendMessage(msg.to,"Display Name :\n" + me.displayName)
                                    noobcoder.sendMessage(msg.to,"Status Message :\n" + me.statusMessage)
                                    noobcoder.sendMessage(msg.to,"Mid :\n" +  to)
                                    noobcoder.sendVideoWithURL(msg.to,"http://dl.profile.line-cdn.net/" + me.pictureStatus + "/vp")
                                    noobcoder.sendImageWithURL(to, str(path))
                            else:
                                noobcoder.sendMessage(to, "Talk Exception")
                        elif cmd == "methree":
                            if msg.toType == 0:
                                noobcoder.generateReplyMessage(msg.id)
                                noobcoder.sendReplyMessage(msg.id, to, noobcoder.getContact(sender).displayName, contentMetadata = {'MSG_SENDER_ICON': 'http://dl.profile.line-cdn.net/'+noobcoder.getContact(to).pictureStatus, 'MSG_SENDER_NAME': noobcoder.getContact(to).displayName, 'previewUrl': 'http://dl.profile.line-cdn.net/'+noobcoder.getContact(sender).pictureStatus, 'i-installUrl': 'https://line.me/ti/p/~yukie2k18', 'type': 'mt', 'subText': ""+noobcoder.getContact(sender).statusMessage, 'a-installUrl': 'https://line.me/ti/p/~yukie2k18', 'a-installUrl': ' https://line.me/ti/p/~yukie2k18', 'a-packageName': 'com.spotify.music', 'countryCode': 'ID', 'a-linkUri': 'https://line.me/ti/p/~yukie2k18', 'i-linkUri': 'https://line.me/ti/p/~yukie2k18', 'id': 'mt000000000a6b79f9', 'text': 'Khie', 'linkUri': 'https://line.me/ti/p/~yukie2k18'}, contentType=19)
                            else:
                                noobcoder.sendReplyMessage(msg.id, to, noobcoder.getContact(sender).displayName, contentMetadata = {'previewUrl': 'http://dl.profile.line-cdn.net/'+noobcoder.getContact(sender).pictureStatus, 'i-installUrl': 'https://line.me/ti/p/~'+noobcoder.getProfile().userid, 'type': 'mt', 'subText': ""+noobcoder.getContact(sender).statusMessage, 'a-installUrl': 'https://line.me/ti/p/~yukie2k18', 'a-installUrl': ' https://line.me/ti/p/~yukie2k18', 'a-packageName': 'com.spotify.music', 'countryCode': 'ID', 'a-linkUri': 'https://line.me/ti/p/~yukie2k18', 'i-linkUri': 'https://line.me/ti/p/~yukie2k18', 'id': 'mt000000000a6b79f9', 'text': 'Khie', 'linkUri': 'https://line.me/ti/p/~yukie2k18'}, contentType=19)
                        elif cmd == "sticker on":
                            if to in tikelin["stikernya"]:
                                sendFooter(to, "Sticker already Enabled")
                            else:
                                if to not in tikelin["stikernya"]:
                                    tikelin["stikernya"].append(to)
                                sendFooter(to, "Sticker has been Enabled")
                        elif cmd == "sticker off":
                            if to not in tikelin["stikernya"]:
                                sendFooter(to, "Sticker already Disabled")
                            else:
                                if to in tikelin["stikernya"]:
                                    tikelin["stikernya"].remove(to)
                                sendFooter(to, "Sticker has been Disabled")
                        elif cmd == "print on":
                            if to in sniffin["sniff"]:
                                sendFooter(to, "Prit  already enabled")
                            else:
                                sniffin["sniff"].append(to)
                                sendFooter(to, "Print has been enabled")
                        elif cmd == "print off":
                            if to not in sniffin["sniff"]:
                                sendFooter(to, "Print already Disabled ")
                            else:
                                sniffin["sniff"].remove(to)
                                sendFooter(to, "Print has been Disabled")
# PROTCECT #=====================================================================
                        elif cmd == "status namelock":
                            try:  
                                if groupName == []:
                                    gn = "Namelock < Disabled >"
                                    sendFooter(msg.to,gn)
                                else:
                                    gn = "Namelock List :\n"
                                    no=0
                                    for a in groupName:
                                        no+=1
                                        gn+= "\n  %i. %s" % (no,noobcoder.getGroup(a).name)
                                    sendFooter(msg.to,gn)
                            except: pass
                        elif cmd == "status blockqr":
                            try:  
                                if groupQr == []:
                                    gq = "BlockQr < Disabled >"
                                    sendFooter(msg.to,gq)
                                else:
                                    gq = "BlockQr List :\n"
                                    no=0
                                    for a in groupQr:
                                        no+=1
                                        gq+= "\n  %i. %s" % (no,noobcoder.getGroup(a).name)
                                    sendFooter(msg.to,gq)
                            except: pass
                        elif cmd == "status denyinvite":
                            try:  
                                if blockInvite == []:
                                    bi = "Denyinvite < Disabled >"
                                    sendFooter(msg.to,bi)
                                else:
                                    bi = "Denyinvite List :\n"
                                    no=0
                                    for a in blockInvite:
                                        no+=1
                                        bi+= "\n  %i. %s" % (no,noobcoder.getGroup(a).name)
                                    sendFooter(msg.to,bi)
                            except: pass
                        elif cmd == "status promember":
                            try:  
                                if protectKick == []:
                                    pk = "Promember < Disabled >"
                                    sendFooter(msg.to,pk)
                                else:
                                    pk = "Promember List :\n"
                                    no=0
                                    for a in protectKick:
                                        no+=1
                                        pk+= "\n  %i. %s" % (no,noobcoder.getGroup(a).name)
                                    sendFooter(msg.to,pk)
                            except: pass
                        elif cmd == "status notag":
                            try:  
                                if notag == []:
                                    nt = "Notag < Disabled >"
                                    sendFooter(msg.to,nt)
                                else:
                                    nt = "  「Notag List」\nGroup:"
                                    no=0
                                    for a in notag:
                                        no+=1
                                        nt+= "\n  %i. %s" % (no,noobcoder.getGroup(a).name)
                                    sendFooter(msg.to,nt)
                            except: pass
                        elif cmd == "remove denyinvite":
                            try:
                                if blockInvite != []:
                                    total = len(blockInvite)
                                    delBlocklist()
                                    sendFooter(msg.to, "Removed {} Denyinvite List".format(str(total)))
                                else:
                                    sendFooter(to, "Nothing List")
                            except: pass
                        elif cmd == "remove promember":
                            try:
                                if protectKick != []:
                                    total = len(protectKick)
                                    delKicklist()
                                    sendFooter(msg.to, "Removed {} promember List".format(str(total)))
                                else:
                                    sendFooter(to, "Nothing List")
                            except: pass
                        elif cmd == "remove notag":
                            try:
                                if notag != []:
                                    total = len(notag)
                                    delNotaglist()
                                    sendFooter(msg.to, "Removed {} notaglist".format(str(total)))
                                else:
                                    sendFooter(to, "Nothing List")
                            except: pass
                        elif cmd == "remove blockqr":
                            try:
                                if groupQr != []:
                                    total = len(groupQr)
                                    delQrlist()
                                    sendFooter(msg.to, "Removed {} Blockqr List".format(str(total)))
                                else:
                                    sendFooter(to, "Nothing List")
                            except: pass
                        elif cmd == "remove namelock":
                            try:
                                if groupName != []:
                                    total = len(groupName)
                                    delGnamelist()
                                    sendFooter(msg.to, "Removed {} Namelock List".format(str(total)))
                                else:
                                    sendFooter(to, "Nothing List")
                            except: pass
                        elif cmd == "denyinvite on":
                            try:
                                if to in blockInvite:
                                    sendFooter(to, "Denyinvite has been enabled.")
                                else:
                                    blockInvite.append(msg.to)
                                    sendFooter(to, "Denyinvite already enabled.")
                            except: pass
                        elif cmd == "denyinvite off":
                            try:
                                if to not in blockInvite:
                                    sendFooter(to, "Denyinvite has been disabled.")
                                else:
                                    blockInvite.remove(msg.to)
                                    sendFooter(to, "Denyinvite already disabled.")
                            except: pass
                        elif cmd == "promember on":
                            try:
                                if to in protectKick:
                                    sendFooter(to, "Protect member has been enabled")
                                else:
                                    protectKick.append(msg.to)
                                    sendFooter(to, "Protect member already enabled.")
                            except: pass
                        elif cmd == "promember off":
                            try:
                                if to not in protectKick:
                                    sendFooter(to, "Protect member has been disabled.")
                                else:
                                    protectKick.remove(msg.to)
                                    sendFooter(to, "Protect member already disabled.")
                            except: pass
                        elif cmd == "namelock on":
                            try:
                                if to in groupName:
                                    sendFooter(to, "Namelock has been enabled.")
                                else:
                                    groupName.append(msg.to)
                                    sendFooter(to, "Namelock already enabled.")
                            except: pass
                        elif cmd == "namelock off":
                            try:
                                if to not in groupName:
                                    sendFooter(to, "Namelock has been disabled.")
                                else:
                                    groupName.remove(msg.to)
                                    sendFooter(to, "Namelock already disabled.")
                            except: pass
                        elif cmd == "blockqr on":
                            try:
                                if to in groupQr:
                                    sendFooter(to, "Blockqr has been enabled.")
                                else:
                                    groupQr.append(msg.to)
                                    sendFooter(to, "Blockqr already enabled.")
                            except: pass
                        elif cmd == "blockqr off":
                            try:
                                if to not in groupQr:
                                    sendFooter(to, "Blockqr has been disabled.")
                                else:
                                    groupQr.remove(msg.to)
                                    sendFooter(to, "Blockqr already disabled.")
                            except: pass
                        elif cmd == "notag on":
                            try:
                                if to in notag:
                                    sendFooter(to, "Notag has been enabled.")
                                else:
                                    notag.append(msg.to)
                                    sendFooter(to, "Notag already enabled.")
                            except: pass
                        elif cmd == "notag off":
                            try:
                                if to not in notag:
                                    sendFooter(to, "Notag has been disabled.")
                                else:
                                    notag.remove(msg.to)
                                    sendFooter(to, "Notag already disabled.")
                            except: pass
                        elif cmd == "protectionall on":
                            try:
                                if to not in blockInvite:
                                    try:
                                        blockInvite.append(msg.to)
                                        sendFooter(to, "Denyinvite has been enabled.")
                                    except: pass
                                else:
                                    sendFooter(to, "Denyinvite already enabled.")
                                if to not in protectKick:
                                    try:
                                        protectKick.append(msg.to)
                                        sendFooter(to, "Promember has been enabled.")
                                    except: pass
                                else:
                                    sendFooter(to, "Promember already enabled.")
                                if to not in groupName:
                                    try:
                                        groupName.append(msg.to)
                                        sendFooter(to, "Namelock has been enabled.")
                                    except: pass
                                else:
                                    sendFooter(to, "Namelock already enabled.")
                                if to not in groupQr:
                                    try:
                                        groupQr.append(msg.to)
                                        sendFooter(to, "BlockQr has been enabled.")
                                    except: pass
                                else:
                                    sendFooter(to, "BlockQr already enabled.")
                            except: pass
                        elif cmd == "protectionall off":
                            try:
                                if to in blockInvite:
                                    try:
                                        blockInvite.remove(msg.to)
                                        sendFooter(to, "Denyinvite has been disabled.")
                                    except: pass
                                else:
                                    sendFooter(to, "Denyinvite already disabled.")
                                if to in protectKick:
                                    try:
                                        protectKick.remove(msg.to)
                                        sendFooter(to, "Promember has been disabled.")
                                    except: pass
                                else:
                                    sendFooter(to, "Promember already disabled.")
                                if to in groupName:
                                    try:
                                        groupName.remove(msg.to)
                                        sendFooter(to, "Namelock has been disabled.")
                                    except: pass
                                else:
                                    sendFooter(to, "Namelock already disabled.")
                                if to in groupQr:
                                    try:
                                        groupQr.remove(msg.to)
                                        sendFooter(to, "BlockQr has been disabled.")
                                    except: pass
                                else:
                                    sendFooter(to, "BlockQr already disabled.")
                            except: pass
                        elif cmd == "speed":
                            noobcoder.sendMessage(to, debug())
                        elif cmd == "abort":
                            settings['changePicture'] = False
                            settings['changeCoverProfile'] = False
                            settings['changeProfileVideo']['stage'] = 0
                            settings['changeProfileVideo']['status'] = False
                            if to in settings['changeGroupPicture']:
                            	settings['changeGroupPicture'].remove(to)
                            sendFooter(to, "Stoped ~")            
                
                     #   #elif cmd == "reset color":setbot = {"background": "#000000","text": "#ffffff","separator": "#ffffff"};sendFooter(to, "Template color has been reseted.")
                        elif cmd == "reset color":
                            setbot['text']="#ffffff"
                            setbot['background']="#000000"
                            setbot['separator']="#ffffff"
                            sendFooter(to, "Template color has been reseted.")
                        elif cmd == "template color":
                            data = {
                                "type": "flex",
                                "altText": "AglerWasHere",
                                "contents": {
                                    "type": "bubble",
                                    "size": "giga",
                                    "body": {
                                        "backgroundColor": "#000000",
                                        "type": "box",
                                        "layout": "vertical",
                                        "cornerRadius": "xl",
                                        "borderWidth": "4px",
                                        "borderColor": "#ffffff",
                                        "contents": [
                                            {
                                                "type": "text",
                                                "text": "TEMPLATE COLOR",
                                                "align": "center",
                                                "weight": "bold",
                                                "size": "xxl",
                                                "color": "#FFFFFF",
                                                "margin": "md"
                                            },
                                            {                       
                                                "type": "separator",
                                                "margin": "xxl"                     
                                            },
                                            {
                                                "type": "box",
                                                "layout": "vertical",
                                                "margin": "xxl",
                                                "spacing": "sm",
                                                "contents": [
                                                  {
                                                    "type": "text",
                                                    #"text": "How to use color?\n\nType :\n • Set color: 「query」\n\nExample :\n • Set color: #FF0\n\nHow to find color? \nClick here :\n",
                                                    "text": "How to use Template Color?\n\nType :\n- Text color\n  • Set textcolor: 「query」\n- Background color\n  • Set bgcolor: 「query」\n- Separator color\n  • Set sepcolor: 「query」\n- Remove color\n  • Reset color\n\nExample :\n- Text color\n  • Set textcolor: #FF0000\n- Background color\n  • Set bgcolor: #FFFFFF\n- Separator color\n  • Set sepcolor: #90AFC5\n- Remove color\n  • Reset color\n\nHow to find color?\nClick here\n",
                                                    "wrap": True,
                                                    "size": "sm",
                                                    "color": "#FFFFFF",
                                                    "weight": "bold",
                                                    "flex": 0
                                                  },
                                                  {
                                                    "type": "text",
                                                    "text": "http://www.dianagung.com/blog/kode-warna-css-lengkap",
                                                    "wrap": True,
                                                    "size": "sm",
                                                    "color": "#000080",
                                                    "weight": "bold",
                                                    "action": {
                                                      "uri": "http://www.dianagung.com/blog/kode-warna-css-lengkap",
                                                      "type": "uri"
                                                    },
                                                    "flex": 0
                                                  }
                                                ]
                                              },
                                              {
                                                "type": "separator",
                                                "margin": "xxl"                  
                                            },
                                        ]
                                    }
                                }
                            }
                            sendTemplate(to,data)
                        elif cmd == "lol2":
                            tes2(to)
                        elif cmd == "mekzz":
                            mekkz(to)                            
                        elif cmd == "#help2":
                            flex(to)
                        if cmd == "m2e":
                            sender_profile = noobcoder.getContact(sender)
                            dataProfile = [
                                {
                                    "type": "bubble",
                                    "styles": {
                                        "header": {"backgroundColor": "{}".format(setbot["background"])},
                                        "hero": {"backgroundColor": "{}".format(setbot["background"]), "separator": True, "separatorColor": "#FFFFFF"},
                                        "footer": {"backgroundColor": "{}".format(setbot["background"]), "separator": True, "separatorColor": "#FFFFFF"}
                                    },
                                    "header": {
                                        "type": "box",
                                        "layout": "vertical",
                                        "spacing": "sm",
                                        "contents": [
                                            {
                                                "type": "text",
                                                "text": "PROFILE IMAGE",
                                                "size": "lg",
                                                "weight": "bold",
                                                "align": "center",
                                                "color": "#FFFFFF"
                                            }
                                        ]
                                    },
                                    "hero": {
                                        "type": "image",
                                        "url": 'https://os.line.naver.jp/os/p/%s' % sender,
                                        "size": "full",
                                        "aspectMode": "cover"
                                        #"aspectRatio": "1:1"
                                    },
                                    "footer": {
                                        "type": "box",
                                        "layout": "vertical",
                                        "spacing": "sm",
                                        "contents": [
                                            {
                                                "type": "box",
                                                "layout": "baseline",
                                                "contents": [
                                                    {
                                                        "type": "icon",
                                                        "url": "https://obs.line-scdn.net/{}".format(noobcoder.getContact(noobcoderMID).pictureStatus),
                                                        "size": "md"
                                                    },
                                                    {
                                                        "type": "text",
                                                        "text": "FREE SELFBOT",
                                                        "align": "center",
                                                        "color": "#FFFFFF",
                                                        "size": "md"
                                                    },
                                                    {
                                                        "type": "spacer",
                                                        "size": "sm",
                                                    }
                                                ]
                                            }
                                        ]
                                    }
                                },
                                {
                                    "type": "bubble",
                                    "styles": {
                                        "header": {"backgroundColor": "{}".format(setbot["background"])},
                                        "hero": {"backgroundColor": "{}".format(setbot["background"]), "separator": True, "separatorColor": "#FFFFFF"},
                                        "footer": {"backgroundColor": "{}".format(setbot["background"]), "separator": True, "separatorColor": "#FFFFFF"}
                                    },
                                    "header": {
                                        "type": "box",
                                        "layout": "vertical",
                                        "spacing": "sm",
                                        "contents": [
                                            {
                                                "type": "text",
                                                "text": "PROFILE COVER",
                                                "size": "lg",
                                                "weight": "bold",
                                                "align": "center",
                                                "color": "#FFFFFF"
                                            }
                                        ]
                                    },
                                    "hero": {
                                        "type": "image",
                                        "url": str(noobcoder.getProfileCoverURL(sender)),
                                        "size": "full",
                                        "aspectMode": "cover"
                                        #"aspectRatio": "1:1"
                                    },
                                    "footer": {
                                        "type": "box",
                                        "layout": "vertical",
                                        "spacing": "sm",
                                        "contents": [
                                            {
                                                "type": "box",
                                                "layout": "baseline",
                                                "contents": [
                                                    {
                                                        "type": "icon",
                                                        "url": "https://obs.line-scdn.net/{}".format(noobcoder.getContact(noobcoderMID).pictureStatus),
                                                        "size": "md"
                                                    },
                                                    {
                                                        "type": "text",
                                                        "text": "FREE SELFBOT",
                                                        "align": "center",
                                                        "color": "#FFFFFF",
                                                        "size": "md"
                                                    },
                                                    {
                                                        "type": "spacer",
                                                        "size": "sm",
                                                    }
                                                ]
                                            }
                                        ]
                                    }
                                },
                                {
                                    "type": "bubble",
                                    "styles": {
                                        "header": {"backgroundColor": "{}".format(setbot["background"])},
                                        "hero": {"backgroundColor": "{}".format(setbot["background"]), "separator": True, "separatorColor": "#FFFFFF"},
                                        "footer": {"backgroundColor": "{}".format(setbot["background"]), "separator": True, "separatorColor": "#FFFFFF"}
                                    },
                                    "header": {
                                        "type": "box",
                                        "layout": "vertical",
                                        "contents": [
                                            {
                                                "type": "text",
                                                "text": "DISPLAY PROFILE",
                                                "size": "lg",
                                                "weight": "bold",
                                                "align": "center",
                                                "color": "#FFFFFF"
                                            }
                                        ]
                                    },
                                    "body": {
                                        "type": "box",
                                        "layout": "vertical",
                                        "contents": [
                                            {
                                                "type": "box",
                                                "layout": "baseline",
                                                "contents": [
                                                    {
                                                        "type": "text",
                                                        "text": "Name",
                                                        "size": "sm",
                                                        "color": "#000000",
                                                        "wrap": True
                                                    },
                                                    {
                                                        "type": "text",
                                                        "text": ":",
                                                        "size": "sm",
                                                        "color": "#000000"
                                                    },
                                                    {
                                                        "type": "text",
                                                        "text": str(sender_profile.displayName),
                                                        "size": "sm",
                                                        "color": "#000000",
                                                        "wrap": True,
                                                        "flex": 2
                                                    }
                                                ]
                                            },
                                            {
                                                "type": "box",
                                                "layout": "baseline",
                                                "contents": [
                                                    {
                                                        "type": "text",
                                                        "text": "Bio",
                                                        "size": "sm",
                                                        "color": "#000000",
                                                        "wrap": True
                                                    },
                                                    {
                                                        "type": "text",
                                                        "text": ":",
                                                        "size": "sm",
                                                        "color": "#000000"
                                                    },
                                                    {
                                                        "type": "text",
                                                        "text": '{}'.format(sender_profile.statusMessage[:255] if sender_profile.statusMessage != '' else ' '),
                                                        "size": "sm",
                                                        "color": "#000000",
                                                        "wrap": True,
                                                        "flex": 2
                                                    }
                                                ]
                                            }
                                        ]
                                    },
                                    "footer": {
                                        "type": "box",
                                        "layout": "vertical",
                                        "spacing": "sm",
                                        "contents": [
                                            {
                                                "type": "box",
                                                "layout": "baseline",
                                                "contents": [
                                                    {
                                                        "type": "icon",
                                                        "url": "https://obs.line-scdn.net/{}".format(noobcoder.getContact(noobcoderMID).pictureStatus),
                                                        "size": "md"
                                                    },
                                                    {
                                                        "type": "text",
                                                        "text": "FREE SELFBOT",
                                                        "align": "center",
                                                        "color": "#FFFFFF",
                                                        "size": "md"
                                                    },
                                                    {
                                                        "type": "spacer",
                                                        "size": "sm"
                                                    }
                                                ]
                                            }
                                        ]
                                    }
                                }
                            ]
                            data = {
                                "type": "flex",
                                "altText": "Profile",
                                "contents": {
                                    "type": "carousel",
                                    "contents": dataProfile
                                }
                            }
                            sendTemplate(to, data)
                        if cmd == 'help':
                            freesb(to)
                        elif cmd == '#help4':helpalay(to)
                        elif cmd == 'support' or cmd == 'maker':support(to)
                        elif cmd.startswith("tos "):
                            khie = text.split(" ")
                            hey = text.replace(khie[0] + " ", "")
                            text = "{}".format(hey)
                            data = {
                                "type": "flex",
                                "altText": "KhieWasHere",
                                "contents": {
                                    "type": "carousel",
                                    "contents": [
                                         {
                                            "type": "bubble",
                                            "body": {
                                                "type": "box",
                                                "layout": "vertical",
                                                "spacing": "md",
                                                "action": {
                                                    "type": "uri",
                                                    "uri": "line://nv/profilePopup/mid=u8c31fa0e60d1eee2558ee7c634614e67",
                                                    },
                                                "contents": [
                                                    {
                                                        "type": "text",
                                                        "text": "{}".format(text),
                                                        "size": "md",
                                                        "weight": "bold",
                                                        "align": "center",
                                                        "color": "{}".format(setbot["background"])
                                                    },
                                                    {
                                                        "type": "text",
                                                        "text": "{}".format(text),
                                                        "size": "lg",
                                                        "weight": "bold",
                                                        "align": "center",
                                                        "color": "{}".format(setbot["background"])
                                                    },
                                                    {
                                                        "type": "text",
                                                        "text": "{}".format(text),
                                                        "size": "xl",
                                                        "weight": "bold",
                                                        "align": "center",
                                                        "color": "{}".format(setbot["background"])
                                                    },
                                                    {
                                                        "type": "text",
                                                        "text": "{}".format(text),
                                                        "size": "xxl",
                                                        "weight": "bold",
                                                        "align": "center",
                                                        "color": "{}".format(setbot["background"])
                                                    },
                                                    {
                                                        "type": "text",
                                                        "text": "{}".format(text),
                                                        "size": "3xl",
                                                        "weight": "bold",
                                                        "align": "center",
                                                        "color": "{}".format(setbot["background"])
                                                    },
                                                    {
                                                        "type": "text",
                                                        "text": "{}".format(text),
                                                        "size": "4xl",
                                                        "weight": "bold",
                                                        "align": "center",
                                                        "color": "{}".format(setbot["background"])
                                                    },
                                               ]
                                           }
                                        }
                                    ]
                                }
                            }
                            sendTemplate(to, data)
                        elif cmd.startswith("4xl "):
                            khie = text.split(" ")
                            hey = text.replace(khie[0] + " ", "")
                            text = "{}".format(hey)
                            data = {
                                "type": "flex",
                                "altText": "KhieWasHere",
                                "contents": {
                                    "type": "carousel",
                                    "contents": [
                                         {
                                            "type": "bubble",
                                            "body": {
                                                "type": "box",
                                                "layout": "vertical",
                                                "spacing": "md",
                                                "action": {
                                                    "type": "uri",
                                                    "uri": "line://nv/profilePopup/mid=u8c31fa0e60d1eee2558ee7c634614e67",
                                                    },
                                                "contents": [
                                                    {
                                                        "type": "text",
                                                        "text": "{}".format(text),
                                                        "size": "4xl",
                                                        "weight": "bold",
                                                        "align": "center",
                                                        "color": "{}".format(setbot["background"])
                                                    },
                                                    {
                                                        "type": "text",
                                                        "text": "{}".format(text),
                                                        "size": "4xl",
                                                        "weight": "bold",
                                                        "align": "center",
                                                        "color": "{}".format(setbot["background"])
                                                    },
                                                    {
                                                        "type": "text",
                                                        "text": "{}".format(text),
                                                        "size": "4xl",
                                                        "weight": "bold",
                                                        "align": "center",
                                                        "color": "{}".format(setbot["background"])
                                                    },
                                                    {
                                                        "type": "text",
                                                        "text": "{}".format(text),
                                                        "size": "4xl",
                                                        "weight": "bold",
                                                        "align": "center",
                                                        "color": "{}".format(setbot["background"])
                                                    },
                                                    {
                                                        "type": "text",
                                                        "text": "{}".format(text),
                                                        "size": "4xl",
                                                        "weight": "bold",
                                                        "align": "center",
                                                        "color": "{}".format(setbot["background"])
                                                    },
                                                    {
                                                        "type": "text",
                                                        "text": "{}".format(text),
                                                        "size": "4xl",
                                                        "weight": "bold",
                                                        "align": "center",
                                                        "color": "{}".format(setbot["background"])
                                                    },
                                               ]
                                           }
                                        }
                                    ]
                                }
                            }
                            sendTemplate(to, data)
                        elif cmd == "#help3":
                            sender_profile = noobcoder.getContact(sender)
                            data = {
                                "type": "flex",
                                "altText": "help message",
                                "contents": {
                                    "type": "carousel",
                                    "contents": [
                                         {
                                            "type": "bubble",
                                            "styles": {
                                                "header": {"backgroundColor": "{}".format(setbot["background"])},
                                                "footer": {"backgroundColor": "{}".format(setbot["background"]),"separator": True, "separatorColor": "{}".format(setbot["background"])}
                                            },
                                            "body": {
                                                "type": "box",
                                                "layout": "vertical",
                                                "spacing": "md",
                                                "action": {
                                                    "type": "uri",
                                                    "uri": "line://nv/profilePopup/mid=u8c31fa0e60d1eee2558ee7c634614e67",
                                                    },
                                                "contents": [
                                                    {
                                                        "type": "text",
                                                        "text": "Help Message",
                                                        "size": "lg",
                                                        "weight": "bold",
                                                        "align": "center",
                                                        "color": "{}".format(setbot["background"])
                                                    },
                                                    {
                                                        "type": "text",
                                                        "text": "Chatbot",
                                                        "size": "sm",
                                                        'flex': 1,
                                                    },
                                                    {
                                                        "type": "text",
                                                        "text": "Feature",
                                                        "size": "sm",
                                                        'flex': 1,
                                                    },
                                                    {
                                                        "type": "text",
                                                        "text": "Images",
                                                        "size": "sm",
                                                        'flex': 1,
                                                    },
                                                    {
                                                        "type": "text",
                                                        "text": "Profile",
                                                        "size": "sm",
                                                        'flex': 1,
                                                    },
                                                    {
                                                        "type": "text",
                                                        "text": "Protect",
                                                        "size": "sm",
                                                        'flex': 1,
                                                    },
                                                    {
                                                        "type": "text",
                                                        "text": "Social",
                                                        "size": "sm",
                                                        'flex': 1,
                                                    },                                 
                                                    {
                                                        "type": "text",
                                                        "text": "Timeline",
                                                        "size": "sm",
                                                        'flex': 1,
                                                    },
                                                    {
                                                        "type": "text",
                                                        "text": "Self",
                                                        "size": "sm",
                                                        'flex': 1,
                                                    },
                                                    {
                                                        "type": "text",
                                                        "text": "Settings",
                                                        "size": "sm",
                                                        'flex': 1,
                                                    }                       
                                               ]
                                           },
                                            "footer": {
                                                "type": "box",
                                                "layout": "vertical",
                                                "spacing": "sm",
                                                "contents": [
                                                    {
                                                        "type": "box",
                                                        "layout": "baseline",
                                                        "contents": [
                                                            {
                                                                "type": "icon",
                                                                "url": "https://i.ibb.co/jrrMPdG/1553179449707.jpg",
                                                                "size": "md"
                                                            },
                                                            {
                                                                "type": "text",
                                                                "text": "FREE SELFBOT",
                                                                "align": "center",
                                                                "color": "{}".format(setbot["text"]),
                                                                "size": "md"
                                                            },
                                                            {
                                                                "type": "spacer",
                                                                "size": "sm",
                                                            }
                                                        ]
                                                    }
                                                ]
                                           }
                                        },
                                         {
                                            "type": "bubble",
                                            "styles": {
                                                "header": {"backgroundColor": "{}".format(setbot["background"])},
                                                "footer": {"backgroundColor": "{}".format(setbot["background"]), "separator": True, "separatorColor": "{}".format(setbot["background"])}
                                            },
                                            "body": {
                                                "type": "box",
                                                "layout": "vertical",
                                                "spacing": "md",
                                                "action": {
                                                    "type": "uri",
                                                    "uri": "line://nv/profilePopup/mid=u8c31fa0e60d1eee2558ee7c634614e67",
                                                    },
                                                "contents": [
                                                    {
                                                        "type": "text",
                                                        "text": "Help Message",
                                                        "size": "lg",
                                                        "weight": "bold",
                                                        "align": "center",
                                                        "color": "{}".format(setbot["background"])
                                                    },
                                                    {
                                                        "type": "text",
                                                        "text": "Banning",
                                                        "size": "sm",
                                                        'flex': 1,
                                                    },
                                                    {
                                                        "type": "text",
                                                        "text": "Github",
                                                        "size": "sm",
                                                        'flex': 1,
                                                    },
                                                    {
                                                        "type": "text",
                                                        "text": "Friend",
                                                        "size": "sm",
                                                        'flex': 1,
                                                    },
                                                    {
                                                        "type": "text",
                                                        "text": "Translate",
                                                        "size": "sm",
                                                        'flex': 1,
                                                    },
                                                    {
                                                        "type": "text",
                                                        "text": "Memegen",
                                                        "size": "sm",
                                                        'flex': 1,
                                                    },
                                                    {
                                                        "type": "text",
                                                        "text": "Kick",
                                                        "size": "sm",
                                                        'flex': 1,
                                                    },
                                                    {
                                                        "type": "text",
                                                        "text": "Utility",
                                                        "size": "sm",
                                                        'flex': 1,
                                                    },
                                                    {
                                                        "type": "text",
                                                        "text": "Wordban",
                                                        "size": "sm",
                                                        'flex': 1,
                                                    },
                                                    {
                                                        "type": "text",
                                                        "text": "Bcast",
                                                        "size": "sm",
                                                        'flex': 1,
                                                    }                       
                                               ]
                                           },
                                            "footer": {
                                                "type": "box",
                                                "layout": "vertical",
                                                "spacing": "sm",
                                                "contents": [
                                                    {
                                                        "type": "box",
                                                        "layout": "baseline",
                                                        "contents": [
                                                            {
                                                                "type": "icon",
                                                                "url": "https://i.ibb.co/jrrMPdG/1553179449707.jpg",
                                                                "size": "md"
                                                            },
                                                            {
                                                                "type": "text",
                                                                "text": "FREE SELFBOT",
                                                                "align": "center",
                                                                "color": "{}".format(setbot["text"]),
                                                                "size": "md"
                                                            },
                                                            {
                                                                "type": "spacer",
                                                                "size": "sm",
                                                            }
                                                        ]
                                                    }
                                                ]
                                           }
                                        },
                                         {
                                            "type": "bubble",
                                            "styles": {
                                                "header": {"backgroundColor": "{}".format(setbot["background"])},
                                                "footer": {"backgroundColor": "{}".format(setbot["background"]), "separator": True, "separatorColor": "{}".format(setbot["background"])}
                                            },
                                            "body": {
                                                "type": "box",
                                                "layout": "vertical",
                                                "spacing": "md",
                                                "action": {
                                                    "type": "uri",
                                                    "uri": "line://nv/profilePopup/mid=u8c31fa0e60d1eee2558ee7c634614e67",
                                                    },
                                                "contents": [
                                                    {
                                                        "type": "text",
                                                        "text": "Help Message",
                                                        "size": "lg",
                                                        "weight": "bold",
                                                        "align": "center",
                                                        "color": "{}".format(setbot["background"])
                                                    },
                                                    {
                                                        "type": "text",
                                                        "text": "Mention",
                                                        "size": "sm",
                                                        'flex': 1,
                                                    },
                                                    {
                                                        "type": "text",
                                                        "text": "Group",
                                                        "size": "sm",
                                                        'flex': 1,
                                                    },
                                                    {
                                                        "type": "text",
                                                        "text": "Steal",
                                                        "size": "sm",
                                                        'flex': 1,
                                                    },
                                                    {
                                                        "type": "text",
                                                        "text": "List",
                                                        "size": "sm",
                                                        'flex': 1,
                                                    },
                                                    {
                                                        "type": "text",
                                                        "text": "Timeleft",
                                                        "size": "sm",
                                                        'flex': 1,
                                                    },
                                                    {
                                                        "type": "text",
                                                        "text": "Leave",
                                                        "size": "sm",
                                                        'flex': 1,
                                                    },
                                                    {
                                                        "type": "text",
                                                        "text": "Reboot",
                                                        "size": "sm",
                                                        'flex': 1,
                                                    },
                                                    {
                                                        "type": "text",
                                                        "text": "About",
                                                        "size": "sm",
                                                        'flex': 1,
                                                    },
                                                    {
                                                        "type": "text",
                                                        "text": "Logout",
                                                        "size": "sm",
                                                        'flex': 1,
                                                    }                       
                                               ]
                                           },
                                            "footer": {
                                                "type": "box",
                                                "layout": "vertical",
                                                "spacing": "sm",
                                                "contents": [
                                                    {
                                                        "type": "box",
                                                        "layout": "baseline",
                                                        "contents": [
                                                            {
                                                                "type": "icon",
                                                                "url": "https://i.ibb.co/jrrMPdG/1553179449707.jpg",
                                                                "size": "md"
                                                            },
                                                            {
                                                                "type": "text",
                                                                "text": "FREE SELFBOT",
                                                                "align": "center",
                                                                "color": "{}".format(setbot["text"]),
                                                                "size": "md"
                                                            },
                                                            {
                                                                "type": "spacer",
                                                                "size": "sm",
                                                            }
                                                        ]
                                                    }
                                                ]
                                            }
                                        }
                                    ]
                                }
                            }
                            sendTemplate(to, data)

                        if cmd == "#about":
                                sender_profile = noobcoder.getContact(sender)
                                groups = noobcoder.getGroupIdsJoined()
                                contactz = noobcoder.getAllContactIds()
                                blockeds = noobcoder.getBlockedContactIds()
                                tz = pytz.timezone("Asia/Makassar")
                                timeNow = datetime.now(tz=tz)
                                day = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday","Friday", "Saturday"]
                                hari = ["Minggu", "Senin", "Selasa", "Rabu", "Kamis", "Jumat", "Sabtu"]
                                bulan = ["Januari", "Februari", "Maret", "April", "Mei", "Juni", "Juli", "Agustus", "September", "Oktober", "November", "Desember"]
                                hr = timeNow.strftime("%A")
                                bln = timeNow.strftime("%m")
                                timeNoww = time.time()
                                runtime = timeNoww - noobcoderStart
                                runtime = timeChange(runtime)
                                for i in range(len(day)):
                                   if hr == day[i]: hasil = hari[i]
                                for k in range(0, len(bulan)):
                                   if bln == str(k): bln = bulan[k-1]
                                readTime = hasil + ", " + timeNow.strftime('%d') + " - " + bln + " - " + timeNow.strftime('%Y') + "\n│ Jam : [ " + timeNow.strftime('%H:%M:%S') + " ]"
                                data={"type":"flex","altText":"NOOB CODER™","contents":{
  "type": "bubble",
  "body": {
    "type": "box",
    "layout": "vertical",
    "contents": [
      {
        "type": "box",
        "layout": "horizontal",
        "contents": [
          {
            "type": "image",
            "url": "https://obs.line-scdn.net/{}".format(noobcoder.getContact(noobcoderMID).pictureStatus)
          },
          {
            "type": "separator",
            "color": "{}".format(setbot["separator"])
          },
          {
            "type": "image",
            "url": str(noobcoder.getProfileCoverURL(sender)),
          }
        ],
        "borderWidth": "1px",
        "borderColor": "{}".format(setbot["separator"]),
        "cornerRadius": "4px"
      },
      {
        "type": "box",
        "layout": "vertical",
        "contents": [
          {
            "type": "separator",
            "color": "{}".format(setbot["separator"])
          },
          {
            "type": "text",
            "text": "SELF BOTS",
            "size": "md",
            "margin": "md",
            "color": "{}".format(setbot["text"]),
            "weight": "bold",
            "align": "center",
            "wrap": True
          },
          {
            "type": "separator",
            "margin": "md",
            "color": "{}".format(setbot["separator"])
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "User : {}".format(noobcoder.getProfile().displayName),
                "size": "xs",
                "color": "{}".format(setbot["text"]),
                "wrap": True
              },
              {
                "type": "text",
                "text": "Bot Running : {}".format(str(runtime)),
                "size": "xs",
                "color": "{}".format(setbot["text"]),
                "wrap": True
              },
              {
                "type": "text",
                "text": "Chat Send : {}".format(str(peler["sendcount"])),
                "size": "xs",
                "color": "{}".format(setbot["text"]),
                "wrap": True
              },
              {
                "type": "text",
                "text": "Chat Received : {}".format(str(peler["receivercount"])),
                "size": "xs",
                "color": "{}".format(setbot["text"]),
                "wrap": True
              },
              {
                "type": "text",
                "text": "Groups : {}".format(str(len(groups))),
                "size": "xs",
                "color": "{}".format(setbot["text"]),
                "wrap": True
              },
              {
                "type": "text",
                "text": "Friends : {}".format(str(len(contactz))),
                "size": "xs",
                "color": "{}".format(setbot["text"]),
                "wrap": True
              },
              {
                "type": "text",
                "text": "Blocked : {}".format(str(len(blockeds))),
                "size": "xs",
                "color": "{}".format(setbot["text"]),
                "wrap": True
              },
              {
                "type": "text",
                "text": "Type : SelfBots",
                "size": "xs",
                "color": "{}".format(setbot["text"]),
                "wrap": True
              },
              {
                "type": "text",
                "text": "Ver : 9.1",
                "size": "xs",
                "color": "{}".format(setbot["text"]),
                "wrap": True
              },
              {
                "type": "text",
                "text": "Powered :\nNOOB CODER™",
                "size": "xs",
                "color": "{}".format(setbot["text"]),
                "wrap": True
              },
              {
                "type": "box",
                "layout": "horizontal",
                "contents": [
                  {
                    "type": "box",
                    "layout": "horizontal",
                    "contents": [
                      {
                        "type": "image",
                        "url": "https://i.ibb.co/4mbftvy/IMG-20190809-211441.jpg",
                        "size": "xxs",
                        "align": "center"
                      }
                    ],
                    "width": "25px",
                    "height": "25px"
                  },
                  {
                    "type": "box",
                    "layout": "horizontal",
                    "contents": [
                      {
                        "type": "text",
                        "text": "Maker",
                        "size": "md",
                        "color": "{}".format(setbot["text"]),
                        "weight": "bold",
                        "align": "center",
                        "action": {
                          "type": "uri",
                          "label": "action",
                          "uri": "line://app/1643727178-0XPGAaRX?type=fotext&text=Support"
                        }
                      },
                      {
                        "type": "box",
                        "layout": "horizontal",
                        "contents": [
                          {
                            "type": "image",
                            "url": "https://i.ibb.co/4mbftvy/IMG-20190809-211441.jpg",
                            "size": "xxs"
                          }
                        ],
                        "width": "25px",
                        "height": "25px"
                      }
                    ]
                  }
                ],
                "offsetTop": "-2px",
                "borderWidth": "1px",
                "borderColor": "{}".format(setbot["separator"]),
                "cornerRadius": "4px",
                "margin": "lg"
              }
            ],
            "margin": "lg"
          }
        ],
        "margin": "lg"
      }
    ],
    "cornerRadius": "xl",
    "borderColor": "{}".format(setbot["separator"]),
    "borderWidth": "4px",
    "offsetTop": "0px",
    "offsetBottom": "0px",
    "offsetStart": "0px",
    "paddingAll": "20px",
    "paddingTop": "18px"
  },
  "styles": {
    "body": {
      "backgroundColor": "{}".format(setbot["background"])
    }
  }
}}
                                sendTemplate(to, data)
                                
                        if cmd == "#about":
                                sender_profile = noobcoder.getContact(sender)
                                groups = noobcoder.getGroupIdsJoined()
                                contactz = noobcoder.getAllContactIds()
                                blockeds = noobcoder.getBlockedContactIds()
                                tz = pytz.timezone("Asia/Makassar")
                                timeNow = datetime.now(tz=tz)
                                day = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday","Friday", "Saturday"]
                                hari = ["Minggu", "Senin", "Selasa", "Rabu", "Kamis", "Jumat", "Sabtu"]
                                bulan = ["Januari", "Februari", "Maret", "April", "Mei", "Juni", "Juli", "Agustus", "September", "Oktober", "November", "Desember"]
                                hr = timeNow.strftime("%A")
                                bln = timeNow.strftime("%m")
                                timeNoww = time.time()
                                runtime = timeNoww - noobcoderStart
                                runtime = timeChange(runtime)
                                for i in range(len(day)):
                                   if hr == day[i]: hasil = hari[i]
                                for k in range(0, len(bulan)):
                                   if bln == str(k): bln = bulan[k-1]
                                readTime = hasil + ", " + timeNow.strftime('%d') + " - " + bln + " - " + timeNow.strftime('%Y') + "\n│ Jam : [ " + timeNow.strftime('%H:%M:%S') + " ]"
                                data = {
                                        "type": "flex",
                                        "altText": "KhieWasHere",
                                        "contents": {
  "styles": {
    "body": {
      "backgroundColor": "{}".format(setbot["background"])
    },
    "footer": {
      "backgroundColor": "{}".format(setbot["background"])
    }
  },
  "type": "bubble",
  "body": {
    "contents": [
      {
        "contents": [
          {
            "url": "https://obs.line-scdn.net/{}".format(noobcoder.getContact(noobcoderMID).pictureStatus),
            "type": "image"
          },
          {
            "type": "separator",
            "color": "{}".format(setbot["separator"])
          },
          {
            "url": str(noobcoder.getProfileCoverURL(sender)),
            "type": "image"
          }
        ],
        "type": "box",
        "spacing": "md",
        "layout": "horizontal"
      },
      {
        "type": "separator",
        "color": "{}".format(setbot["separator"])
      },
      {
        "contents": [
          {
            "text": "SELF BOTS",
            "size": "md",
            "align": "center",
            "color": "{}".format(setbot["text"]),
            "wrap": True,
            "weight": "bold",
            "type": "text"
          }
        ],
        "type": "box",
        "spacing": "md",
        "layout": "vertical"
      },
      {
        "type": "separator",
        "color": "{}".format(setbot["separator"])
      },
      {
        "contents": [
          {
            "contents": [
              {
                "text": "User : {}".format(noobcoder.getProfile().displayName),
                "size": "xs",
                "margin": "none",
                "color": "{}".format(setbot["text"]),
                "weight": "regular",
                "type": "text"
              }
            ],
            "type": "box",
            "layout": "baseline"
          },
          {
            "contents": [
              {
                "text": "Bot Running : {}".format(str(runtime)),
                "size": "xs",
                "margin": "none",
                "color": "{}".format(setbot["text"]),
                "wrap": True,
                "weight": "regular",
                "type": "text"
              }
            ],
            "type": "box",
            "layout": "baseline"
          },
          {
            "contents": [
              {
                "text": "Chat Send : {}".format(str(peler["sendcount"])),
                "size": "xs",
                "margin": "none",
                "color": "{}".format(setbot["text"]),
                "wrap": True,
                "weight": "regular",
                "type": "text"
              }
            ],
            "type": "box",
            "layout": "baseline"
          },
          {
            "contents": [
              {
                "text": "Chat Received : {}".format(str(peler["receivercount"])),
                "size": "xs",
                "margin": "none",
                "color": "{}".format(setbot["text"]),
                "wrap": True,
                "weight": "regular",
                "type": "text"
              }
            ],
            "type": "box",
            "layout": "baseline"
          },
          {
            "contents": [
              {
                "text": "Groups : {}".format(str(len(groups))),
                "size": "xs",
                "margin": "none",
                "color": "{}".format(setbot["text"]),
                "wrap": True,
                "weight": "regular",
                "type": "text"
              }
            ],
            "type": "box",
            "layout": "baseline"
          },
          {
            "contents": [
              {
                "text": "Friends : {}".format(str(len(contactz))),
                "size": "xs",
                "margin": "none",
                "color": "{}".format(setbot["text"]),
                "wrap": True,
                "weight": "regular",
                "type": "text"
              }
            ],
            "type": "box",
            "layout": "baseline"
          },
          {
            "contents": [
              {
                "text": "Blocked : {}".format(str(len(blockeds))),
                "size": "xs",
                "margin": "none",
                "color": "{}".format(setbot["text"]),
                "wrap": True,
                "weight": "regular",
                "type": "text"
              }
            ],
            "type": "box",
            "layout": "baseline"
          },
          {
            "contents": [
              {
                "text": "Type : SelfBots",
                "size": "xs",
                "margin": "none",
                "color": "{}".format(setbot["text"]),
                "wrap": True,
                "weight": "regular",
                "type": "text"
              }
            ],
            "type": "box",
            "layout": "baseline"
          },
          {
            "contents": [
              {
                "text": "Ver : 9.1",
                "size": "xs",
                "margin": "none",
                "color": "{}".format(setbot["text"]),
                "wrap": True,
                "weight": "regular",
                "type": "text"
              }
            ],
            "type": "box",
            "layout": "baseline"
          },
          {
            "contents": [
              {
                "text": "Powered :\nNOOB CODER™",
                "size": "xs",
                "margin": "none",
                "color": "{}".format(setbot["text"]),
                "wrap": True,
                "weight": "regular",
                "type": "text"
              }
            ],
            "type": "box",
            "layout": "baseline"
          }
        ],
        "type": "box",
        "layout": "vertical"
      }
    ],
    "type": "box",
    "spacing": "md",
    "layout": "vertical"
  },
  "footer": {
    "contents": [
      {
        "contents": [
          {
            "contents": [
              {
                "text": "Maker",
                "size": "sm",
                "action": {
                  "uri": "line://ti/p/~khiewuzzheree",
                  "type": "uri",
                  "label": "Add Maker"
                },
                "margin": "xl",
                "align": "center",
                "color": "{}".format(setbot["text"]),
                "weight": "bold",
                "type": "text"
              }
            ],
            "type": "box",
            "layout": "baseline"
          }
        ],
        "type": "box",
        "layout": "horizontal"
      }
    ],
    "type": "box",
    "layout": "vertical"
  }
}
}
                                sendTemplate(to, data)
                        if cmd == "me":
                            contact = noobcoder.getContact(sender)
                            LINKFOTO = "https://os.line.naver.jp/os/p/" + sender
                            data={"type":"flex","altText":"NOOB CODER™","contents":{
  "type": "bubble",
  "body": {
    "type": "box",
    "layout": "vertical",
    "cornerRadius": "xl",
    "borderWidth": "4px",
    "borderColor": "{}".format(setbot["separator"]),
    "contents": [
      {
        "type": "separator",
        "color": "{}".format(setbot["background"])
      },
      {
        "type": "box",
        "layout": "horizontal",
        "contents": [
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "url": "https://obs.line-scdn.net/{}".format(contact.pictureStatus),
                "aspectMode": "cover",
                "size": "full"
              }
            ],
            "cornerRadius": "100px",
            "width": "30px",
            "height": "30px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "box",
                "layout": "baseline",
                "contents": [
                  {
                    "type": "text",
                    "text": "{}".format(contact.displayName),
                    "size": "md",
                    "color": "{}".format(setbot["text"])
                  }
                ],
                "spacing": "md",
                "margin": "sm",
                "offsetTop": "2px"
              }
            ]
          }
        ],
        "spacing": "xl",
        "paddingAll": "6px"
      },
      {
        "type": "image",
        "url": "https://obs.line-scdn.net/{}".format(contact.pictureStatus),
        "size": "full",
        "aspectMode": "cover",
        "aspectRatio": "1:1",
        "gravity": "center"
      },
      {
        "type": "box",
        "layout": "horizontal",
        "contents": [
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "url": "https://i.ibb.co/7WWFvYS/love.png",
                "aspectMode": "cover",
                "size": "full"
              }
            ],
            "cornerRadius": "100px",
            "width": "30px",
            "height": "30px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "url": "https://i.ibb.co/d7fw2r8/comment.png",
                "size": "full"
              }
            ],
            "cornerRadius": "100px",
            "width": "30px",
            "height": "30px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "url": "https://i.ibb.co/kKY0RQt/share.png",
                "size": "full"
              }
            ],
            "cornerRadius": "100px",
            "width": "30px",
            "height": "30px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "url": "https://i.ibb.co/2j82H5G/saved.png",
                "aspectMode": "cover",
                "size": "full",
                "align": "end"
              }
            ],
            "cornerRadius": "100px",
            "width": "30px",
            "height": "30px",
            "offsetStart": "155px"
          }
        ],
        "spacing": "sm",
        "paddingAll": "6px"
      },
      {
        "type": "box",
        "layout": "vertical",
        "contents": [
          {
            "type": "spacer",
            "size": "md"
          }
        ]
      },
      {
        "type": "box",
        "layout": "vertical",
        "contents": [
          {
            "type": "separator",
            "color": "{}".format(setbot["separator"])
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "FREE SELFBOT",
                "size": "xl",
                "color": "{}".format(setbot["text"]),
                "weight": "bold",
                "align": "center"
              }
            ],
            "paddingAll": "6px"
          }
        ]
      }
    ],
    "paddingAll": "0px",
    "backgroundColor": "{}".format(setbot["background"])
  }
}}
                            sendTemplate(to,data)                                
                        if cmd == "me2":
                            if noobcoder.profile.pictureStatus != None:
                                b = "https://obs.line-scdn.net/" + noobcoder.profile.pictureStatus
                            else:
                                b = "https://goo.gl/MMeyzi"
                            data = {
                                "type": "flex",
                                "altText": "KhieWasHere",
                                "contents": {
                                "type": "bubble",
                                "styles": {
                                    "body": {"backgroundColor": "{}".format(setbot["background"])}
                                },
                                "body": {
                                "type": "box",
                                "layout": "vertical",
                                "cornerRadius": "xl",
                                "borderWidth": "4px",
                                "borderColor": "{}".format(setbot["separator"]),
                                "spacing": "md",
                                "contents": [
                                    {
                                        "type": "text",
                                        "text": "SELFBOTS EDITION",
                                        "wrap": True,
                                        "weight": "bold",
                                        "color": "{}".format(setbot["text"]),
                                        "gravity": "center",
                                        "size": "xl"
                                    },
                                    {
                                        "type": "box",
                                        "layout": "baseline",
                                        "margin": "md",
                                        "contents": [
                                            {
                                                "type": "text",
                                                "text": "Rate ",
                                                "size": "sm",
                                                "color": "{}".format(setbot["text"]),
                                                "margin": "md",
                                                "flex": 0
                                            },
                                            {
                                                "type": "icon",
                                                "size": "sm",
                                                "url": "https://scdn.line-apps.com/n/channel_devcenter/img/fx/review_gold_star_28.png"
                                            },
                                            {
                                                "type": "icon",
                                                "size": "sm",
                                                "url": "https://scdn.line-apps.com/n/channel_devcenter/img/fx/review_gold_star_28.png"
                                            },
                                            {
                                                 "type": "icon",
                                                 "size": "sm",
                                                 "url": "https://scdn.line-apps.com/n/channel_devcenter/img/fx/review_gold_star_28.png"
                                            },
                                            {
                                                 "type": "icon",
                                                 "size": "sm",
                                                 "url": "https://scdn.line-apps.com/n/channel_devcenter/img/fx/review_gold_star_28.png"
                                            },
                                            {
                                                  "type": "icon",
                                                 "size": "sm",
                                                 "url": "https://scdn.line-apps.com/n/channel_devcenter/img/fx/review_gray_star_28.png"
                                            },
                                            {
                                                "type": "text",
                                                "text": "4.0",
                                                "size": "sm",
                                                "color": "{}".format(setbot["text"]),
                                                "margin": "md",
                                                "flex": 0
                                            }
                                        ]
                                    },
                                    {
                                        "type": "box",
                                        "layout": "vertical",
                                        "margin": "lg",
                                        "spacing": "sm",
                                        "contents": [
                                            {
                                                "type": "box",
                                                "layout": "baseline",
                                                "spacing": "sm",
                                                "contents": [
                                                    {
                                                        "type": "text",
                                                        "text": "Name :",
                                                        "color": "{}".format(setbot["text"]),
                                                        "size": "sm",
                                                        "flex": 1
                                                    },
                                                    {
                                                        "type": "text",
                                                        "text": noobcoder.profile.displayName,
                                                        "wrap": True,
                                                        "size": "sm",
                                                        "color": "{}".format(setbot["text"]),
                                                        "flex": 4
                                                    }
                                                ]
                                            }
                                        ]
                                    },
                                    {
                                        "type": "box",
                                        "layout": "vertical",
                                        "margin": "xxl",
                                        "contents": [
                                            {
                                                "type": "spacer"
                                            },
                                            {
                                                "type": "image",
                                                "url": b,
                                                "aspectMode": "cover",
                                                "size": "full"
                                            },
                                            {
                                                "type": "text",
                                                "text": "Created : Khie",
                                                "color": "{}".format(setbot["text"]),
                                                "wrap": True,
                                                "margin": "xxl",
                                                "size": "xs"
                                            }
                                        ]
                                    }
                                ]
                            }
                            }}
                            sendTemplate(to, data)
                        if cmd == "me3":
                                contact = noobcoder.getProfile()
                                mids = [contact.mid]
                                status = noobcoder.getContact(sender)
                                sender_profile = noobcoder.getContact(sender)
                                LINKFOTO = "https://os.line.naver.jp/os/p/" + sender
                                LINKVIDEO = "https://os.line.naver.jp/os/p/" + sender + "/vp"
                                gifnya = ['#000000','#FF0032']
                                data = {
                                        "type": "flex",
                                        "altText": "KhieWasHere",
                                        "contents": {
  "type": "bubble",
  "body": {
    "type": "box",
    "layout": "horizontal",
    "spacing": "md",
    "contents": [
      {
        "type": "box",
        "layout": "vertical",
        "flex": 2,
        "contents": [
          {
            "type": "text",
            "flex": 2,
            "text": "{}".format(status.displayName),
            "size": "md",
            "wrap": True,
            "weight": "bold",
            "gravity": "center",
            "color": "{}".format(random.choice(gifnya)),
          },
          {
            "type": "separator",
            "color": "#000000"
          },
          {
            "type": "text",
            "text": "{}".format(status.statusMessage),
            "size": "md",
            "color": "{}".format(random.choice(gifnya)),
            "wrap": True
          }
        ]
      }
    ]
  },
  "styles": {
    "body": {
      "backgroundColor": "#FFFFFF"
    },
    "footer": {
      "backgroundColor": "{}".format(setbot["background"])
    }
  },
  "hero": {
    "type": "image",
    "url": "https://obs.line-scdn.net/{}".format(noobcoder.getContact(sender).pictureStatus),
    "size": "full",
    "margin": "xl"
  },
  "footer": {
    "type": "box",
    "layout": "horizontal",
    "contents": [
      {
        "type": "text",
        "text": "Cover",
        "size": "md",
        "wrap": True,
        "weight": "bold",
        "color": "#FFFFFF",
        "action": {
          "type": "uri",
          "uri": str(noobcoder.getProfileCoverURL(sender)),
        },
        "align": "center"
      },
      {
        "type": "separator",
        "color": "#FFFFFF"
      },
      {
        "type": "text",
        "text": "Video",
        "size": "md",
        "wrap": True,
        "weight": "bold",
        "color": "#FFFFFF",
        "action": {
          "type": "uri",
          "uri": "line://app/1643727178-0XPGAaRX?type=video&ocu={}&piu={}".format(LINKVIDEO,LINKFOTO)
        },
        "align": "center"
      }
    ]
  }
}
}
                                sendTemplate(to, data)
                        elif cmd == "fak":
                            data = {
                                "type": "template",
                                "altText": "Image carouserl",
                                "template": {
                                    "type": "image_carousel",
                                    "columns": [
                                        {
                                            "imageUrl":"https://stickershop.line-scdn.net/stickershop/v1/sticker/694837/IOS/sticker@2x.png",
                                            "size": "full",
                                            "action": {
                                                "type": "uri",
                                                "uri": "line://ti/p/~khiewuzzheree"
                                            }
                                        }
                                    ]
                                }
                            }
                            sendTemplate(to, data)
                        elif cmd == "randomtiktok":
                            contact = noobcoder.getContact(sender)
                            data = {
                                "type": "video",
                                "originalContentUrl": "https://rest.farzain.com/api/tiktok.php?apikey=fn",
                                "previewImageUrl": "https://obs.line-scdn.net/{}".format(contact.pictureStatus),
                                }
                            sendTemplate(to, data)
                        elif cmd.startswith("footer "):
                            khie = text.split(" ")
                            hey = text.replace(khie[0] + " ", "")
                            text = "{}".format(hey)
                            data = {
                                "type": "text",
                                "text": "{}".format(text),
                                "sentBy": {
                                    "label": "{}".format(noobcoder.getContact(noobcoderMID).displayName),
                                    "iconUrl": "https://obs.line-scdn.net/{}".format(noobcoder.getContact(noobcoderMID).pictureStatus),
                                    "linkUrl": "line://ti/p/~khiewuzzheree"
                                }
                            }
                            sendTemplate(to, data)
                        elif cmd.startswith("dor "):
                           sep = text.split(" ")
                           midn = text.replace(sep[0] + " ","")
                           hmm = text.lower()
                           G = noobcoder.getGroup(msg.to)
                           members = [G.mid for G in G.members]
                           targets = []
                           imkhie = 'simple.js gid={} token={} app={}'.format(to, noobcoder.authToken, "IOSIPAD\t11.2.5\tiPhone X\t11.2.5")
                           for x in members:
                               contact = noobcoder.getContact(x)
                               msg = op.message
                               testt = contact.displayName.lower()
                                   #print(testt)
                               if midn in testt:targets.append(contact.mid)
                           if targets == []:return noobcoder.sendMessage(to,"not found name "+midn)
                           for target in targets:
                             imkhie += ' uid={}'.format(target)
                           success = execute_js(imkhie)

                        elif cmd.startswith("skill "):
                           sep = text.split(" ")
                           midn = text.replace(sep[0] + " ","")
                           hmm = text.lower()
                           G = noobcoder.getGroup(msg.to)
                           members = [G.mid for G in G.members]
                           targets = []
                           for x in members:
                               contact = noobcoder.getContact(x)
                               msg = op.message
                               testt = contact.displayName.lower()
                                   #print(testt)
                               if midn in testt:targets.append(contact.mid)
                           if targets == []:return noobcoder.sendMessage(to,"not found name "+midn)
                           for target in targets:
                               noobcoder.kickoutFromGroup(msg.to,[target])

                        elif cmd.startswith("nk "):
                            nk0 = text.replace("nk ","")
                            nk1 = nk0.lstrip()
                            nk2 = nk1.replace("@","")
                            nk3 = nk2.rstrip()
                            _name = nk3
                            gs = noobcoder.getGroup(to)
                            targets = []
                            for s in gs.members:
                                if _name in s.displayName:
                                    targets.append(s.mid)
                            if targets == []:
                                sendFooter(to,"Target not match.")
                            else:
                                cms = 'simple.js gid={} token={} app={}'.format(to, noobcoder.authToken, "IOSIPAD\t11.2.5\tiPhone X\t11.2.5")
                                for y in targets:
                                    cms += ' uid={}'.format(y)
                                success = execute_js(cms)
                                if success:
                                    sendFooter(to,'Execute success')
                                else:
                                     sendFooter(to,'error')

                        elif cmd.startswith("kickass "):
                           sep = text.split(" ")
                           midn = text.replace(sep[0] + " ","")
                           hmm = text.lower()
                           G = noobcoder.getGroup(msg.to)
                           members = [G.mid for G in G.members]
                           targets = []
                           for x in members:
                               contact = noobcoder.getContact(x)
                               msg = op.message
                               testt = contact.displayName.lower()
                               if midn in testt:targets.append(contact.mid)
                           if targets == []:return noobcoder.sendMessage(to,"not found name "+midn)
                           for target in targets:
                               noobcoder.kickoutFromGroup(msg.to,[target])
                               noobcoder.findAndAddContactsByMid(target)
                               noobcoder.inviteIntoGroup(msg.to, [target])
                               noobcoder.cancelGroupInvitation(msg.to, [target])
                               time.sleep(5)
                               noobcoder.inviteIntoGroup(msg.to, [target])
                        if cmd.startswith("addcontact "):
                            global contacts
                            name = cmd.replace("addcontact ","")
                            name = name.lower()
                            if name not in contacts:
                                settings["addContact"]["status"] = True
                                settings["addContact"]["name"] = name.lower()
                                contacts[name.lower()] = {}
                                f = codecs.open('khie/contact.json','w','utf-8')
                                json.dump(contacts, f, sort_keys=True, indent=4, ensure_ascii=False)
                                sendFooter(to,"Send a contact to add to command {}.".format(name.lower()))
                            else:
                                noobcoder.sendMessage(to,"Contact no to add to command {} because in the list".format(name.lower()))
                        elif cmd.startswith('ssweb'):
                            sep = text.split(" ")
                            query = text.replace(sep[0] + " ","")
                            r = "https://image.thum.io/get/width/1200/http://{}".format(query)
                            noobcoder.sendImageWithURL(receiver, r)
                        elif text.lower().startswith('sifatnama'):
                            try:
                                sep = text.split(" ")
                                search = text.replace(sep[0] + " ","")
                                r = requests.get("http://syadnysyz2.herokuapp.com/api/ramalan-nama?nama=/{}".format(search))
                                data = r.json()
                                a="Sifat Nama :\n"
                                a+="\nRomantis : "+str(data["result"]["romantis"])
                                a+="\nMesum : "+str(data["result"]["mesum"])
                                a+="\nMiris : "+str(data["result"]["miris"])
                                a+="\nTulus : "+str(data["result"]["tulus"])
                                a+="\nLoyal : "+str(data["result"]["loyal"])
                                sendFooter(to,a)
                            except Exception as e:
                                noobcoder.sendReplyMessage(msg.id, to, str(e))
                        if cmd.startswith("delcontact "):
                            name = cmd.replace("delcontact ","")
                            name = name.lower()
                            if name in contacts:
                                del contacts[name.lower()]
                                f = codecs.open('khie/contact.json','w','utf-8')
                                json.dump(contacts, f, sort_keys=True, indent=4, ensure_ascii=False)
                                noobcoder.sendMessage(to,"Contact to del to command {}.".format(name.lower()))
                            else:
                                noobcoder.sendMessage(to,"Contact no to del to command {} because not in the list".format(name.lower()))
                        if cmd == "list contact":
                            with open('khie/contact.json','r') as fp:
                                contacts = json.load(fp)
                            if contacts == {}:
                                noobcoder.sendMessage(to,"Command contact does not exist.")
                            else:
                                ret_ = "「 List Contact 」"
                                no = 1
                                for contact in contacts:
                                    ret_ += "\n    {}. {}".format(str(no),str(contact.title()))
                                    no += 1                           
                                sendFooter(to, ret_)
                        elif cmd == "topnews":
                             try:
                                 api_key = "a53cb61cee4d4c518b69473893dba73b"
                                 r = _session.get("https://newsapi.org/v2/top-headlines?country=id&apiKey={}".format(str(api_key)))
                                 data = r.text
                                 data = json.loads(data)
                                 ret_ = "「Top News」"
                                 no = 1
                                 anu = data["articles"]
                                 if len(anu) >= 5:
                                     for s in range(5):
                                         syit = anu[s]
                                         sumber = syit['source']['name']
                                         author = syit['author']
                                         judul = syit['title']
                                         url = syit['url']
                                         ret_ += "\n\n{}. Judul : {}\n    Sumber : {}\n    Penulis : {}\n    Link : {}".format(str(no), str(judul), str(sumber), str(author), str(url))
                                         no += 1
                                 else:
                                     for s in anu:
                                         syit = s
                                         sumber = syit['source']['name']
                                         author = syit['author']
                                         judul = syit['title']
                                         url = syit['url']
                                         ret_ += "\n\n{}. Judul : {}\n    Sumber : {}\n    Penulis : {}\n    Link : {}".format(str(no), str(judul), str(sumber), str(author), str(url))
                                         no += 1
                                 noobcoder.sendMessage(to, str(ret_))
                             except:
                                 noobcoder.sendMessage(to, "Not Found !")
                        if cmd == 'gcall':
                            a = noobcoder.getGroupCall(to)
                            print(a)
                            k = len(a.memberMids)//20
                            for i in range(k+1):
                                try:
                                    if i == 0:aa = '╭「 Group Call 」─\n│In {}\n│Call started in: {}'.format(noobcoder.getGroup(to).name,humanize.naturaltime(datetime.fromtimestamp(int(a.started)//1000)));no = i
                                    else:aa = '├「 Group Call 」─\n│In {}\n│Call started in: {}'.format(noobcoder.getGroup(to).name,humanize.naturaltime(datetime.fromtimestamp(int(a.starter)//1000)));no=i*20
                                    ret = aa
                                    for b in a.memberMids[i*20 : (i+1)*20]:
                                        no += 1
                                        c = a.hostMids
                                        if a.mediaType == 1:typenya = 'Free Call Group'
                                        if a.mediaType == 2:typenya = 'Video Call Group'
                                        if no == len(a.memberMids):ret+='\n╰{}. @!\n  • Type: {}\nHost: @!'.format(no,typenya)
                                        else:ret+='\n│{}. @!'.format(no)
                                    noobcoder.sendMention(to, ret,"",a.memberMids[i*20 : (i+1)*20]+[c])
                                except:
                                    if a.mediaType == 3:typenya = 'Group Live'
                                    if i == 0:aa = '╭「 Group Live 」─\n│In {}\n│Live started in: {}\n│   • Member watch:'.format(noobcoder.getGroup(to).name,humanize.naturaltime(datetime.fromtimestamp(int(a.started)//1000)));no = i
                                    else:aa = '├「 Group Live 」─\n│In {}\n│Live started in: {}\n│   • Member Watch:'.format(noobcoder.getGroup(to).name,humanize.naturaltime(datetime.fromtimestamp(int(a.starter)//1000)));no=i*20
                                    ret = aa
                                    for b in a.memberMids[i*20 : (i+1)*20]:
                                        no += 1
                                        c = a.hostMids
                                        if no == len(a.memberMids):ret+='\n╰{}. @!\n  • Type: {}\nHost: @!'.format(no,typenya)
                                        else:ret+='\n│{}. @!'.format(no)
                                    noobcoder.sendMention(to, ret,"",a.memberMids[i*20 : (i+1)*20]+[c])
                        elif cmd.startswith("calc "):
                            query = cmd.replace("calc ","")
                            r=requests.get("https://www.calcatraz.com/calculator/api?c={}".format(urllib.parse.quote(query)))
                            data=r.text
                            data=json.loads(data)
                            sendFooter(msg.to, query + " = " + str(data))
                        elif cmd.startswith("mimicadd ") and sender == noobcoderMID:
                            targets = []
                            key = eval(msg.contentMetadata["MENTION"])
                            key["MENTIONEES"][0]["M"]
                            for x in key["MENTIONEES"]:
                                targets.append(x["M"])
                            for target in targets:
                                try:
                                    mimikin["mimic"]["target"][target] = True
                                    noobcoder.sendMessage(msg.to,"Has been Added")
                                    break
                                except:
                                    noobcoder.sendMessage(msg.to,"Added Target Fail !")
                                    break
                        elif cmd.startswith("mimicdel ") and sender == noobcoderMID:
                            targets = []
                            key = eval(msg.contentMetadata["MENTION"])
                            key["MENTIONEES"][0]["M"]
                            for x in key["MENTIONEES"]:
                                targets.append(x["M"])
                            for target in targets:
                                try:
                                    del mimikin["mimic"]["target"][target]
                                    noobcoder.sendMessage(msg.to,"Has been Deleted")
                                    break
                                except:
                                    noobcoder.sendMessage(msg.to,"Deleted Target Fail !")
                                    break
                        elif cmd == "mimiclist":
                            if settings["mimic"]["target"] == {}:
                                noobcoder.sendMessage(msg.to,"Nothing")
                            else:
                                mc = "「 Mimic List 」\n"
                                for mi_d in mimikin["mimic"]["target"]:
                                    mc += "\n"+noobcoder.getContact(mi_d).displayName
                                noobcoder.sendMessage(msg.to,mc + "\n")
                        elif cmd.startswith("mimic ") and sender == noobcoderMID:
                            mic = removeCmd("mimic", text)
                            if mic == "on":
                                if mimikin["mimic"]["status"] == False:
                                    mimikin["mimic"]["status"] = True
                                    noobcoder.sendMessage(msg.to,"Mimic has been Enabled")
                            elif mic == "off":
                                if mimikin["mimic"]["status"] == True:
                                    mimikin["mimic"]["status"] = False
                                    noobcoder.sendMessage(msg.to,"Mimic has been Disabled")
                        elif cmd.startswith("timezone "):
                            try:
                                search = cmd.replace("timezone ","")
                                r = requests.get("https://time.siswadi.com/geozone/{}".format(urllib.parse.quote(search)))
                                data=r.text
                                data=json.loads(data)
                                ret_ = "「 Timezone 」\n"
                                ret_ += "\nLatitude : " +str(data["data"]["latitude"])
                                ret_ += "\nLongitude : " +str(data["data"]["longitude"])
                                ret_ += "\nAddress : " +str(data["data"]["address"])
                                ret_ += "\nCountry : " +str(data["data"]["country"])
                                sendFooter(to, str(ret_))
                            except Exception as error:
                               noobcoder.sendMessage(to, str(error))                                    
                        elif cmd.startswith("praytime "):
                            sep = text.split(" ")
                            txt = text.replace(sep[0]+ " ","")
                            url = requests.get("https://time.siswadi.com/pray/{}".format(txt))
                            data = url.json()
                            ret_ = "Praytime at {}\n".format(txt)
                            ret_ += "\nDate : {}".format(data["time"]["date"])
                            ret_ += "\nSubuh : {}".format(data["data"]["Fajr"])
                            ret_ += "\nDzuhur : {}".format(data["data"]["Dhuhr"])
                            ret_ += "\nAshar : {}".format(data["data"]["Asr"])
                            ret_ += "\nMagrib : {}".format(data["data"]["Maghrib"])
                            ret_ += "\nIsha : {}".format(data["data"]["Isha"])
                            ret_ += "\n1/3 Malam : {}".format(data["data"]["SepertigaMalam"])
                            ret_ += "\nTengah Malam : {}".format(data["data"]["TengahMalam"])
                            ret_ += "\n2/3 Malam : {}".format(data["data"]["DuapertigaMalam"])
                            sendFooter(to, str(ret_))   
                        elif cmd.startswith("brainly "):
                            sep = text.split(" ")
                            txt = text.replace(sep[0] + " ","")
                            url = requests.get("https://rest.farzain.com/api/brainly.php?id={}&apikey=oQ61nCJ2YBIP1qH25ry6cw2ba".format(txt))
                            data = url.json()
                            no = 0
                            result = "Brainly :\n"
                            for anu in data:
                                no += 1
                                result += "\n{}. {}".format(str(no),str(anu["title"]))
                                result += "\n{}".format(str(anu["url"]))
                            result += "\n\nTotal {} Jawaban".format(str(len(data)))
                            sendFooter1(to, result)                               
                        elif cmd.startswith("astronotnow"):  
                            with requests.session() as web:
                                web.headers["User-Agent"] = random.choice(settings["userAgent"])
                                r = web.get("http://api.open-notify.org/astros.json")
                                data = r.text
                                data = json.loads(data)
                                if data["message"] == "success":
                                    if data["people"] != []:
                                        number = data["number"]
                                        people = data["people"]
                                        ret_ = "Date Astronot :\n"
                                        for i in people:
                                           ret_ += "\nName : {}".format(str(i["name"]))
                                           ret_ += "\nStation : {}".format(str(i["craft"]))
                                        ret_ += "\nCurrently there : {}".format(str(number))
                                        sendFooter(to, str(ret_))
                                    else:
                                        sendFooter(to, "Nothing")
                                else:
                                    noobcoder.sendReplyMessage(msg.id, to, "Error404")                
                        elif cmd == "bitcoin" or cmd == " bitcoin":
                            r=requests.get("https://xeonwz.herokuapp.com/bitcoin.api")
                            data=r.text
                            data=json.loads(data)
                            hasil = "「 Bitcoin 」\n" 
                            hasil += "\nPrice : " +str(data["btc"])
                            hasil += "\nExpensive : " +str(data["high"])
                            hasil += "\nCheap : " +str(data["low"])
                            noobcoder.sendMessage(msg.to, str(hasil))
                        elif cmd == "anitoki":
                            result = requests.get("http://anitoki.com/")
                            data = BeautifulSoup(result.content, 'html5lib')
                            hasil = "「 Anitoki 」\nType : Last Update\n"
                            no = 1
                            for dzin in data.findAll('div', attrs={'class':'content'}):
                                hasil += "\n\n{}. {}".format(str(no), str(dzin.find('h2').text))
                                hasil += "\n     Link : {}".format(str(dzin.find('a')['href']))
                                no = (no+1)
                            noobcoder.sendMessage(to, str(hasil))
                        elif cmd == "cinema xx1":
                            result = requests.get("http://jadwalnonton.com/")
                            data = BeautifulSoup(result.content, 'html5lib')
                            hasil = "「 Cinema XX1 」\nType : Movie List Today\n"
                            no = 1
                            for dzin in data.findAll('div', attrs={'class':'col-xs-6 moside'}):
                                hasil += "\n\n{}. {}".format(str(no), str(dzin.find('h2').text))
                                hasil += "\n     Link : {}".format(str(dzin.find('a')['href']))
                                no = (no+1)
                            noobcoder.sendMessage(to, str(hasil))
                        elif cmd == "system":
                            ac = subprocess.getoutput('lsb_release -a')
                            am = subprocess.getoutput('cat /proc/meminfo')
                            ax = subprocess.getoutput('lscpu')
                            core = subprocess.getoutput('grep -c ^processor /proc/cpuinfo ')
                            python_imp = platform.python_implementation()
                            python_ver = platform.python_version()
                            for line in ac.splitlines():
                                if 'Description:' in line:
                                    osi = line.split('Description:')[1].replace('  ','')
                            for line in ax.splitlines():
                                if 'Architecture:' in line:
                                    architecture =  line.split('Architecture:')[1].replace(' ','')
                            for line in am.splitlines():
                                if 'MemTotal:' in line:
                                    mem = line.split('MemTotal:')[1].replace(' ','')
                                if 'MemFree:' in line:
                                    fr = line.split('MemFree:')[1].replace(' ','')
                            md = "⚒️ System\n\n"
                            md +="OS: {}\n".format(osi)
                            md +="Lang: {}\n".format(python_imp)
                            md +="Ver: {}\n".format(python_ver)
                            md +="Architecture: {}\n".format(architecture)
                            md +="CPU Core: {}\n".format(core)
                            md +="Memory: {}\n".format(mem)
                            md +="Free: {}".format(fr)
                            sendFooter(to,md)
                        elif cmd == "about2":
                            try:
                                arr = []
                                today = datetime.today()
                                thn = 2018 
                                bln = 8    #isi bulannya yg sewa
                                hr = 9   #isi tanggalnya yg sewa
                                future = datetime(thn, bln, hr)
                                days = (str(future - today))
                                comma = days.find(",")
                                days = days[:comma]
                                h = noobcoder.getContact(noobcoderMID)
                                groups = noobcoder.getGroupIdsJoined()
                                contactlist = noobcoder.getAllContactIds()
                                kontak = noobcoder.getContacts(contactlist)
                                favorite = noobcoder.getFavoriteMids()
                                blockedlist = noobcoder.getBlockedContactIds()
                                kontak2 = noobcoder.getContacts(blockedlist)
                                fil = noobcoder.getSettings().privacyReceiveMessagesFromNotFriend
                                seal = noobcoder.getSettings().e2eeEnable
                                src = noobcoder.getSettings().privacySearchByUserid
                                status = {"kick": "", "invite": ""}
                                try:noobcoder.kickoutFromGroup(to, [noobcoderMID]);status["kick"] = "Normal"
                                except:status["kick"] = "Limit"
                                try:noobcoder.inviteIntoGroup(to, [noobcoderMID]);status["invite"] = "Normal"
                                except:status["invite"] = "Limit"
                                if src == True:alid = "Add From LineID : True"
                                else:alid = "Add From LineID : False"                            
                                if seal == True:letsel = "Letter Sealing : True"
                                if seal == False:letsel = "Letter Sealing : False"
                                if fil == True:fpes = "Filter Message : False"
                                if fil == False:fpes = "Filter Message : True"
                                ret_ = "About noobcoder :\n"
                                ret_ += "\nnoobcoder : {}".format(h.displayName)
                                ret_ += "\nGroup : {}".format(str(len(groups)))
                                ret_ += "\nFriend : {}".format(str(len(kontak)))
                                ret_ += "\nFavorite: {}".format(str(len(favorite)))
                                ret_ += "\nBlocked : {}".format(str(len(kontak2)))
                                ret_ += "\nChat Send: {}".format(str(peler["sendcount"]))
                                ret_ += "\nChat Received : {}".format(str(peler["receivercount"]))
                                ret_ += "\n{}".format(alid)
                                ret_ += "\n{}".format(letsel)
                                ret_ += "\n{}".format(fpes)
                                ret_ += "\nKick : %s" % status["kick"]
                                ret_ += "\nInvite : %s" % status["invite"]
                                ret_ += "\n\n< About Bots >\n"
                                ret_ += "\nType : Selfbot"
                                ret_ += "\nVersion : V.09\n"
                                ret_ += "\nMaker : Khie"
                                sendFooter(to, str(ret_))
                            except Exception as e:
                                noobcoder.sendMessage(to, str(e))
                        elif cmd == "fight":
                               group = noobcoder.getGroup(to)
                               try:
                                   members = [mem.mid for mem in group.members]
                                   mortal = [mem.mid for mem in group.members]
                               except:
                                   members = [mem.mid for mem in group.members]
                                   mortal = [mem.mid for mem in group.members]
                               s = random.choice(members)
                               t = random.choice(mortal)
                               sam = "Mortal Kombat has been initiated. "+noobcoder.getContact(s).displayName+" must fight..."+noobcoder.getContact(t).displayName+"! FIGHTO!"
                               noobcoder.generateReplyMessage(msg.id)
                               noobcoder.sendReplyMessage(msg.id, to,str(sam))
                        elif cmd == "fancypict off":
                            settings["fancy"]["status"] = False
                            settings["fancy"]["foto1"] = []
                            settings["fancy"]["foto2"] = []
                            settings["fancy"]["foto3"] = []
                            sendFooter(to, " 「 Fancy 」\nType: Fancy picture\n • Status: DISABLED\n • Fancypict: Clear...")
                        elif cmd.startswith("fancypict on "):
                            settings['fancy']['foto1'] = []
                            settings['fancy']['foto2'] = []
                            settings['fancy']['foto3'] = []
                            if to not in settings["fancy"]["foto1"]:
                                settings["fancy"]["foto1"].append(to)
                            msg.text = noobcoder.mycmd(msg.text,wait)
                            wait['waktu'] = int(msg.text.split(" ")[2])
                            sendFooter(to, "Waiting for picture, please send a picture...")
                        elif cmd == "changedp fancy":
                            settings["fancy"]["foto1"] = []
                            settings["fancy"]["foto2"] = []
                            settings["fancy"]["foto3"] = []
                            if to not in settings["fancy"]["foto1"]:
                                settings["fancy"]["foto1"].append(to)
                                wait['waktu'] = 5
                            sendFooter(to, "Waiting for picture...")
                        elif cmd == "picture uploaded to fancy picture 1":
                            if to not in settings["fancy"]["foto2"]:
                                settings["fancy"]["foto2"].append(to)
                            sendFooter(to, "Send pict again..")
                        elif cmd == "picture uploaded to fancy picture 2":
                            if to not in settings["fancy"]["foto3"]:
                                settings["fancy"]["foto3"].append(to)
                            sendFooter(to, "Send pict again...")
                        elif cmd == "delallchat" and sender == noobcoderMID:
                            noobcoder.removeAllMessages(op.param2)
                            noobcoder.generateReplyMessage(msg.id)
                            noobcoder.sendReplyMessage(msg.id, to, "Deleted")
                        elif cmd == 'square' or cmd == ' squares':
                            a = noobcoder.getJoinedSquares()
                            squares = a.squares
                            txt2 = '「 Squares 」\n'
                            for s in range(len(squares)):
                                txt2 += "\n"+str(s+1)+". "+str(squares[s].name)
                            txt2 += "\n\nTotal {} Squares.".format(str(len(squares)))
                            txt2 += "\n\nUsage : Square [num]"
                            sendFooter(to,str(txt2))
                        elif cmd.startswith("square"):
                            number = removeCmd("square",text)
                            squares = noobcoder.getJoinedSquares().squares
                            ret_ = "「 Square 」\n"
                            try:
                                square = squares[int(number)-1]
                                path = "http://dl.profile.line-cdn.net/" + square.profileImageObsHash
                                ret_ += "\n1. Name : {}".format(str(square.name))
                                ret_ += "\n2. Description: {}".format(str(square.desc))
                                ret_ += "\n3. ID Square : {}".format(str(square.mid))
                                ret_ += "\n4. Link : {}".format(str(square.invitationURL))
                                noobcoder.sendImageWithURL(to, path)
                                sendFooter(to,str(ret_))
                            except Exception as error:
                                noobcoder.sendMessage(to, str(error))
                        elif cmd.startswith("$"):
                            if msg._from in myAdmin:
                                kntl = removeCmd("$", text)
                                ikkeh = os.popen("{}".format(str(kntl)))
                                enaena = ikkeh.read()
                                noobcoder.sendMessage(to, "{}".format(str(enaena)))
                                ikkeh.close()
                        elif cmd == "screenlist":
                            if msg._from in myAdmin:
                                proses = os.popen("screen -list")
                                a = proses.read()
                                sendFooter1(to, "{}".format(str(a)))
                                proses.close()
                        elif cmd.startswith("urban "):
                            sep = text.split(" ")
                            judul = text.replace(sep[0] + " ","")
                            url = "http://api.urbandictionary.com/v0/define?term="+str(judul)
                            with requests.session() as s:
                                s.headers["User-Agent"] = random.choice(settings["userAgent"])
                                r = s.get(url)
                                data = r.text
                                data = json.loads(data)
                                y = "Result Urban :\n"
                                y += "\nAuthor: "+str(data["list"][0]["author"])
                                y += "\nWord: "+str(data["list"][0]["word"])
                                y += "\nLink: "+str(data["list"][0]["permalink"])
                                y += "\nDefinition: "+str(data["list"][0]["definition"])
                                y += "\nExample: "+str(data["list"][0]["example"])                                
                                sendFooter1(to, str(y))
                        elif cmd.startswith("arti-nama "):
                            sep = text.split(" ")
                            nama = text.replace(sep[0] + " ","")
                            with requests.session() as s:
                                s.headers['user-agent'] = 'Mozilla/5.0'
                                r = s.get("http://primbon.com/arti_nama.php?nama1={}&proses=+Submit%21+".format(urllib.parse.quote(nama)))
                                soup = BeautifulSoup(r.content, 'html5lib')
                                for anu in soup.findAll('div', attrs={'id':'body'}):
                                    data = anu.get_text()
                                    rep = data.replace('ARTI','<b>ARTI')
                                    res = rep.replace('< Hitung Kembali','</b>')
                                    data1 = BeautifulSoup(res, 'html5lib')
                                    for content in data1:
                                        ret_ = content.b.string
                                        sendFooter1(to, ret_)
                        elif cmd.startswith("indo:"):
                             proses = text.split(" ")
                             pesan = text.replace(proses[0] + " ","")
                             logs = TEXTLIB().translator(is_html=False, text=pesan, lang_to='id', proxy=False)
                             sendFooter1(to, str(logs))
                        elif cmd.startswith("eng:"):
                             proses = text.split(" ")
                             pesan = text.replace(proses[0] + " ","")
                             logs = TEXTLIB().translator(is_html=False, text=pesan, lang_to='en', proxy=False)
                             sendFooter1(to, str(logs))
                        elif cmd.startswith("korea:"):
                             proses = text.split(" ")
                             pesan = text.replace(proses[0] + " ","")
                             logs = TEXTLIB().translator(is_html=False, text=pesan, lang_to='ko', proxy=False)
                             sendFooter1(to, str(logs))
                        elif cmd.startswith("thai:"):
                             proses = text.split(" ")
                             pesan = text.replace(proses[0] + " ","")
                             logs = TEXTLIB().translator(is_html=False, text=pesan, lang_to='th', proxy=False)
                             sendFooter1(to, str(logs))
                        elif cmd.startswith("arab:"):
                             proses = text.split(" ")
                             pesan = text.replace(proses[0] + " ","")
                             logs = TEXTLIB().translator(is_html=False, text=pesan, lang_to='ar', proxy=False)
                             sendFooter1(to, str(logs))
                        elif cmd.startswith("russia:"):
                             proses = text.split(" ")
                             pesan = text.replace(proses[0] + " ","")
                             logs = TEXTLIB().translator(is_html=False, text=pesan, lang_to='ru', proxy=False)
                             sendFooter1(to, str(logs))
                        elif cmd.startswith("japan:"):
                             proses = text.split(" ")
                             pesan = text.replace(proses[0] + " ","")
                             logs = TEXTLIB().translator(is_html=False, text=pesan, lang_to='ja', proxy=False)
                             sendFooter1(to, str(logs))
                        elif cmd.startswith("malay:"):
                             proses = text.split(" ")
                             pesan = text.replace(proses[0] + " ","")
                             logs = TEXTLIB().translator(is_html=False, text=pesan, lang_to='ms', proxy=False)
                             sendFooter1(to, str(logs))
                        elif cmd.startswith("french:"):
                             proses = text.split(" ")
                             pesan = text.replace(proses[0] + " ","")
                             logs = TEXTLIB().translator(is_html=False, text=pesan, lang_to='fr', proxy=False)
                             sendFooter1(to, str(logs))
                        elif cmd.startswith("german:"):
                             proses = text.split(" ")
                             pesan = text.replace(proses[0] + " ","")
                             logs = TEXTLIB().translator(is_html=False, text=pesan, lang_to='de', proxy=False)
                             sendFooter1(to, str(logs))
                        elif cmd.startswith("italy:"):
                             proses = text.split(" ")
                             pesan = text.replace(proses[0] + " ","")
                             logs = TEXTLIB().translator(is_html=False, text=pesan, lang_to='it', proxy=False)
                             sendFooter1(to, str(logs))
                        elif cmd.startswith("czech:"):
                             proses = text.split(" ")
                             pesan = text.replace(proses[0] + " ","")
                             logs = TEXTLIB().translator(is_html=False, text=pesan, lang_to='cs', proxy=False)
                             sendFooter1(to, str(logs))
                        elif cmd.startswith("turky:"):
                             proses = text.split(" ")
                             pesan = text.replace(proses[0] + " ","")
                             logs = TEXTLIB().translator(is_html=False, text=pesan, lang_to='tr', proxy=False)
                             sendFooter1(to, str(logs))
                        elif cmd.startswith("india:"):
                             proses = text.split(" ")
                             pesan = text.replace(proses[0] + " ","")
                             logs = TEXTLIB().translator(is_html=False, text=pesan, lang_to='hi', proxy=False)
                             sendFooter1(to, str(logs))
                        elif cmd.startswith("spain:"):
                             proses = text.split(" ")
                             pesan = text.replace(proses[0] + " ","")
                             logs = TEXTLIB().translator(is_html=False, text=pesan, lang_to='es', proxy=False)
                             sendFooter1(to, str(logs))
                        if cmd.startswith('zalgo '):
                            def zalgo(text):return zalgoname().zalgofy(noobcoder.mainsplit(text))
                            noobcoder.sendMessage(to, zalgo(text))                            
                        elif cmd == "gotcha":
                            spam = hmmk()
                            noobcoder.sendMessage(to, str(spam))
                        elif cmd == "randomname":
                            r=requests.get("http://uinames.com/api/")
                            data=r.text
                            data=json.loads(data)
                            hasil = "Random Name :\n\n"
                            hasil += "Name: " + str(data["name"])                                              
                            hasil += "\nLastName: " + str(data["surname"])
                            hasil += "\nGender: " + str(data["gender"])
                            hasil += "\nCountry: " + str(data["region"])      
                            sendFooter(to,str(hasil))
                        elif cmd.startswith("kaskus "):
                            query = cmd.replace("kaskus ","")
                            cond = query.split("|")
                            search = str(cond[0])
                            result = requests.get("https://api.bayyu.net/kaskus-hotthread/?apikey=c28c944199384f191335f1f8924414fa839350d&page={}".format(str(search)))
                            data = result.text
                            data = json.loads(data)
                            if len(cond) == 1:
                                num = 0
                                ret_ = " 「 Kaskus 」\nType: Search Kaskus"
                                for kus in data["hot_threads"]:
                                    num += 1
                                    ret_ += "\n{}. {}".format(str(num), str(kus["title"]))                                  
                                ret_ += "\n\nExample: {} Kaskus {}|1".format(str(setKey), str(search))
                                sendFooter(to, str(ret_))
                            elif len(cond) == 2:
                                num = int(cond[1])
                                if num <= len(data["hot_threads"]):
                                    kaskus = data["hot_threads"][num - 1]
                                    result = requests.get("https://api.bayyu.net/kaskus-hotthread/?apikey=c28c944199384f191335f1f8924414fa839350d&page={}".format(str(search)))
                                    data = result.text
                                    data = json.loads(data)
                                    if data["hot_threads"] != []:
                                        ret_ =" 「 Kaskus 」\nType: Detail Kaskus"
                                        ret_ += "\n   Description: {}".format(str(kaskus["detail"]))                                            
                                        ret_ += "\n   {}".format(str(kaskus["link"]))
                                        noobcoder.sendImageWithURL(to, str(kaskus["img"]))
                                        sendFooter1(to, str(ret_))
                        elif cmd == "dadjoke":
                            count = random.randint(0,500)
                            r=requests.get("http://api.icndb.com/jokes/%s"%count)
                            data=r.text
                            data=json.loads(data)
                            noobcoder.sendMessage(to, str(data["value"]["joke"]))
                        elif cmd == "love":
                            gifnya = ['https://thumbs.gfycat.com/InconsequentialRipeLeopardseal-small.gif']
                            data = {
                                "type": "template",
                                "altText": "Image carouserl",
                                "template": {
                                    "type": "image_carousel",
                                    "columns": [
                                        {
                                            "imageUrl": "{}".format(random.choice(gifnya)),
                                            "size": "full",
                                            "action": {
                                                "type": "uri",
                                                "uri": "line://ti/p/~khiewuzzheree"
                                            }
                                        }
                                    ]
                                }
                            }
                            sendTemplate(to, data)
                            
                        elif cmd == "test6":
                            data={"type":"flex","altText":"NOOB CODER™","contents":{
  "type": "bubble",
  "body": {
    "type": "box",
    "layout": "vertical",
    "contents": [
      {
        "type": "image",
        "url": "https://i.ibb.co/fYLky4k/1573042360208.png",
        "size": "full",
        "aspectMode": "cover",
        "aspectRatio": "1:1",
        "gravity": "center"
      },
      {
        "type": "box",
        "layout": "horizontal",
        "contents": [
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "text",
                    "text": "NOOB CODER™",
                    "size": "lg",
                    "color": "#ffffff",
                    "weight": "bold",
                    "align": "center",
                    "offsetStart": "15px"
                  }
                ]
              },
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "text",
                    "text": "Selfbots Edition",
                    "size": "sm",
                    "color": "#ffffff",
                    "weight": "bold",
                    "align": "center"
                  }
                ]
              },
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "spacer"
                  }
                ],
                "margin": "md"
              },
              {
                "type": "box",
                "layout": "horizontal",
                "contents": [
                  {
                    "type": "filler"
                  },
                  {
                    "type": "box",
                    "layout": "vertical",
                    "contents": [
                      {
                        "type": "text",
                        "text": "Login",
                        "size": "sm",
                        "color": "#ffffff",
                        "align": "center",
                        "action": {
                          "type": "uri",
                          "label": "action",
                          "uri": "https://nekopoi.care"
                        }
                      }
                    ],
                    "offsetStart": "0px"
                  },
                  {
                    "type": "filler"
                  },
                  {
                    "type": "box",
                    "layout": "vertical",
                    "contents": [
                      {
                        "type": "text",
                        "text": "Logout",
                        "size": "sm",
                        "color": "#ffffff",
                        "align": "center",
                        "action": {
                          "type": "uri",
                          "label": "action",
                          "uri": "https://nekopoi.care"
                        }
                      }
                    ],
                    "offsetStart": "10px"
                  },
                  {
                    "type": "filler"
                  }
                ],
                "margin": "lg"
              },
              {
                "type": "box",
                "layout": "horizontal",
                "contents": [
                  {
                    "type": "filler"
                  },
                  {
                    "type": "box",
                    "layout": "vertical",
                    "contents": [
                      {
                        "type": "text",
                        "text": "Login",
                        "size": "sm",
                        "color": "#ffffff",
                        "align": "center",
                        "action": {
                          "type": "uri",
                          "label": "action",
                          "uri": "https://nekopoi.care"
                        }
                      },
                      {
                        "type": "spacer"
                      }
                    ],
                    "offsetStart": "0px"
                  },
                  {
                    "type": "filler"
                  },
                  {
                    "type": "box",
                    "layout": "vertical",
                    "contents": [
                      {
                        "type": "text",
                        "text": "Logout",
                        "size": "sm",
                        "color": "#ffffff",
                        "align": "center",
                        "action": {
                          "type": "uri",
                          "label": "action",
                          "uri": "https://nekopoi.care"
                        }
                      }
                    ],
                    "offsetStart": "10px"
                  },
                  {
                    "type": "filler"
                  }
                ],
                "margin": "xl"
              },
              {
                "type": "box",
                "layout": "horizontal",
                "contents": [
                  {
                    "type": "filler"
                  },
                  {
                    "type": "box",
                    "layout": "vertical",
                    "contents": [
                      {
                        "type": "text",
                        "text": "Login",
                        "size": "sm",
                        "color": "#ffffff",
                        "align": "center",
                        "action": {
                          "type": "uri",
                          "label": "action",
                          "uri": "https://nekopoi.care"
                        }
                      }
                    ],
                    "offsetStart": "0px"
                  },
                  {
                    "type": "filler"
                  },
                  {
                    "type": "box",
                    "layout": "vertical",
                    "contents": [
                      {
                        "type": "text",
                        "text": "Logout",
                        "size": "sm",
                        "color": "#ffffff",
                        "align": "center",
                        "action": {
                          "type": "uri",
                          "label": "action",
                          "uri": "https://nekopoi.care"
                        }
                      }
                    ],
                    "offsetStart": "10px"
                  },
                  {
                    "type": "filler"
                  }
                ],
                "margin": "sm"
              },
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "spacer",
                    "size": "xxl"
                  },
                  {
                    "type": "filler"
                  },
                  {
                    "type": "box",
                    "layout": "vertical",
                    "contents": [
                      {
                        "type": "text",
                        "text": "Test",
                        "color": "#ffffff",
                        "align": "center"
                      }
                    ],
                    "margin": "lg",
                    "offsetEnd": "20px"
                  },
                  {
                    "type": "box",
                    "layout": "horizontal",
                    "contents": [
                      {
                        "type": "filler"
                      },
                      {
                        "type": "box",
                        "layout": "vertical",
                        "contents": [
                          {
                            "type": "text",
                            "text": "Test",
                            "size": "sm",
                            "color": "#ffffff",
                            "align": "center"
                          }
                        ],
                        "offsetEnd": "20px"
                      },
                      {
                        "type": "filler"
                      },
                      {
                        "type": "box",
                        "layout": "vertical",
                        "contents": [
                          {
                            "type": "text",
                            "text": "Test",
                            "size": "sm",
                            "color": "#ffffff",
                            "align": "center"
                          }
                        ],
                        "offsetEnd": "40px"
                      },
                      {
                        "type": "filler"
                      }
                    ],
                    "margin": "md"
                  }
                ],
                "margin": "md"
              },
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "filler"
                  }
                ],
                "margin": "sm"
              }
            ],
            "spacing": "xs"
          }
        ],
        "position": "absolute",
        "offsetBottom": "0px",
        "offsetStart": "0px",
        "offsetEnd": "0px",
        "paddingAll": "20px"
      }
    ],
    "paddingAll": "0px"
  }
}}
                            sendTemplate(to, data)

                            
                        elif cmd == "test5":
                            data={"type":"flex","altText":"NOOB CODER™","contents":{
  "type": "carousel",
  "contents": [
    {
  "type": "bubble",
  "body": {
    "type": "box",
    "layout": "vertical",
    "contents": [
      {
        "type": "box",
        "layout": "vertical",
        "contents": [
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "ABOUT MAKER",
                "size": "md",
                "color": "#ffffff",
                "weight": "bold",
                "align": "center",
                "wrap": True
              },
              {
                "type": "box",
                "layout": "horizontal",
                "contents": [
                  {
                    "type": "box",
                    "layout": "horizontal",
                    "contents": [
                      {
                        "type": "image",
                        "url": "https://i.ibb.co/4mbftvy/IMG-20190809-211441.jpg",
                        "size": "xxs",
                        "align": "center"
                      }
                    ],
                    "width": "25px",
                    "height": "25px"
                  },
                  {
                    "type": "box",
                    "layout": "horizontal",
                    "contents": [
                      {
                        "type": "text",
                        "text": "Khie",
                        "size": "md",
                        "color": "#ffffff",
                        "weight": "bold",
                        "align": "center",
                        "action": {
                          "type": "uri",
                          "label": "action",
                          "uri": "http://line.me/ti/p/~khiewuzzheree"
                        }
                      },
                      {
                        "type": "box",
                        "layout": "horizontal",
                        "contents": [
                          {
                            "type": "image",
                            "url": "https://i.ibb.co/4mbftvy/IMG-20190809-211441.jpg",
                            "size": "xxs"
                          }
                        ],
                        "width": "25px",
                        "height": "25px"
                      }
                    ]
                  }
                ],
                "offsetTop": "-2px",
                "borderWidth": "1px",
                "borderColor": "#ffffff",
                "cornerRadius": "4px",
                "margin": "lg"
              },
              {
                "type": "box",
                "layout": "horizontal",
                "contents": [
                  {
                    "type": "box",
                    "layout": "horizontal",
                    "contents": [
                      {
                        "type": "image",
                        "url": "https://i.ibb.co/4mbftvy/IMG-20190809-211441.jpg",
                        "size": "xxs",
                        "align": "center"
                      }
                    ],
                    "width": "25px",
                    "height": "25px"
                  },
                  {
                    "type": "box",
                    "layout": "horizontal",
                    "contents": [
                      {
                        "type": "text",
                        "text": "Agler",
                        "size": "md",
                        "color": "#ffffff",
                        "weight": "bold",
                        "align": "center",
                        "action": {
                          "type": "uri",
                          "label": "action",
                          "uri": "http://line.me/ti/p/~welovebigbang"
                        }
                      },
                      {
                        "type": "box",
                        "layout": "horizontal",
                        "contents": [
                          {
                            "type": "image",
                            "url": "https://i.ibb.co/4mbftvy/IMG-20190809-211441.jpg",
                            "size": "xxs"
                          }
                        ],
                        "width": "25px",
                        "height": "25px"
                      }
                    ]
                  }
                ],
                "offsetTop": "-2px",
                "borderWidth": "1px",
                "borderColor": "#ffffff",
                "cornerRadius": "4px",
                "margin": "lg"
              },
              {
                "type": "box",
                "layout": "horizontal",
                "contents": [
                  {
                    "type": "box",
                    "layout": "horizontal",
                    "contents": [
                      {
                        "type": "image",
                        "url": "https://i.ibb.co/4mbftvy/IMG-20190809-211441.jpg",
                        "size": "xxs",
                        "align": "center"
                      }
                    ],
                    "width": "25px",
                    "height": "25px"
                  },
                  {
                    "type": "box",
                    "layout": "horizontal",
                    "contents": [
                      {
                        "type": "text",
                        "text": "Rhyn",
                        "size": "md",
                        "color": "#ffffff",
                        "weight": "bold",
                        "align": "center",
                        "action": {
                          "type": "uri",
                          "label": "action",
                          "uri": "line://ti/p/~sayangadekzeefaa"
                        }
                      },
                      {
                        "type": "box",
                        "layout": "horizontal",
                        "contents": [
                          {
                            "type": "image",
                            "url": "https://i.ibb.co/4mbftvy/IMG-20190809-211441.jpg",
                            "size": "xxs"
                          }
                        ],
                        "width": "25px",
                        "height": "25px"
                      }
                    ]
                  }
                ],
                "offsetTop": "-2px",
                "borderWidth": "1px",
                "borderColor": "#ffffff",
                "cornerRadius": "4px",
                "margin": "lg"
              }
            ],
            "margin": "lg"
          }
        ],
        "margin": "lg"
      }
    ],
    "cornerRadius": "xl",
    "borderColor": "#ffffff",
    "borderWidth": "4px",
    "offsetTop": "0px",
    "offsetBottom": "0px",
    "offsetStart": "0px",
    "paddingAll": "20px",
    "paddingTop": "18px"
  },
  "styles": {
    "body": {
      "backgroundColor": "#000000"
    }
  }
},
{
  "type": "bubble",
  "body": {
    "type": "box",
    "layout": "vertical",
    "contents": [
      {
        "type": "box",
        "layout": "vertical",
        "contents": [
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "ABOUT MAKER",
                "size": "md",
                "color": "#ffffff",
                "weight": "bold",
                "align": "center",
                "wrap": True
              },
              {
                "type": "box",
                "layout": "horizontal",
                "contents": [
                  {
                    "type": "box",
                    "layout": "horizontal",
                    "contents": [
                      {
                        "type": "image",
                        "url": "https://i.ibb.co/4mbftvy/IMG-20190809-211441.jpg",
                        "size": "xxs",
                        "align": "center"
                      }
                    ],
                    "width": "25px",
                    "height": "25px"
                  },
                  {
                    "type": "box",
                    "layout": "horizontal",
                    "contents": [
                      {
                        "type": "text",
                        "text": "Khie",
                        "size": "md",
                        "color": "#ffffff",
                        "weight": "bold",
                        "align": "center",
                        "action": {
                          "type": "uri",
                          "label": "action",
                          "uri": "http://line.me/ti/p/~khiewuzzheree"
                        }
                      },
                      {
                        "type": "box",
                        "layout": "horizontal",
                        "contents": [
                          {
                            "type": "image",
                            "url": "https://i.ibb.co/4mbftvy/IMG-20190809-211441.jpg",
                            "size": "xxs"
                          }
                        ],
                        "width": "25px",
                        "height": "25px"
                      }
                    ]
                  }
                ],
                "offsetTop": "-2px",
                "borderWidth": "1px",
                "borderColor": "#ffffff",
                "cornerRadius": "4px",
                "margin": "lg"
              },
              {
                "type": "box",
                "layout": "horizontal",
                "contents": [
                  {
                    "type": "box",
                    "layout": "horizontal",
                    "contents": [
                      {
                        "type": "image",
                        "url": "https://i.ibb.co/4mbftvy/IMG-20190809-211441.jpg",
                        "size": "xxs",
                        "align": "center"
                      }
                    ],
                    "width": "25px",
                    "height": "25px"
                  },
                  {
                    "type": "box",
                    "layout": "horizontal",
                    "contents": [
                      {
                        "type": "text",
                        "text": "Agler",
                        "size": "md",
                        "color": "#ffffff",
                        "weight": "bold",
                        "align": "center",
                        "action": {
                          "type": "uri",
                          "label": "action",
                          "uri": "http://line.me/ti/p/~welovebigbang"
                        }
                      },
                      {
                        "type": "box",
                        "layout": "horizontal",
                        "contents": [
                          {
                            "type": "image",
                            "url": "https://i.ibb.co/4mbftvy/IMG-20190809-211441.jpg",
                            "size": "xxs"
                          }
                        ],
                        "width": "25px",
                        "height": "25px"
                      }
                    ]
                  }
                ],
                "offsetTop": "-2px",
                "borderWidth": "1px",
                "borderColor": "#ffffff",
                "cornerRadius": "4px",
                "margin": "lg"
              },
              {
                "type": "box",
                "layout": "horizontal",
                "contents": [
                  {
                    "type": "box",
                    "layout": "horizontal",
                    "contents": [
                      {
                        "type": "image",
                        "url": "https://i.ibb.co/4mbftvy/IMG-20190809-211441.jpg",
                        "size": "xxs",
                        "align": "center"
                      }
                    ],
                    "width": "25px",
                    "height": "25px"
                  },
                  {
                    "type": "box",
                    "layout": "horizontal",
                    "contents": [
                      {
                        "type": "text",
                        "text": "Rhyn",
                        "size": "md",
                        "color": "#ffffff",
                        "weight": "bold",
                        "align": "center",
                        "action": {
                          "type": "uri",
                          "label": "action",
                          "uri": "line://ti/p/~sayangadekzeefaa"
                        }
                      },
                      {
                        "type": "box",
                        "layout": "horizontal",
                        "contents": [
                          {
                            "type": "image",
                            "url": "https://i.ibb.co/4mbftvy/IMG-20190809-211441.jpg",
                            "size": "xxs"
                          }
                        ],
                        "width": "25px",
                        "height": "25px"
                      }
                    ]
                  }
                ],
                "offsetTop": "-2px",
                "borderWidth": "1px",
                "borderColor": "#ffffff",
                "cornerRadius": "4px",
                "margin": "lg"
              }
            ],
            "margin": "lg"
          }
        ],
        "margin": "lg"
      }
    ],
    "cornerRadius": "xl",
    "borderColor": "#ffffff",
    "borderWidth": "4px",
    "offsetTop": "0px",
    "offsetBottom": "0px",
    "offsetStart": "0px",
    "paddingAll": "20px",
    "paddingTop": "18px"
  },
  "styles": {
    "body": {
      "backgroundColor": "#000000"
    }
  }
}]}}
                            sendTemplate(to, data)
                        elif cmd == "lolzz":
                            contact = noobcoder.getContact(noobcoderMID)
                            tz = pytz.timezone("Asia/Jakarta")
                            timeNow = time.time()
                            runtime = timeNow - botStart
                            runtime = format_timespan(runtime)
                            data = {
                                "type": "flex",
                                "altText": "{} Send Flex".format(noobcoder.getProfile().displayName),
                                "contents": {
                                    "type": "bubble",
                                        'styles': {
                                            "body": {
                                                "backgroundColor": "{}".format(setbot["background"])
                                            },
                                            "footer": {
                                                "backgroundColor": '#FFFFFF'
                                            },
                                        },
                                        "hero":{
                                            "type":"image",
                                            "aspectMode":"cover",
                                            "url":"https://obs.line-scdn.net/{}".format(contact.pictureStatus),
                                            "size":"full"
                                        },
                                        "body":{
                                            "type":"box",
                                            "layout": "vertical",
                                            "contents":[
                                                {
                                                    "type":"separator",
                                                    "margin":"sm",
                                                    "color":"#FFFFFF"
                                                },
                                                {
                                                    "type":"text",
                                                    "align":"center",
                                                    "size":"lg",
                                                    "color":"#FFFFFF",
                                                    "text":"NOOBCODER™",
                                                },
                                                {
                                                    "type":"separator",
                                                    "margin":"sm",
                                                    "color":"#FFFFFF"
                                                },
                                                {
                                                    "type":"separator",
                                                    "margin":"sm",
                                                    "color":"#FFFFFF"
                                                },
                                                {
                                                    "type":"text",
                                                    "align":"center",
                                                    "size":"lg",
                                                    "color":"#FFFFFF",
                                                    "text":"{}".format(contact.displayName),
                                                },
                                                {
                                                    "type":"separator",
                                                    "margin":"sm",
                                                    "color":"#FFFFFF"
                                                },
                                                {
                                                    "type":"text",
                                                    "align":"center",
                                                    "size": "sm",
                                                    "color": "#FFFFFF",
                                                    "text":"{}".format(contact.statusMessage),
                                                    "wrap": True,
                                                    "flex": 2
                                                },
                                                {
                                                    "type":"separator",
                                                    "margin":"sm",
                                                    "color":"#FFFFFF"
                                                },
                                                {
                                                    "type":"text",
                                                    "align":"start",
                                                    "size":"xxs",
                                                    "color":"#FFFFFF",
                                                    "text":"Support By :"
                                                },
                                                {
                                                    "type":"box",
                                                    "layout":"horizontal",
                                                    "spacing":"md",
                                                    "margin":"sm",
                                                    "contents":[
                                                        {
                                                            "type":"text",
                                                            "align":"center",
                                                            "color":"#FFFFFF",
                                                            "size":"xs",
                                                            "text":"Rafly"
                                                        },
                                                        {
                                                            "type":"separator",
                                                            "margin":"md",
                                                            "color":"#FFFFFF"
                                                        },
                                                        {
                                                            "type":"text",
                                                            "align":"center",
                                                            "color":"#FFFFFF",
                                                            "size":"xs",
                                                            "text":"Khie"
                                                        }
                                                    ]
                                                },
                                                {
                                                    "type":"box",
                                                    "layout":"horizontal",
                                                    "spacing":"md",
                                                    "margin":"xs",
                                                    "contents":[
                                                        {
                                                            "type":"text",
                                                            "align":"center",
                                                            "color":"#FFFFFF",
                                                            "size":"xs",
                                                            "text":"Faisal"
                                                        },
                                                        {
                                                            "type":"separator",
                                                            "margin":"md",
                                                            "color":"#FFFFFF"
                                                        },
                                                        {
                                                            "type":"text",
                                                            "align":"center",
                                                            "color":"#FFFFFF",
                                                            "size":"xs",
                                                            "text":"Bagas"
                                                        }
                                                    ]
                                                },
                                                {
                                                    "type":"box",
                                                    "layout":"vertical",
                                                    "spacing":"md",
                                                    "contents":[
                                                        {
                                                            "type":"text",
                                                            "align":"center",
                                                            "color":"#FFFFFF",
                                                            "size":"xxs",
                                                            "text":"And Other Beside Me"
                                                        },
                                                        {
                                                            "type":"separator",
                                                            "color":"#FFFFFF"
                                                        },
                                                        {
                                                            "type":"text",
                                                            "align":"center",
                                                            "color":"#FFFFFF",
                                                            "size":"xxs",
                                                            "text":"Runtime :"
                                                        },
                                                        {
                                                            "type":"text",
                                                            "align":"center",
                                                            "color":"#FFFFFF",
                                                            "size":"xxs",
                                                            "text":"{}".format(runtime)
                                                        }
                                                    ]
                                                }
                                            ]
                                        },
                                        "footer": {
                                            "type": "box",
                                            "layout": "vertical",
                                            "spacing": "sm",
                                            "contents": [
                                                {
                                                    "type": "box",
                                                    "layout": "baseline",
                                                    "contents": [
                                                        {
                                                            "type": "icon",
                                                            "url": 'https://files.boteater.net/jpg-kygbqzld.jpg',
                                                            "size": "md"
                                                        },
                                                        {
                                                            "type": "text",
                                                            "text": "FREE SELFBOT",
                                                            "align": "center",
                                                            "color": "#000000",
                                                            "size": "md",
                                                            "action": 
                                                                {
                                                                    "type": "uri",
                                                                    "uri": "https://line.me/ti/p/~This_Me_HOOK"
                                                                }
                                                            },
                                                            {
                                                                "type": "spacer",
                                                                "size": "sm",
                                                            }
                                                        ]
                                                    }
                                                ]
                                            }
                                        }
                                    }
                            sendTemplate(to, data)
                        elif cmd.startswith("youtubemp4"):
                            link = removeCmd("youtubemp4", text)
                            youtubeMp4(to, link)
                        elif cmd.startswith("youtubemp3"):
                            link = removeCmd("youtubemp3", text)
                            youtubeMp3(to, link)
                        elif cmd.startswith("fileytmp4"):
                             link = removeCmd("fileytmp4", text)
                             fileYtMp4(to, link)
                        elif cmd.startswith("fileytmp3"):
                             link = removeCmd("fileytmp3", text)
                             fileYtMp3(to, link)
                        elif cmd.startswith("unblockmid "):
                            user = removeCmd("unblockmid", text)
                            noobcoder.unblockContact(user)
                            sendFooter(to, "Success Unblock Contact.")
                        elif cmd.startswith("blockmid "):
                            user = removeCmd("blockmid", text)
                            noobcoder.blockContact(user)
                            sendFooter(to, "Success Block Contact.")
                        elif cmd == "speedz":
                            start = time.time()
                            noobcoder.sendMessage("u8356f84ac11d24464fb797227e573c20", '</>')
                            elapsed_time = time.time() - start
                            noobcoder.sendMessage(to,"Time:\n%s"%str(round(elapsed_time,5)))
                        elif cmd == "reboot" and sender == noobcoderMID:
                            try:
                                noobcoder.sendMessage(to, "Brb , going to pee")
                            except: pass
                            settings["restartPoint"] = to
                            restartBot()
                        elif cmd == 'clearban':
                            wait["blacklist"] = []
                            noobcoder.sendMessage(to, "Done")
                        if cmd == "quotes":
                            r = requests.get("https://talaikis.com/api/quotes/random")
                            data=r.text
                            data=json.loads(data)
                            hasil = " 「 Quotes 」\n"
                            hasil += "Category: " +str(data["cat"])
                            hasil += "\n" +str(data["quote"])
                            hasil += "\nAuthor: " +str(data["author"])
                            sendFooter(to,str(hasil))
                        if cmd == "fmylife":
                            result = requests.get("http://www.fmylife.com/random")
                            data = BeautifulSoup(result.content, 'html5lib')                                                                             
                            for sam in data.findAll('figure', attrs={'class':'text-center visible-xs'}):                                        
                                path = str(sam.find('img')['data-src'])                                    
                            noobcoder.sendImageWithURL(to, str(path))
                        if cmd == "movienews":
                            count = random.randint(0,2)
                            result = requests.get("http://www.jadwaltv.net/artikel/page/%s"%count)
                            data = BeautifulSoup(result.content, 'html5lib')
                            hasil = " 「 Movie News 」"                                  
                            no = 1                                    
                            for sam in data.findAll('div', attrs={'class':'media'}):
                                hasil += "\n{}. {}".format(str(no), str(sam.find('a')['title']))
                                hasil += "\n{}".format(str(sam.find('a')['href']))                                        
                                no = (no+1)                                    
                            sendFooter1(to,str(hasil))
#=====================================================================
                        elif cmd.startswith("smulemp4 "):
                            try:
                                name = removeCmd("smulemp4", text)    
                                r = requests.get('http://beearchi.pw/tools/smule.php?link='+name)
                                data = r.text
                                data = json.loads(data)
                                sendFooter(to, "Processed upload...")
                                noobcoder.sendVideoWithURL(to,data["result"])
                            except:
                                sendFooter(to, "ERROR")   
                        elif cmd.startswith("smulefile "):
                            try:
                                name = removeCmd("smulefile", text)    
                                r = requests.get('http://beearchi.pw/tools/smule.php?link='+name)
                                data = r.text
                                data = json.loads(data)
                                sendFooter(to, "Processed upload...")
                                noobcoder.sendFileWithURL(to,data["result"])
                            except:
                                sendFooter(to, "ERROR")   
                        elif cmd.startswith("smulemp3 "):
                            try:
                                name = removeCmd("smulemp3", text)    
                                r = requests.get('http://beearchi.pw/tools/smule.php?link='+name)
                                data = r.text
                                data = json.loads(data)
                                sendFooter(to, "Processed upload...")
                                noobcoder.sendAudioWithURL(to,data["result"])
                            except:
                                sendFooter(to, "ERROR")   
                        elif cmd.startswith("azab "):
                            try:
                                aa = removeCmd("azab", text)
                                bb = requests.get("https://api.dzin.jp/api/azab/?apikey=beta&text=%s"%aa)
                                cc = json.loads(bb.text)
                                noobcoder.sendImageWithURL(to, str(cc["image"]))
                            except:
                                sendFooter(to, "ERROR")   
                        elif cmd.startswith("smuleprofile "):
                            try:
                                name = removeCmd("smuleprofile", text)
                                bb = requests.get("https://api.dzin.jp/api/smule/profile/?apikey=beta&username=%s"%name)
                                data = json.loads(bb.text)
                                aa = "  「Smule Profile」\n"
                                try:aa += "\n• Username : %s"%name
                                except:aa += ""
                                try:aa += "\n• First Name : %s"%data["result"]["user"]["first_name"]
                                except:aa += ""
                                try:aa += "\n• Last Name : %s"%data["result"]["user"]["last_name"]
                                except:aa += ""
                                try:aa += "\n• Followers : %s"%data["result"]["user"]["followers"]
                                except:aa += ""
                                try:aa += "\n• Following : %s"%data["result"]["user"]["followees"]
                                except:aa += ""
                                try:aa += "\n• VIP : %s"%data["result"]["user"]["is_vip"]
                                except:aa += ""
                                try:aa += "\n• Verified : %s"%data["result"]["user"]["is_verified"]
                                except:aa += ""
                                try:aa += "\n• Link : https://smule.com%s"%data["result"]["user"]["url"]
                                except:aa += ""
                                try:aa += "\n  「Status」\n %s"%data["result"]["user"]["blurb"]
                                except:aa += ""
                                noobcoder.sendImageWithURL(to, str(data["result"]["user"]["pic_url"]))
                                sendFooter(to, str(aa))
                            except:
                                sendFooter1(to, "ERROR")   
                        elif cmd.startswith("instaprofile "):
                            try:
                                username = removeCmd("instaprofile", text)
                                data = Instagram().InstagramProfile(username)["result"]
                                aa = "\n• Username : %s"%data["username"]
                                aa += "\n• Full Name : %s"%data["name"]
                                aa += "\n• Biography : %s"%data["bio"]
                                aa += "\n• Media Count : %s"%data["media"]
                                aa += "\n• Followers : %s"%data["followers"]
                                aa += "\n• Following : %s"%data["following"]
                                aa += "\n• Private : %s"%data["private"]
                                noobcoder.sendImageWithURL(to, str(data["pict"]))
                                sendFooter1(to, "  ｢Instagram Profile｣\n%s"%aa)
                            except:
                                sendFooter(to, "Error")
                        elif cmd.startswith("instapost "):
                            try:
                                aa = removeCmd("instapost", text).split(" ")
                                username = aa[0]
                                number = int(aa[1])
                                data = Instagram().InstagramPost(username, number-1)["result"]
                                aa = "\n• Username : %s"%data["username"]
                                aa += "\n• Caption : %s"%data["caption"]
                                aa += "\n• Like Count : %s"%data["jml_like"]
                                aa += "\n• Comment Count : %s"%data["jml_komen"]
                                aa += "\n• Link : %s"%data["link"]
                                bb = Instagram().InstagramDownload(str(data["link"]))
                                if bb["result"]["type"] == "picture":
                                    noobcoder.sendImageWithURL(to, str(bb["result"]["download"]))
                                if bb["result"]["type"] == "video":
                                    noobcoder.sendVideoWithURL(to, str(bb["result"]["download"]))
                                sendFooter1(to, "  ｢Instagram Post｣\n%s"%aa)
                            except:
                                sendFooter(to, "Error")
                        elif cmd.startswith("kbbi word "):
                            try:
                                word = removeCmd("kbbi word", text)
                                r = requests.get("https://api.dzin.jp/api/kbbi/word/?apikey=beta&word=%s"%word)
                                data = json.loads(r.text)
                                for anu in data["result"]:
                                    result = "  「KBBI」\n"
                                    result += "\n• Word : %s"%anu["word"]
                                    result += "\n• Mean : %s"%anu["mean"]
                                sendFooter(receiver, str(result))
                            except:
                                sendFooter1(receiver, "Tidak ada hasil untuk %s"%word)
                        elif cmd.startswith("kbbi page "):
                            try:
                                wtf = removeCmd("kbbi page", text)
                                cond = wtf.split("/")
                                page = int(cond[0])
                                r = requests.get("https://api.dzin.jp/api/kbbi/page/?apikey=beta&page=%i"%page)
                                data = json.loads(r.text)
                                if len(cond)  == 1:
                                    if data["result"] != []:
                                        num = 0
                                        result = "  「KBBI」\n"
                                        for anu in data["result"]:
                                            num += 1
                                            result += "\n%s. %s"%(num, anu["word"])
                                        sendFooter1(receiver, str(result))
                                    else:
                                        sendFooter(receiver, "Tidak ada halaman untuk %s"%page)
                                elif len(cond) == 2:
                                    num = int(cond[1])
                                    if num <= len(data["result"]):
                                        lmao = data["result"][num - 1]
                                        result = "  「KBBI」\n"
                                        result += "\n• Link : %s"%lmao["url"]
                                        sendFooter(receiver, str(result))
                            except:
                                sendFooter(to, "Error")
                        elif cmd.startswith("shio "):
                            shio = removeCmd("shio", text)
                            with requests.session() as web:
                                web.headers["user-agent"] = random.choice(settings["userAgent"])
                                try:
                                    r = web.get("http://api.dzin.jp/api/shio/?apikey=beta&shio={}".format(shio))
                                    data = r.text
                                    data = json.loads(data)
                                    result = "  「Shio」\n"
                                    for a in data["result"]:
                                        result += "Search : "+str(a["shio"])
                                        result += "\n\n"+str(a["description"])
                                    sendFooter(to, str(result))
                                except Exception as error:
                                    logError(error)
                        elif cmd.startswith("retro"):
                            try:
                                text_ = removeCmd("retro ", text)
                                txt = text_.split("-")        
                                txt = msg.text.split("-")                
                                bid = ["1","2","3","4","5"]
                                tid = ["1","2","3","4"]
                                btype = random.choice(bid)
                                ttype = random.choice(tid)
                                r= requests.get('https://api.ians.web.id/api/photofunia/arrow.php?text1='+txt[1]+'&text2='+txt[2]+'&btype='+btype+'&ttype='+ttype)
                                data = r.text
                                data = json.loads(data)
                                noobcoder.sendImageWithURL(to, data['image'])
                            except:
                                sendFooter(to, "Error")
                        elif cmd.startswith("photo"):
                            try:
                                text_ = removeCmd("photo ", text)
                                txt = text_.split("-")        
                                txt = msg.text.split("-")                
                                bid = ["1","2","3","4","5"]
                                tid = ["1","2","3","4"]
                                btype = random.choice(bid)
                                ttype = random.choice(tid)
                                r = requests.get('http://zicor.ooo/api/retrowave.php?text1='+txt[1]+'&text2='+txt[2]+'&text3='+txt[3]+'&btype='+btype+'&ttype='+ttype)
                                data = r.text
                                data = json.loads(data)
                                noobcoder.sendImageWithURL(to, data['image'])
                            except:
                                sendFooter(to, "Error")
#=====================================================================
                        if cmd.startswith('multikick '):
                            j = int(cmd.split(' ')[1])
                            a = [noobcoder.adityasplittext(cmd,'s').replace('{} '.format(j),'')]*j
                            if 'MENTION' in msg.contentMetadata.keys()!= None:
                                names = re.findall(r'@(\w+)', text)
                                mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                                mentionees = mention['MENTIONEES']
                                lists = []
                                for mention in mentionees:
                                    if mention["M"] not in lists:
                                        lists.append(mention["M"])
                                for ls in lists:
                                    try:
                                        group = noobcoder.getGroup(to)
                                        group.preventedJoinByTicket = True
                                        noobcoder.updateGroup(group)
                                        b = [entod_in(to, ls) for b in a];noobcoder.sendMention(to, '「 MultiKick 」\n@!has been Kicked out with {} amount of MultiKick♪'.format(j),'',[ls])
                                    except Exception as e:
                                        print(e)

                        if cmd.startswith('gcall '):
                            j = int(cmd.lower().split(' ')[1])
                            a = [noobcoder.adityasplittext(cmd,'s').replace(f'{j} ','')]*j
                            if 'MENTION' in msg.contentMetadata.keys() != None:
                                nama = []
                                key = eval(msg.contentMetadata['MENTION'])
                                key['MENTIONEES'][0]['M']
                                for x in key['MENTIONEES']:
                                    nama.append(x['M'])
                                b = [noobcoder.call.inviteIntoGroupCall(to, nama, mediaType=2) for b in a]
                                k = len(nama)//20
                                for i in range(k+1):
                                    if i == 0:aa = f' 「 Gcall 」\nSpam Call';no = i
                                    else:aa = f' 「 Gcall 」\nSpam Call';no = i*20
                                    ret = aa
                                    for b in nama[i*20 : (i+1)*20]:
                                        no += 1
                                        if no == len(nama):ret += f'\n - {no}. @!\nhas been spammed with amount {j} of gcall.'
                                        else:ret += f'\n - {no}. @!'
                                    noobcoder.sendMention(to, str(ret), '', nama[i*20 : (i+1)*20])
                            else:
                                try:nama = [a.mid for a in noobcoder.getCompactGroup(to).members]
                                except:nama = [a.mid for a in noobcoder.getRoom(to).contacts]
                                b = [noobcoder.call.inviteIntoGroupCall(to, nama, mediaType=2) for b in a]
                                noobcoder.sendMessage(to, f' 「 Gcall 」\n{noobcoder.getContact(msg._from).displayName} has been spammed with amount {j} of gcall to all members.')

                        if cmd.startswith('pc '):
                            try:
                                j = int(cmd.split(' ')[1])
                                a = [noobcoder.adityasplittext(cmd,'s').replace('{} '.format(j),'')]*j
                                if 'MENTION' in msg.contentMetadata.keys()!=None:
                                    key = eval(msg.contentMetadata["MENTION"])
                                    key1 = key["MENTIONEES"][0]["M"]
                                    nama = noobcoder.getContact(key1).displayName
                                    anu = noobcoder.getContact(key1)
                                    if len(cmd.split("\n")) >= 2:
                                        mid  = "{}".format(key1)
                                        text = "{}".format(str(cmd.replace(cmd.split("\n")[0]+"\n","")))
                                        icon = "http://dl.profile.line.naver.jp/{}".format(anu.pictureStatus)
                                        name = "{}".format(anu.displayName)
                                        b = [sendMessageCustom(key1, text, icon, name) for b in a];noobcoder.sendMention(to, '「 Spam 」\n@!has been spammed with {} amount of messages♪'.format(j),'',[key1])
                            except Exception as e:print(e)
                        elif cmd.startswith('spam 1 '):
                            try:
                                msg.text = noobcoder.mycmd(msg.text,wait)
                                j = int(msg.text.split(' ')[2])
                                a = [noobcoder.adityasplittext(msg.text,'s').replace('{} '.format(j),'')]*j
                                h = [noobcoder.sendMessage(to,b) for b in a];noobcoder.sendMessage(to, '「 Spam 」\nTarget has been spammed with {} amount of messages♪'.format(j))
                            except:pass
                        elif cmd.startswith('spam 2 '):
                            if msg.toType == 0:
                                msg.text = noobcoder.mycmd(msg.text,wait)
                                j = int(msg.text.split(' ')[2])
                                a = [noobcoder.adityasplittext(msg.text,'s').replace('{} '.format(j),'')]*j
                                b = [noobcoder.giftmessage(to) for b in a];noobcoder.sendMessage(to, '「 Spam 」\nTarget has been spammed with {} amount of messages♪'.format(j))
                            else:
                                j = int(msg.text.split(' ')[2])
                                a = [noobcoder.adityasplittext(msg.text,'s').replace('{} '.format(j),'')]*j
                                if 'MENTION' in msg.contentMetadata.keys()!=None:
                                    key = eval(msg.contentMetadata["MENTION"])
                                    key1 = key["MENTIONEES"][0]["M"]
                                    nama = [key1]
                                    b = [noobcoder.giftmessage(key1) for b in a];noobcoder.sendMention(to, '「 Spam 」\n@!has been spammed with {} amount of gift♪'.format(j),'',[key1])
                        elif cmd.startswith('spam 3 '):
                            msg.text = noobcoder.mycmd(msg.text,wait)
                            j = int(msg.text.split(' ')[2])
                            a = [noobcoder.adityasplittext(msg.text,'s').replace('{} '.format(j),'')]*j
                            try:group = noobcoder.getGroup(to);nama = [contact.mid for contact in group.members];b = [noobcoder.sendContact(to,random.choice(nama)) for b in a]
                            except:nama = [to,to];b = [noobcoder.sendContact(to,random.choice(nama)) for b in a]
                        elif cmd.startswith('spam 4 '):
                            j = int(msg.text.split(' ')[2])
                            lontong = cmd
                            msg.text = noobcoder.mycmd(msg.text,wait)
                            a = settings['keyCommand'].title()
                            if settings['setKey'] == False:a = ''
                            anu = [noobcoder.adityasplittext(msg.text,'s').replace('{} '.format(j),'')]*j
                            if 'MENTION' in msg.contentMetadata.keys()!=None:
                                key = eval(msg.contentMetadata["MENTION"])
                                key1 = key["MENTIONEES"][0]["M"]
                                nama = [key1]
                                if cmd.startswith(a+" "):gss = 7 + len(a)+1
                                else:gss = 7 + len(a)
                                msg.contentMetadata = {'AGENT_LINK': 'line://ti/p/~{}'.format(noobcoder.getProfile().userid),'AGENT_ICON': "http://dl.profile.line-cdn.net/" + noobcoder.getProfile().picturePath,'AGENT_NAME': ' 「 SPAM MENTION 」','MENTION': str('{"MENTIONEES":' + json.dumps([{'S':str(int(key['S'])-gss-len(msg.text.split(' ')[2])-1+13), 'E':str(int(key['E'])-gss-len(msg.text.split(' ')[2])-1+13), 'M':key['M']} for key in eval(msg.contentMetadata["MENTION"])["MENTIONEES"]]) + '}')}
                                msg.text = lontong[gss+1+len(msg.text.split(' ')[2]):].replace(lontong[gss+1+len(msg.text.split(' ')[2]):],' 「 Mention 」\n{}'.format(lontong[gss+1+len(msg.text.split(' ')[2]):]))
                                b = [noobcoder.sendMessages(msg) for b in anu]
                        elif cmd.startswith("say "):
                            text_ = removeCmd("say", text)
                            cond = text_.split(" ")
                            bahasa = cond[0]
                            say = text_.replace(bahasa + " ","")
                            if bahasa in ["af", "sq", "ar", "hy", "az", "eu", "be", "bn", "bs", "bg", "ca", "ny", "zh", "zh", "hr", "cs", "da", "nl", "en", "eo", "et", "tl", "fi", "fr", "gl", "ka", "de", "el", "gu", "ht", "ha", "iw", "hi", "hu", "is", "ig", "id", "ga", "it", "ja", "jw", "kn", "kk", "km", "ko", "lo", "la", "lv", "lt", "mk", "mg", "ms", "ml", "mt", "mi", "mr", "mn", "my", "ne", "no", "fa", "pl", "pt", "pa", "ro", "ru", "sr", "st", "si", "sk", "sl", "so", "es", "su", "sw", "sv", "tg", "ta", "te", "th", "tr", "uk", "ur", "uz", "vi", "cy", "yi", "yo", "zu"]:
                                tts = gTTS(text=say,lang=bahasa)
                                tts.save("hasil.mp3")
                                noobcoder.sendAudio(msg.to,"hasil.mp3")
                        elif cmd.startswith("creatememe "):
                            text_ = removeCmd("creatememe", text)
                            cond = text_.split("|")
                            list_template = ["10guy","afraid","blb","both","buzz","chosen","doge","elf","ermg","fa","fetch","fry","fwp","ggg","icanhas","interesting","iw","keanu","live","ll","mordor","morpheus","officiespace","oprah","philosoraptor","remembers","sb","ss","success","toohigh","wonka","xy","yallgot","yuno"]
                            if cond[0] is not None and cond[1] is not None:
                                up = str(cond[0])
                                down = str(cond[1])
                                if len(cond) > 2:
                                    if cond[2] is not None and cond[2] in list_template:
                                        template = str(cond[2])
                                    elif cond[2] is not None and cond[2] not in list_template:
                                        template = None
                                        noobcoder.sendMessage(to,"Template tidak valid")
                                else:
                                    template = random.choice(list_template)
                                if template is not None:
                                    noobcoder.sendImageWithURL(to,"https://memegen.link/{}/{}/{}.jpg".format(template,up,down))
                            else:
                                noobcoder.sendMessage(to,"Error")
                        elif cmd == "template memegen":
                            f = open('khie/memeGen.txt','r')
                            lines = f.readlines()
                            panjang = len(lines)
                            lists = ""
                            for a in lines:
                                lists += str(a)
                            noobcoder.sendMessage(to,"Template List :\n%s" %(lists))
                        elif cmd.startswith("wordbanadd "):
                            wban = cmd.split()[1:]
                            wban = " ".join(wban)
                            wbanlist.append(wban)
                            noobcoder.sendMessage(to,"%s is now blacklisted."%wban)
                        elif cmd.startswith("wordbandel "):
                            wunban = cmd.split()[1:]
                            wunban = " ".join(wunban)
                            if wunban in wbanlist:
                                wbanlist.remove(wunban)
                                noobcoder.sendMessage(to,"%s is no longer blacklisted."%wunban)
                            else:
                                noobcoder.sendMessage(to,"%s is not blacklisted."%wunban)
                        elif cmd == 'list wordban':
                            tst = "「 WordBan List 」\n"
                            if len(wbanlist) > 0:
                                for word in wbanlist:
                                    tst += "• %s"%word
                                noobcoder.sendMessage(msg.to,tst)
                            else:
                                noobcoder.generateReplyMessage(msg.id)
                                noobcoder.sendReplyMessage(msg.id, to,"Wbanlist is empty!")
                        elif cmd == "@reject all":
                          gids = noobcoder.getGroupIdsInvited()
                          xyzs = []
                          for x in gids:xyzs.append(x)
                          for x in gids:
                            noobcoder.acceptGroupInvitation(x)
                          for x in xyzs:
                            noobcoder.leaveGroup(x)
                          noobcoder.sendMessage(to, "Success reject %i invitation." % len(xyzs))
                        elif cmd == "purge":
                            if msg.toType == 2:
                                group = noobcoder.getGroup(to)
                                nama = [contact.mid for contact in group.members]
                                lists = []
                                for tag in wait["blacklist"]:
                                    lists+=filter(lambda str: str == tag, nama)
                                if lists == []:
                                    noobcoder.sendMessage(to, "Blacklist not detected!")
                                    return
                                for jj in lists:
                                    noobcoder.kickoutFromGroup(to,[jj])
                                noobcoder.sendMessage(msg.to,"Blacklist has been purge")
                        elif cmd == "newticket":
                            noobcoder.reissueUserTicket()
                            userid = "https://line.me/ti/p/~" + noobcoder.profile.userid
                            noobcoder.sendMessage(to, "New Ticket :\n"+str(userid))
                        elif cmd == "conblock":
                            if msg._from in noobcoderMID:
                                blockedlist = noobcoder.getBlockedContactIds()
                                if blockedlist == []:
                                    noobcoder.sendMessage(to, "Empty !")
                                else:
                                    for kontak in blockedlist:
                                        noobcoder.sendMessage(to, text=None, contentMetadata={'mid': kontak}, contentType=13)                                        
                        elif cmd.startswith("reject "):
                            number = removeCmd("reject", text)
                            groups = noobcoder.getGroupIdsInvited()
                            try:
                                group = groups[int(number)-1]
                                G = noobcoder.getGroup(group)
                                try:
                                    noobcoder.rejectGroupInvitation(G.id)
                                except:
                                    noobcoder.rejectGroupInvitation(G.id)
                                noobcoder.generateReplyMessage(msg.id)
                                noobcoder.sendReplyMessage(msg.id, to, "「 Reject 」\n\nGroup : " + G.name)
                            except Exception as error:
                                noobcoder.sendMessage(to, str(error))
                        elif cmd.startswith("flood ") and sender == noobcoderMID:
                            dzin = removeCmd("flood", text)
                            line = dzin.split("|")
                            count = int(line[1])
                            text1 = removeCmd("flood"+str(line[0])+"|"+str(count)+"|", text)
                            text2 = count * (text1+"\n")
                            if line[0] == "on":
                                if count <= 1000:
                                    for a in range(count):
                                        data = {
                                                "type": "flex",
                                                "altText": "KhieWasHere",
                                                "contents": {
  "styles": {
    "body": {
      "backgroundColor": "{}".format(setbot["background"])
    },
    "footer": {
      "backgroundColor": "{}".format(setbot["separator"])
    }
  },
  "type": "bubble",
  "body": {
    "contents": [
      {
        "contents": [
          {
            "url": "https://obs.line-scdn.net/{}".format(noobcoder.getContact(noobcoderMID).pictureStatus),
            "type": "image"
          },
          {
            "type": "separator",
            "color": "{}".format(setbot["separator"])
          },
          {
            "url": str(noobcoder.getProfileCoverURL(sender)),
            "type": "image"
          }
        ],
        "type": "box",
        "spacing": "md",
        "layout": "horizontal"
      },
      {
        "type": "separator",
        "color": "{}".format(setbot["separator"])
      },
      {
        "contents": [
          {
            "text": str(text1),
            "size": "md",
            "align": "center",
            "color": "{}".format(setbot["text"]),
            "wrap": True,
            "weight": "bold",
            "type": "text"
          }
        ],
        "type": "box",
        "layout": "vertical"
      }
    ],
    "type": "box",
    "spacing": "md",
    "layout": "vertical"
  }
}
}
                                        sendTemplate(to, data)
                                else:
                                    noobcoder.sendMessage(to, "Max 1000.")
                            if line[0] == "off":
                                if count <= 1000:
                                    noobcoder.sendMessage(to, str(text2))
                                else:
                                    noobcoder.sendMessage(to, "Max 1000.")
                        elif cmd == "settings":
                            txt = "</> Status :"
                            txt += "\n"
                            if settings["autoAdd"] == True:txt += "\nAutoadd: ON♪"
                            else:txt += "\nAutoadd: OFF♪"
                            if blocked["autoBlock"] == True:txt += "\nAutoBlock: ON♪"
                            else:txt += "\nAutoBlock: OFF♪"
                            if settings["autoJoin"] == True:txt += "\nAutoJoin: ON♪"
                            else:txt += "\nAutoJoin: OFF♪"
                            #if to in wait["GROUP"]["WM"]["AP"]:txt += "\nWelcome: ON♪"
                            #else:txt += "\nWelcome: OFF♪"
                            #if to in wait["GROUP"]["AR"]["AP"]:txt += "\nAutoRespon: ON♪"
                            #else:txt += "\nAutoRespon: OFF♪"
                            #if to in wait["GROUP"]["LM"]["AP"]:txt += "\nLeave: ON♪
                            #else:txt += "\nLeave: OFF♪"
                            if wmin["wMessage"] == True:txt += "\nWelcomemsg: ON♪"
                            else:txt += "\nWelcomemsg: OFF♪"
                            if lvin["lMessage"] == True:txt += "\nLeavemsg: ON♪"
                            else:txt += "\nLeavemsg: OFF♪"
                            if settings["notag"] == True:txt += "\nAntitag: ON♪"
                            else:txt += "\nAntitag: OFF♪"
                            if temptag["stealtag"] == True:txt += "\nRespontag: ON♪"
                            else:txt += "\nRespontag: OFF♪"
                            if sets["tagsticker"] == True:txt += "\nResponsticker: ON♪"
                            else:txt += "\nResponsticker: OFF♪"
                            if mcroom["leaveMC"] == True:txt += "\nMchat: ON♪"
                            else:txt += "\nMchat: OFF♪"
                            if settings["autoReply"] == True:txt += "\nSleepMode: ON♪"
                            else:txt += "\nSleepMode: OFF♪"
                            if komen["komenan"] == True:txt += "\nLikePost: ON♪"
                            else:txt += "\nLikePost: OFF♪"
                            if settings["unsendMessage"] == True:txt += "\nResendchat: ON♪"
                            else:txt += "\nResendchat: OFF♪"
                            #if to in wait["notificationCallPrank"]:txt += "\nPrankCall: ON♪"
                            #else:txt += "\nPrankCall: OFF♪"
                            if to in wait["notificationCall"]:txt += "\nGroupCall: ON♪"
                            else:txt += "\nGroupCall: OFF♪"
                            txt += "\n\n</> Command :\n"
                            txt += "\nAutoAdd"
                            txt += "\nAutoRead"
                            txt += "\nAutoJoin"
                           # txt += "\nWelcomemsg"
                            txt += "\nLeavemsg"
                           # txt += "\nAutoRespon"
                            txt += "\nWelcomemsg On/Off"
                            txt += "\nWelcomemsg set [text]"
                            txt += "\nLeavemsg On/Off"
                            txt += "\nLeavemsg set [text]"
                            txt += "\nReader On/Off"
                            txt += "\nReader msg set [text]"
                            txt += "\nSleepMode On/Off"
                            txt += "\nSleepMode msg set [text]"
                            txt += "\nLike On/Off"
                            txt += "\nCommentpost: [text]"
                            txt += "\nMc On/Off"
                            txt += "\nAntitag On/Off"
                            txt += "\nSticker On/Off"
                            txt += "\nAutoblock msg set [text]"
                            txt += "\nAutoblock On/Off"
                            txt += "\nResponsticker On/Off"
                            txt += "\nAdd responsticker"
                            txt += "\nRespon On/Off"
                            txt += "\nRespon msg set [text]"
                            txt += "\nResendchat On/Off"
                            #txt += "\nPrankcall On/Off"
                            txt += "\nGroupcall On/Off"
                            #txt += "\nVcg set[enter][text]"
                            #txt += "\nFcg set[enter][text]"
                            mosing(to, str(txt))
                        elif cmd == "profile":
                            ret = "Type: Profile\n\n"
                            ret += "  • Changedp\n"
                            ret += "  • Change cover\n"
                            ret += "  • Changedp video\n"
                            ret += "  • Changevideourl <link>\n"
                            ret += "  • Updatename <name>\n"
                            ret += "  • Updatestatus <name>"
                            mosing(to, str(ret))
                        elif cmd == "banning":
                            ret = "Type: Banning\n\n"
                            ret += "  • Tban <@>\n"
                            ret += "  • Tunban <@>\n"
                            ret += "  • Tbanlist \n"
                            ret += "  • Notag on/off\n"
                            ret += "  • Status notag\n"
                            ret += "  • Remove notag\n"
                            ret += "  • Blacklist\n"
                            ret += "  • Purge\n"
                            ret += "  • Conban\n"
                            ret += "  • Clearban"
                            mosing(to, str(ret))
                        elif cmd == "utility":
                            ret = "Type: Utility\n\n"
                            ret += "  • Autoread\n"
                            ret += "  • Autorespon\n"
                            ret += "  • Autojoin\n"
                            ret += "  • Leavemsg\n"
                            ret += "  • Welcomemsg\n"
                            ret += "  • Autoadd"
                            mosing(to, str(ret))
                        elif cmd == "kick":
                            ret = "Type: Kick\n\n"
                            ret += "  • Multikick <num><@>\n"
                            ret += "  • Kick <@>\n"
                            ret += "  • Slain <@>\n"
                            ret += "  • Ass <@>\n"
                            ret += "  • Ulti <@>\n"
                            ret += "  • Nk <@>\n"
                            ret += "  • Skill <name>\n"
                            ret += "  • Kickass <name>\n"
                            ret += "  • Cleanse\n"
                            ret += "  • Bypass\n"
                            ret += " •  Reinv <@>"
                            mosing(to, str(ret))
                        elif cmd == "steal":
                            ret = "Type: Stealing\n\n"
                            ret += "  • Rename <@> | <name>\n"
                            ret += "  • Pict <@>\n"
                            ret += "  • Cover <@>\n"
                            ret += "  • Profile <@>\n"
                            ret += "  • Video <@>\n"
                            ret += "  • Name <@>\n"
                            ret += "  • Bio <@>\n"
                            ret += "  • Contact <@>\n"
                            ret += "  • Midclone <mid>\n"
                            ret += "  • Cloneprofile <@>\n"
                            ret += "  • Restoreprofile\n"
                            ret += "  • Backupprofile\n"
                            ret += "  • Mid <@>\n"
                            ret += "  • Whois <name>\n"
                            ret += "  • Status <name>"
                            mosing(to, str(ret))
                        elif cmd == "spam":
                            ret = "Type: Spaming\n\n"
                            ret += "Spam Text\n"
                            ret += "  • Spam 1 [1][enter|text]\n"
                            ret += "Spam Gift\n"
                            ret += "  • Spam 2 [1][@|]\n"
                            ret += "Spam Contact\n"
                            ret += "  • Spam 3 [1]<@>\n"
                            ret += "Spam Mention\n"
                            ret += "  • Spam 4 [1]<@>\n"
                            ret += "Spam Pm\n"
                            ret += "  • Pc [1] <@>[enter|text]"
                            mosing(to, str(ret))
                        elif cmd == "translate":
                            ret = "Type: Translator\n\n"
                            ret += "  • Indo: <text>\n"
                            ret += "  • Eng: <text>\n"
                            ret += "  • Japan: <text>\n"
                            ret += "  • Korea: <text>\n"
                            ret += "  • Thai: <text>\n"                            
                            ret += "  • Arab: <text>\n"
                            ret += "  • Malay: <text>\n"
                            ret += "  • French: <text>\n"
                            ret += "  • Italy: <text>\n"
                            ret += "  • Czech: <text>\n"
                            ret += "  • India: <text>\n"
                            ret += "  • Spain: <text>\n"
                            ret += "  • Turky: <text>\n"
                            ret += "  • Russia: <text>"
                            mosing(to, str(ret))
                        elif cmd == "images":
                            ret = "Type: Images\n\n"
      #                      ret += "  • Goimage <text>\n"
                         #   ret += "  • Wallpaper <text>\n"
                            ret += "  • Image <text>\n"
         #                   ret += "  • Food <text>\n"
         #                   ret += "  • Drawwindow <text>\n"
          #                  ret += "  • Drawlight <text>\n"
      #                      ret += "  • Drawsoupletters <text>\n"
      #                      ret += "  • Drawcookies <text>\n"
        #                    ret += "  • Retro-text-text-text\n"
           #                 ret += "  • Fmylife\n"
         #                   ret += "  • Azab <name>\n"
                            ret += "  • Cosplay <name>\n"
                            ret += "  • Viloid <name>\n"
                            ret += "  • Imagetext <query>\n"
                            ret += "  • Danbooru [page]\n"
                            ret += "  • Nhentai page [number/number]"
                            mosing(to, str(ret))
                        elif cmd == "feature":
                            ret = "Type: Feature\n\n"
                            ret += "  • Music <query>\n"
                            ret += "  • Themes <query>\n"
                            ret += "  • Stickers <query>\n"
                            ret += "  • Devianart <text>\n"
                            ret += "  • Brainly <query>\n"
                            ret += "  • Praytime [city]\n"
                            ret += "  • Timezone [city]\n"
                            ret += "  • Astronotnow\n"
                            ret += "  • Sifatnama <name>\n"
                            ret += "  • Urban <query>\n"
                            ret += "  • Kaskus <query>\n"
                            ret += "  • Zalgo <name>\n"
                            ret += "  • Dick <name>\n"
                            ret += "  • Tits <name>\n"
                            ret += "  • Anus <name>\n"
                            ret += "  • Vagina <name>\n"
                            ret += "  • Porns <query>\n"
                            ret += "  • Xxx <query>\n"
                            ret += "  • Checkip [ip]\n"
                            ret += "  • Gif <query>"
                            mosing(to, str(ret))
                        elif cmd == "social":
                            ret = "Type: Social\n\n"
      #                      ret += "  • Kaskus <query>\n"
                            ret += "  • Webtoon\n"
     #                       ret += "  • Google <text>\n"
                            ret += "  • Wikipedia <text>\n"
                            ret += "  • Quran\n"
                            ret += "  • Topnews\n"
       #                     ret += "  • Tvschedule\n"
                            ret += "  • Smuleprofile <username>\n"
                            ret += "  • Smulemp4 <link>\n"
                            ret += "  • Smulemp3 <link>\n"
                            ret += "  • Smulefile <link>\n"
                            ret += "  • Youtubesearch <query>\n"
                            ret += "  • Youtubemp3 <link>\n"
                            ret += "  • Youtubemp4 <link>\n"
                            ret += "  • Fileytmp3 <link>\n"
                            ret += "  • Fileytmp4 <link>\n"
                            ret += "  • Instaprofile <username>\n"
                            ret += "  • Instapost [username page]\n"
      #                      ret += "  • Instagram <username>\n"
  #                          ret += "  • Searchapp <query>\n"
                            ret += "  • Kbbi word <text>\n"
                            ret += "  • Kbbi page <num>\n"
                            #ret += "  • Joox <query>"
                            mosing(to, str(ret))
                        elif cmd == "group":
                            ret = "Type: Group\n\n"
                            ret += "  • Favoritelist\n"
                            ret += "  • Blocklist\n"
                           # ret += "  • Square\n"
                            ret += "  • Lurk\n"
                            ret += "  • Find <@>\n"
                            ret += "  • Lastseen <@>\n"
                            ret += "  • Rejectall\n"
                            ret += "  • Cancelall\n"
                            ret += "  • Gcall <num><@>\n"
                            ret += "  • Gcall <num>\n"
                            ret += "  • Groups\n"
                            ret += "  • Openqr\n"
                            ret += "  • Closeqr\n"
                            ret += "  • Invite\n"
                            ret += "  • Inviteid [Idline]\n  • Invite <@>\n"
                            ret += "  • Countdown <num>\n"
                            ret += "  • Countforward <num>\n"
                            ret += "  • Creategroup <name>\n"
                            ret += "  • Changegn <name>\n"
                            ret += "  • Get note\n"
                            ret += "  • Get note <num>\n"
                            ret += "  • Mentionnote\n"
                            ret += "  • Create note <text>\n"
                            ret += "  • Get album\n"
                            ret += "  • Get album [1] [<|>|-|num]\n"
                            ret += "  • Changedp group"
                            mosing(to, str(ret))
                        elif cmd == "timeline":
                            ret = "Type: Timeline\n\n"
                            ret += "  • Updatepost <text>\n"
                            ret += "  • Update post [1][time]<text>\n"
                            ret += "  • Timeline <@>\n"
                            ret += "  • Likepost <@>\n"
                            ret += "  • Share allpost <num><@>"
                            mosing(to, str(ret))
                        elif cmd == "github":
                            ret = "Type: Github\n\n"
                            ret += "  • Githubprofile <username>\n"
                            ret += "  • Githubfollowing <username>\n"
                            ret += "  • Githubfollowers <username>\n"
                            ret += "  • Githubrepo <username>\n"
                            ret += "  • Githuzip [name|name]"
                            mosing(to, str(ret))
                        elif cmd == "mention":
                            ret = "Type: Mention\n\n"
                            ret += "  • Mention [num|>|<|1-5]\n"
                            ret += "  • Mentionname [A-z]\n"
                            ret += "  • Mention [A-z]\n"
                            ret += "  • Mention [2|@]\n"
                            ret += "  • Mentionall\n"
                            ret += "  • Check mention"
                            mosing(to, str(ret))
                        elif cmd == "friend":
                            ret = "Type: Friend\n\n"
                            ret += "  • Friendlist\n"
                            ret += "  • Friend info <num>\n"
                            ret += "  • Clearfriend\n"
                            ret += "  • Delete <pm>\n"
                            ret += "  • Delfriend <@>\n"
                            ret += "  • Del friend <num>\n"
                            ret += "  • Addfriend <@>"
                            mosing(to, str(ret))
                        elif cmd == "protect":
                            ret = "Type: Protection\n\n"
                            ret += "  • Protectionall On/Off\n"
                            ret += "  • Namelock On/Off\n"
                            ret += "  • Denyinvite On/Off\n"
                            ret += "  • Promember On/Off\n"
                            ret += "  • Blockqr On/Off\n"
                            ret += "  • Status Namelock\n"
                            ret += "  • Status Denyinvite\n"
                            ret += "  • Status Promember\n"
                            ret += "  • Status Blockqr\n"
                            ret += "  • Remove Namelock\n"
                            ret += "  • Remove Denyinvite\n"
                            ret += "  • Remove Promember\n"
                            ret += "  • Remove Blockqr"
                            mosing(to, str(ret))
                        elif cmd == "wordban":
                            ret = "Type: Wordban\n\n"
                            ret += "  • Wordbanadd <text>\n"
                            ret += "  • Wordbandel <text>\n"
                            ret += "  • List wordban"
                            mosing(to, str(ret))
                        elif cmd == "quran":
                            ret = "Type: Quran\n\n"
                            ret += "Daftar Surah\n"
                            ret += "  • Quranlist\n"
                            ret += "Get Ayat Qur'an\n"
                            ret += "  • Qur'an [numsurah]\n"
                            ret += "  • Qur'an [numsurah] [1|<|>|-]"
                            mosing(to, str(ret))
                        elif cmd == "bcast":
                            ret = "Type: Broadcast\n\n"
                            ret += "  • Gbroadcast <text>\n"
                            ret += "  • Fbroadcast <text>\n"
                            ret += "  • Allbroadcast <text>\n"
                            ret += "  • Flexgbc <text>\n"
                            ret += "  • Flexfbc <text>\n"
                            ret += "  • Groupcastvoice <text>\n"
                            ret += "  • Friendcastvoice <text>"
                            mosing(to, str(ret))
                        elif cmd == "webtozon":
                            ret = "Drama :\n  • Webtoon drama\n  • Webtoon drama <num>\n"
                            ret += "Fantasi :\n  • Webtoon fantasi\n  • Webtoon fantasi <num>\n"
                            ret += "Comedy :\n  • Webtoon comedy\n  • Webtoon comedy <num>\n"
                            ret += "Slice Of Life :\n  • Webtoon sol\n  • Webtoon sol <num>\n"
                            ret += "Romance :\n  • Webtoon romance\n  • Webtoon romancethriller <num>\n"
                            ret += "Thriller :\n  • Webtoon thriller\n  • Webtoon thriller <num>\n"
                            ret += "Horror :\n  • Webtoon horror\n  • Webtoon horror <num>"
                            mosing(to, str(ret))
                        elif cmd == "list":
                            ret ="Type: List\n\n  • Mysticker\n  • Add sticker 「name」\n  • Del sticker 「name」\n  • List sticker\n"
                            ret +="  • Add pict 「name」\n  • Del pict 「name」\n  • Changepict 「name」\n  • List pict\n  • Sendpict 「numb」 「name」\n"
                            ret +="  • Add sflex「name」\n  • Del  sflex「name」\n  • List sflex\n"
                            ret +="  • Addaudio「name」\n  • Delaudio「name」\n  • Audiolist\n"
                            ret +="  • Addtext#「name/text 」\n  • Deltext「name」\n  • List text\n"
                            ret +="  • Addcontact「name 」\n  • Delcontact「name」\n  • List contact\n  • Template color"
                            mosing(to, str(ret))
                        elif cmd == "textspeech":
                            ret = "How to use ?\n"
                            ret += "Use command :\n  • Say *lang* *text*\n"
                            ret += "Example :\n"
                            ret += "  • Say id khie cool\n"
                            ret += "How to find language?\n"
                            ret += "Use command :\n  • Say language"
                            mosing(to, str(ret))
                        elif cmd == "memegen":
                            ret = "How to use ?\n"
                            ret += "Use command :\n  • Creatememe *text*|*text*|*template*\n"
                            ret += "Example :\n"
                            ret += "  • Creatememe khie|ganteng|buzz\n"
                            ret += "How to find template?\n"
                            ret += "Use command :\n  • Template memegen"
                            mosing(to, str(ret))
                        elif cmd == "self":
                            ret = "Type: My Self\n\n"
                            ret += "  • Mypicture\n"
                            ret += "  • Mycover\n"
                            ret += "  • Mycontact\n"
                            ret += "  • Mymid\n"
                            ret += "  • Myprofile\n"
                            ret += "  • Myvideo"
                            mosing(to, str(ret))
                        elif cmd == settings['jskick1']:
                          xyz = noobcoder.getGroup(to)
                          mem = [c.mid for c in xyz.members]
                          targets = []
                          for x in mem:
                            if x not in ["u8c31fa0e60d1eee2558ee7c634614e67","u09c11f239846b06539d08608099f7733",noobcoder.profile.mid]:targets.append(x)
                          if targets:
                            imkhie = 'simple.js gid={} token={} app={}'.format(to, noobcoder.authToken, "IOSIPAD\t11.2.5\tiPhone X\t11.2.5")
                            for target in targets:
                              imkhie += ' uid={}'.format(target)
                            success = execute_js(imkhie)
                            if success:noobcoder.sendMessage(to, "Success kick %i members." % len(targets))
                            else:noobcoder.sendMessage(to, "Failed kick %i members." % len(targets))
                          else:noobcoder.sendMessage(to, "Target not found.")
                        elif cmd == settings['jskick']:
                          xyz = noobcoder.getGroup(to)
                          if xyz.invitee == None:pends = []
                          else:pends = [c.mid for c in xyz.invitee]
                          targp = []
                          for x in pends:
                            if x not in ["u8c31fa0e60d1eee2558ee7c634614e67","u09c11f239846b06539d08608099f7733",noobcoder.profile.mid]:targp.append(x)
                          mems = [c.mid for c in xyz.members]
                          targk = []
                          for x in mems:
                            if x not in ["u8c31fa0e60d1eee2558ee7c634614e67","u09c11f239846b06539d08608099f7733",noobcoder.profile.mid]:targk.append(x)
                          imkhie = 'dual.js gid={} token={}'.format(to, noobcoder.authToken)
                          for x in targp:imkhie += ' uid={}'.format(x)
                          for x in targk:imkhie += ' uik={}'.format(x)
                          execute_js(imkhie)
                        elif cmd.startswith("spaminv "):
                          sep = text.split("spaminv ")[1]
                          name = str(sep.split("|")[0])
                          targets = str(sep.split("|")[1])
                          imkhie = "spam.js name={} token={}".format(name, noobcoder.authToken)
                          if len(targets.split(",")) > 0:
                            targets = targets.split(",")
                            for target in targets:
                              noobcoder.findAndAddContactsByMid(target)
                              imkhie += " uid={}".format(target)
                          else:
                            imkhie += " uid={}".format(targets)
                          success = execute_js(imkhie)
                          if success:noobcoder.sendMessage(to,"Done")
                          else:noobcoder.sendMessage(to,"Error")
                        elif cmd.startswith("Exec"):
                            if msg._from in myAdmin:
                                try:
                                    sep = text.split("\n")
                                    txt = text.replace(sep[0] + "\n","")
                                    exec(txt)
                                except:
                                    pass
                        if(cmd.startswith('youtube video ') or cmd.startswith('youtube audio ') or cmd.startswith('youtube info ')):
                            try:
                                texts = noobcoder.adityasplittext(cmd,'s').split("|")
                                print(texts)
                                a = noobcoder.adityarequestweb("https://www.googleapis.com/youtube/v3/search?part=snippet&maxResults=25&q="+texts[0]+"&type=video&key=AIzaSyAF-_5PLCt8DwhYc7LBskesUnsm1gFHSP8")
                                if len(texts) == 1:dfghj = noobcoder.adityasplittext(msg.text,'s').replace('https://youtu.be/','').replace('youtube video ','').replace('youtube audio ','').replace('youtube info ','').replace('https://www.youtube.com/watch?v=','');meta = youtube_dl.YoutubeDL({}).extract_info(dfghj, download=False)
                                if len(texts) >= 2:dfghj = a["items"][int(texts[1])-1]["id"]['videoId'];dfghj = 'https://www.youtube.com/watch?v='+a["items"][int(texts[1])-1]["id"]['videoId'];meta = youtube_dl.YoutubeDL({}).extract_info(dfghj, download=False)
                                if cmd.startswith('youtube info '):
                                    if(len(texts) == 1):dfghj = noobcoder.adityasplittext(msg.text,'s').replace('youtu.be/','youtube.com/watch?v=').replace('info ','');meta = youtube_dl.YoutubeDL({}).extract_info(dfghj, download=False)
                                    if(len(texts) == 2):dfghj = 'https://www.youtube.com/watch?v='+a["items"][int(texts[1])-1]["id"]['videoId'];meta = youtube_dl.YoutubeDL({}).extract_info(dfghj, download=False)
                                    if meta['description'] == '':hjk = ''
                                    else:hjk = '\nDescription:\n{}'.format(meta['description'])
                                    t = ' 「 Youtube 」\nTitle: {}{}\n\nLike: {}  Dislike: {}\nViewers: {}'.format(meta['title'],hjk,humanize.intcomma(meta['like_count']),humanize.intcomma(meta['dislike_count']),humanize.intcomma(meta['view_count']))
                                    lol(to,t)
                                    s = meta['thumbnail']
                                    anunanu(to,s,liffnya)
                                if(cmd.startswith("youtube video ") or cmd.startswith("youtube audio ")):
                                    kk = random.randint(0,999)
                                    if(len(texts) == 1):dfghj = noobcoder.adityasplittext(msg.text,'s').replace('youtu.be/','youtube.com/watch?v=').replace('audio ','').replace('video ','');meta = youtube_dl.YoutubeDL({}).extract_info(dfghj, download=False)
                                    if len(texts) == 2:dfghj = 'https://www.youtube.com/watch?v='+a["items"][int(texts[1])-1]["id"]['videoId'];print(dfghj);meta = youtube_dl.YoutubeDL({}).extract_info(dfghj, download=False)
                                    hhhh = ' 「 Youtube 」\nJudul: {}\nDuration: {}\nEx: {}\nStatus: Waiting... For Upload'.format(meta['title'],meta['duration'],'1270*720')
                                    lol(to,hhhh)
                                    links = cytmp4(dfghj);links = 'https://'+google_url_shorten(links)
                                    linkss = cytmp3(dfghj);linkss = 'https://'+google_url_shorten(linkss)
                                    sendCarousel(to,YoutubeTempat(liffnya,to,meta,dfghj,links,linkss))
                                    if(cmd.startswith("youtube video ")):sendCarousel(to,{"messages": [{"type": "video","altText": "YouTube","originalContentUrl": links,"previewImageUrl": meta['thumbnail']}]})
                                    if(cmd.startswith("youtube audio ")):sendCarousel(to,{"messages": [{"type": "audio","altText": "YouTube","originalContentUrl": linkss,"duration": meta['duration']*1000}]})
                            except Exception as e:noobcoder.sendMessage(to, str(e))
                        if cmd.startswith("goimage "):
                            query = cmd.replace("goimage ","")
                            cond = query.split("|")
                            search = str(cond[0])
                            result = requests.get("https://xeonwz.herokuapp.com/images/google.api?q={}".format(str(search)))
                            data = result.text
                            data = json.loads(data)
                            if data["content"] != []:
                                ret_ = []
                                for i in data["content"]:
                                    if '.gif' in i:
                                        links = 'line://app/1606644641-DAwvRm5p?type=images&imgs='
                                    else:
                                        links = 'line://app/1606644641-DAwvRm5p?type=image&img='
                                    url = i
                                    ret_.append({"type": "bubble","header": {"type": "box","layout": "vertical","contents": [{"type": "text","text": "Google Image","weight": "bold"}]},"hero": {"type": "image","url": "https://app-1536548990.000webhostapp.com/apis.php?images="+url,"size": "full","aspectRatio": "2:1","aspectMode": "fit"},"body": {"type": "box","layout": "vertical","contents": [{"type": "text","text": "TAP ON THE BUTTON","weight": "bold","size":"md","margin":"md"},{"type":"separator","color":"#000000"}]},"footer": {"type": "box","layout": "vertical","contents": [{"type": "box","layout": "horizontal","contents": [{"type": "button","flex": 2,"style": "primary","color": "#000000","height": "sm","action": {"type": "uri","label": "LINK","uri": "{}{}".format(liffnya['ttt'],url)}}, {"flex": 3,"type": "button","margin": "sm","style": "primary","color": "#000000","height": "sm","action": {"type": "uri","label": "SEND IMAGE","uri": links+url}}]}]}})
                                k = len(ret_)//10
                                for aa in range(k+1):
                                    data = {"messages": [{"type": "flex","altText": "Google Image","contents": {"type": "carousel","contents": ret_[aa*10 : (aa+1)*10]}}]}
                                    sendCarousel(to,data)
                        if cmd.startswith('joox ') or cmd.startswith('lyric joox '):
                            anu = str(cmd.replace('joox ',''))
                            if cmd.startswith('joox '):
                                a = requests.get('http://api-jooxtt.sanook.com/web-fcgi-bin/web_search?country=id&lang=en&search_input={}&sin=10&ein=60'.format(str(cmd.replace('joox ','')))).json()
                                ret_ = []
                                songID = []
                                for i in a['itemlist']:
                                    songID.append(i['songid'])
                                    b = requests.get('http://api-jooxtt.sanook.com/web-fcgi-bin/web_get_songinfo?country=id&lang=en&songid={}&https_only=1'.format(i['songid'])).json()
                                    linkss = (b['mp3Url'])
                                    ret_.append(
                                        {
                                            "type": "bubble",
                                            "header": {
                                                "type": "box",
                                                "layout": "horizontal",
                                                "contents": [
                                                    {
                                                        "type": "text",
                                                        "text": "JOOX",
                                                        "weight": "bold",
                                                        "color": "#aaaaaa",
                                                        "size": "sm"
                                                    }
                                                ]
                                            },
                                        "hero": {
                                            "type": "image",
                                            "url": b['imgSrc'],
                                            "size": "full",
                                            "aspectRatio": "20:13",
                                            "aspectMode": "fit",
                                            "action": {
                                                "type": "uri",
                                                "uri": 'https://line.me/ti/p/zMankMvx69'
                                            }
                                        },
                                        "body": {
                                            "type": "box",
                                            "layout": "vertical",
                                            "contents": [
                                                {
                                                    "type": "box",
                                                    "layout": "vertical",
                                                    "margin": "lg",
                                                    "spacing": "sm",
                                                    "contents": [
                                                        {
                                                           "type": "box",
                                                            "layout": "baseline",
                                                            "spacing": "sm",
                                                            "contents": [
                                                                {
                                                                    "type": "text",
                                                                    "text": "Title",
                                                                    "color": "#aaaaaa",
                                                                    "size": "sm",
                                                                    "flex": 1
                                                                },
                                                                {
                                                                    "type": "text",
                                                                    "text": "{}".format(b['msong']),
                                                                    "color": "#262423",
                                                                    "wrap": True,
                                                                    "size": "sm",
                                                                    "flex": 5
                                                                }
                                                            ]
                                                        }
                                                   ]
                                                }
                                            ]
                                        },
                                        "footer": {
                                            "type": "box",
                                            "layout": "horizontal",
                                            "spacing": "sm",
                                            "contents": [
                                            {
                                                    "type": "button",
                                                    "style": "link",
                                                    "height": "sm",
                                                    "action": {
                                                        "type": "uri",
                                                        "label": "Send Audio",
                                                        "uri": "line://app/1643727178-0XPGAaRX?type=audio&link={}".format(linkss)
                                                    }
                                                }
                                            ],
                                            "flex": 0
                                        }
                                    }
                                )
                            k = len(ret_)//10
                            for aa in range(k+1):
                                data = {"messages": [{"type": "flex","altText": "JOOX","contents": {"type": "carousel","contents": ret_[aa*10 : (aa+1)*10]}}]}
                                sendCarousel(to,data)
                        if cmd.startswith('lyric joox '):
                            bbb = cmd.replace('lyric joox ','').split('-')[0]
                            b = requests.get('http://api-jooxtt.sanook.com/web-fcgi-bin/web_search?country=id&lang=en&search_input={}&sin=10&ein=60'.format(bbb)).json()
                            songID = []
                            for c in b['itemlist']:
                                songID.append(c['songid'])
                            try:
                                d = requests.get("http://api-jooxtt.sanook.com/web-fcgi-bin/web_lyric?country=id&lang=en&musicid={}".format(songID[int(cmd.split('-')[1])-1])).json()
                                b = str(base64.b64decode(d['lyric']).decode('utf-8'))
                                lyric = b.replace('ti:','Title - ')
                                lyric = lyric.replace('ar:','Artist - ')
                                lyric = lyric.replace('al:','Album - ')
                                lyric = lyric.replace('by','')
                                lyric = lyric.replace('offset','')
                                lyric = lyric.replace("***Lyrics are from third-parties***\n","")
                                removeString = "[1235467890:.]"
                                for char in removeString:
                                    lyric = lyric.replace(char,'')
                                sendFlex(to, str(lyric))
                            except Exception as e:print(e)
                        if cmd.startswith("youtube search "):
                            a = noobcoder.adityarequestweb("https://www.googleapis.com/youtube/v3/search?part=snippet&maxResults=25&q="+noobcoder.adityasplittext(cmd,'s')+"&type=video&key=AIzaSyAF-_5PLCt8DwhYc7LBskesUnsm1gFHSP8")
                            if a["items"] != []:
                                no = 0
                                ret_ = []
                                for music in a["items"]:
                                    no += 1
                                    ret_.append({"type": "bubble","header": {"type": "box","layout": "horizontal","contents": [{"type": "text","text": "Youtube","weight": "bold","color": "#aaaaaa","size": "sm"}]},"hero": {"type": "image","url": 'https://i.ytimg.com/vi/{}/maxresdefault.jpg'.format(music['id']['videoId']),"size": "full","aspectRatio": "20:13","aspectMode": "fit","action": {"type": "uri","uri": 'https://www.youtube.com/watch?v=' +music['id']['videoId']}},"body": {"type": "box","layout": "vertical","contents": [{"type": "box","layout": "vertical","margin": "lg","spacing": "sm","contents": [{"type": "box","layout": "baseline","spacing": "sm","contents": [{"type": "text","text": "Title","color": "#aaaaaa","size": "sm","flex": 1},{"type": "text","text": "{}".format(music['snippet']['title']),"color": "#262423","wrap": True,"size": "sm","flex": 5}]}]}]},"footer": {"type": "box","layout": "horizontal","spacing": "sm","contents": [{"type": "button","style": "link","height": "sm","action": {"type": "uri","label": "Page","uri": 'https://www.youtube.com/watch?v=' +music['id']['videoId']}},{"type": "button","style": "link","height": "sm","action": {"type": "uri","label": "Video","uri": "{}youtubemp4%20https://www.youtube.com/watch?v={}".format(wait['ttt'],music['id']['videoId'])}},{"type": "button","style": "link","height": "sm","action": {"type": "uri","label": "Audio","uri": "{}youtubemp3%20https://www.youtube.com/watch?v={}".format(wait['ttt'],music['id']['videoId'])}},],}})
                                k = len(ret_)//10
                                for aa in range(k+1):
                                    data = {"type": "flex","altText": "KhieWasHere","contents": {"type": "carousel","contents": ret_[aa*10 : (aa+1)*10]}}
                                    sendTemplate(to ,data)
                            else:
                                noobcoder.sendMessage(to,"Type: Search Youtube Video\nStatus: "+str(self.adityasplittext(msg.text,'s'))+" not found")
                        if cmd.startswith('instagram ') or cmd.startswith('instagram post ') or cmd.startswith('instagram story ') or cmd.startswith('instagram postinfo '): igsearch(msg,liffnya,cmd)
                        elif cmd.startswith("danbooru "):                                                                                 	    
                                text_ = removeCmd("danbooru", text)
                                cond = text_.split(" ")                          
                                jml = int(cond[0])
                                url = requests.get("https://api.boteater.co/danbooru?page=1")
                                data = url.json()                              
                                for x in range(jml):
                                    def anu():
                                        for anu in data["result"]:
                                            result = str(anu["img"])
                                            noobcoder.sendImageWithURL(to, result)
                                    treding = Thread(target=anu)
                                    treding.daemon = True
                                    treding.start()

                        elif cmd == "chatbot":
                            ret = "Type: ChatBot\n\n"
                            ret += "  • Chatbot on\n"
                            ret += "  • Chatbot off\n"
                            ret += "  • Chatbot list"
                            sendFooter(to, str(ret))
                        elif cmd == "groups":
                            key = settings["keyCommand"].title()
                            if settings['setKey'] == False:key = ''
                            gid = noobcoder.getGroupIdsJoined()
                            sd = noobcoder.getGroups(gid)
                            ret = "「 Group List 」\n"
                            no = 0
                            total = len(gid)
                            cd = "\n\nTotal {} Groups\n\n「 Command 」\n\n• Trigger: [<|>|-|num]\n> • < Remote Mention\n   •  groups (numb) tag <trigger>\n> • < Remote Kick\n   •  groups (numb) kick <trigger>\n> • < Leave Groups\n   •  leave groups <trigger>\n> • < Get QR\n   • openqr <trigger>\n> • < Unsent\n   • groups (numb) unsent (numb)\n> • < Cek Member\n   •  groups (numb)\n   •  groups (numb) mem <trigger>".format(total)
                            for G in sd:
                                member = len(G.members)
                                no += 1
                                ret += "\n{}. {} | {}".format(no, G.name[0:20], member)
                            ret += cd
                            k = len(ret)//10000
                            for aa in range(k+1):
                                sendFooter1(to,'{}'.format(ret[aa*10000 : (aa+1)*10000]))
                        elif cmd.startswith("commentpost: "):
                            sep = text.split(" ")
                            txt = text.replace(sep[0] + " ","")
                            try:
                                settings["commentPost"] = txt
                                sendFooter(to, "Comment changed to :\n{}".format(txt))
                            except:
                                noobcoder.sendMessage(to, "Failed")
                        elif cmd == "group pending":
                            groups = noobcoder.getGroupIdsInvited()
                            ret_ = "「 Group Pending List 」\n"
                            no = 1
                            for gid in groups:
                                group = noobcoder.getGroup(gid)
                                ret_ += "\n{}. {} | {}".format(str(no), str(group.name), str(len(group.members)))
                                no = (no+1)
                            ret_ += "\n\nTotal {} Pending".format(str(len(groups)))
                            ret_ += "\n\nUsage : Reject [num]"
                            sendFooter(to, str(ret_))
#==========================================
                        elif cmd == "conban":
                            if wait["blacklist"] == {}:
                                  noobcoder.sendMessage(msg.to,"No blacklist")
                            else:
                                  ma = ""
                                  for i in wait["blacklist"]:
                                      ma = noobcoder.getContact(i)
                                      noobcoder.sendMessage(msg.to, None, contentMetadata={'mid': i}, contentType=13)
                        elif cmd == "mymid":
                            sendFooter1(to, "「 Mid 」\n "+str(sender))
                        elif cmd == "myprofile":
                            contact = noobcoder.getContact(noobcoderMID)
                            cu = noobcoder.getProfileCoverURL(noobcoderMID)
                            path = str(cu)
                            image = "http://dl.profile.line-cdn.net/" + contact.pictureStatus
                            noobcoder.sendImageWithURL(to, image)
                            noobcoder.sendImageWithURL(to, path)
                            noobcoder.sendMessage(to, "「 Profile 」\nMid : "+str(sender)+"\nName : "+str(contact.displayName)+"\nStatus :\n"+str(contact.statusMessage))
                        elif cmd == "myname":
                            h = noobcoder.getContact(noobcoderMID)
                            sendFooter(to, "「 Name 」\n"+str(h.displayName))
                        elif cmd == "mybio":
                            h = noobcoder.getContact(noobcoderMID)
                            sendFooter(to, "「 Status 」\n"+str(h.statusMessage))
                        elif cmd == "mycontact":
                            contact = noobcoder.getContact(sender)
                            data={"type":"flex","altText":"NOOB CODER™","contents":{"type":"bubble","body": {"type": "box","layout": "vertical","contents": [{"type": "box","layout": "horizontal","contents": [{"type": "box","layout": "vertical","contents": [{"type": "image","url": "https://obs.line-scdn.net/{}".format(contact.pictureStatus),"aspectMode": "cover","size": "full"}],"cornerRadius": "100px","width": "72px","height": "72px"},{"type": "box","layout": "baseline","contents": [{"type": "text","contents": [],"size": "xl","wrap": True,"text": "{}".format(contact.displayName),"color": "#000000","weight": "bold","style": "italic"}]}],"spacing": "xl","paddingAll": "20px"}],"paddingAll": "0px"},"footer":{"type":"box","layout":"horizontal","spacing":"sm","contents":[{"type":"box","layout":"vertical","contents":[{"type":"image","url":"https://i.ibb.co/4mbftvy/IMG-20190809-211441.jpg","size":"full","offsetTop":"0px","offsetBottom":"0px","offsetStart":"0px","offsetEnd":"0px"}],"width":"20px","height":"20px","cornerRadius":"5px","offsetTop":"5px"},{"type":"text","text":"NOOB CODER™","size":"xs","gravity":"center","offsetStart":"5px"},{"type":"box","layout":"vertical","contents":[{"type":"image","url":"https://cdn3.iconfinder.com/data/icons/faticons/32/arrow-right-01-512.png","offsetTop":"0px","offsetBottom":"0px","offsetStart":"0px","offsetEnd":"0px"}],"width":"15px","height":"15px","cornerRadius":"5px","offsetTop":"9px"}],"flex":0,"height":"50px","action":{"type":"uri","label":"action","uri":"https://line.me/ti/p/~" + noobcoder.profile.userid}},"styles":{"footer":{"separator":True}}}}
                            sendTemplate(to, data)
                        elif cmd == "mypicture":
                            contact = noobcoder.getContact(sender)
                            LINKFOTO = "https://os.line.naver.jp/os/p/" + sender
                            data = {
                                "type": "template",
                                "altText": "Image carouserl",
                                "template": {
                                    "type": "image_carousel",
                                    "columns": [
                                        {
                                            "imageUrl": "https://obs.line-scdn.net/{}".format(contact.pictureStatus),
                                            "size": "full",
                                            "action": {
                                                "type": "uri",
                                                "uri": "line://ti/p/~khiewuzzheree"
                                            }
                                        }
                                    ]
                                }
                            }
                            sendTemplate(to, data)
                        elif cmd == "myvideo":
                            h = noobcoder.getContact(noobcoderMID)
                            if h.videoProfile == None:
                            	return noobcoder.sendMessage(to, "「 Video 」\nNone")
                            noobcoder.generateReplyMessage(msg.id)
                            noobcoder.sendReplyVideoWithURL(msg.id, to,"http://dl.profile.line-cdn.net/" + h.pictureStatus + "/vp")
                        elif cmd == "mycover":
                            h = noobcoder.getContact(noobcoderMID)
                            cu = noobcoder.getProfileCoverURL(noobcoderMID)
                            image = str(cu)
                            noobcoder.generateReplyMessage(msg.id)
                            noobcoder.sendReplyImageWithURL(msg.id, to, image)
                        elif cmd == "openqr":
                            if msg.toType == 2:
                                group = noobcoder.getGroup(to)
                                group.preventedJoinByTicket = False
                                noobcoder.updateGroup(group)
                                gurl = noobcoder.reissueGroupTicket(to)
                                sendFooter1(msg.to,"QR Group open\n\n" + "Link : line://ti/g/" + gurl)
                        elif cmd == "closeqr":
                            if msg.toType == 2:
                                group = noobcoder.getGroup(to)
                                group.preventedJoinByTicket = True
                                noobcoder.updateGroup(group)
                                sendFooter1(msg.to,"QR Group close")
                        elif cmd == "leave":
                            if msg.toType == 2:
                                group = noobcoder.getGroup(to)
                                sendFooter(to, "🔥Bye bye "+str(group.name))
                                noobcoder.leaveGroup(to)
                        elif cmd == "timeleft":
                            timeNow = time.time()
                            runtime = timeNow - botStart
                            runtime = format_timespan(runtime)
                            sendFooter(to, "「 Time to due 」\n"+str(runtime))
                        elif cmd == "rejectall" and sender == noobcoderMID:
                            ginvited = noobcoder.getGroupIdsInvited()
                            if ginvited != [] and ginvited != None:
                                for gid in ginvited:
                                    noobcoder.rejectGroupInvitation(gid)
                                sendFooter(to, "Succes rejected 「 {} 」invitetation".format(str(len(ginvited))))
                            else:
                                noobcoder.sendMessage(to, "Nothing")
                        elif cmd == "cancelall" and sender == noobcoderMID:
                            if msg.toType == 2:
                                group = noobcoder.getGroup(to)
                                if group.invitee is None or group.invitee == []:
                                    noobcoder.sendMessage(to, "Nothing")
                                else:
                                    invitee = [contact.mid for contact in group.invitee]
                                    for inv in invitee:
                                        noobcoder.cancelGroupInvitation(to, [inv])
                                        time.sleep(1)
                                    sendFooter(to, "Succes canceled 「 {} 」user".format(str(len(invitee))))
                        elif cmd == "nukeall":
                            if msg.toType == 2:
                                group = noobcoder.getGroup(to)
                                gMembers = [contact.mid for contact in group.members]
                                for i in gMembers:
                                    time.sleep(0.008)
                                    noobcoder.kickoutFromGroup(to,[i])
                                sendFooter(to,"Just Some Casual Cleasing")
                            else:
                                noobcoder.sendMessage(to,"failed >_<")
                        elif cmd == 'nuke':
                            if msg.toType == 2:
                                print ("[ 19 ] KICK ALL MEMBER")
                                _name = removeCmd("hulabala", text)
                                gs = noobcoder.getCompactGroup(to)
                                sendFooter(msg.id, to,"Victims shall yell hul·la·ba·loo♪\n/ˌhələbəˈlo͞o,ˈhələb♪ˌlo͞o/")
                                targets = []
                                for g in gs.members:
                                    if _name in g.displayName:
                                        targets.append(g.mid)
                                if targets == []:
                                    sendFooter(to,"tidak ditemukan")
                                else:
                                    for target in targets:
                                        try:
                                            noobcoder.kickoutFromGroup(to,[target])
                                            print (to,[g.mid])
                                        except:
                                            sendFooter(to,"Finish !")
                        elif cmd == "blocklist" and sender == noobcoderMID:
                            blockedlist = noobcoder.getBlockedContactIds()
                            kontak = noobcoder.getContacts(blockedlist)
                            num=1
                            msgs="「 Blocked List 」\n"
                            for ids in kontak:
                                msgs+="\n%i. %s" % (num, ids.displayName)
                                num=(num+1)
                            msgs+="\n\nTotal Blocked : %i" % len(kontak)
                            msgs+= "\nBlockInfo「 number 」"
                            msgs+= "\nConBlock"
                            msgs+= "\nBlockfriend [@]"
                            msgs+= "\nBlockmid [mid]"
                            msgs+= "\nUnblockmid [mid]"
                            sendFooter(to, str(msgs))
                        elif cmd == "favoritelist":
                            contactlist = noobcoder.getFavoriteMids()
                            kontak = noobcoder.getContacts(contactlist)
                            num=1
                            msgs="「 Favorite List 」\n"
                            for ids in kontak:
                                msgs+="\n%i. %s" % (num, ids.displayName)
                                num=(num+1)
                            msgs+="\n\n「 Total Favoritelist : %i 」" % len(kontak)
                            msgs+= "\nUsage : FavoriteInfo「 number 」"
                            sendFooter(to, str(msgs))
                        elif cmd == 'gift':
                            noobcoder.sendReplyMessage(msg.id, to, text=None, contentMetadata={'PRDID': '350d37d6-bfc9-44cb-a0d1-cf17ae3657db','PRDTYPE': 'THEME','MSGTPL': '5'}, contentType=9)
#=====================================================================
                        elif cmd == "detailcon on":
                            settings["checkContact"] = True
                            sendFooter(to, "Detail Contact has been Enabled")
                        elif cmd == "detailcon off":
                            settings["checkContact"] = False
                            sendFooter(to, "Detail Contact has been Disabled")
                        elif cmd == "changedp" and sender == noobcoderMID:
                            settings["changePicture"] = True
                            sendFooter(to, "Type: Profile\n • Detail: Change Profile Picture\n • Status: Waiting for picture\n Please send a picture...")
                        elif cmd == "change cover":
                            settings["changeCoverProfile"] = True
                            sendFooter(to,"Type: Profile\n • Detail: Change Home Photos\n • Status: Waiting for picture\nPlease send a picture...")
                        elif cmd == "changedp video" and sender == noobcoderMID:
                            settings['changeProfileVideo']['status'] = True
                            settings['changeProfileVideo']['stage'] = 1
                            sendFooter(to, "Type: Profile\n • Detail: Change Video Profile\n • Status: Waiting for video\nPlease send a video...")
                        elif cmd == "changedp group":
                            if msg.toType == 2:
                                if to not in settings["changeGroupPicture"]:
                                    settings["changeGroupPicture"].append(to)
                                sendFooter(to, "Type: Group\n • Detail: Change Group Picture\n • Status: Waiting for picture\nPlease send a picture...")
                        elif cmd.startswith("addtext"):
                           sep = text.split("#")
                           an = sep[len(sep)-1].split('/')
                           name = an[0]
                           name = name.lower()
                           if name not in textsadd:
                            ciel["addText"]["statustext"] = True
                            ciel["addText"]["texts"] = str(name.lower())
                            textsadd[str(name.lower())] = {}
                            textsadd[ciel["addText"]["texts"]] = {"CHAT":"{}".format(an[1])}
                            sendFooter(to, "Command {} created".format(str(ciel["addText"]["texts"])))
                            ciel["addText"]["statustext"] = False                
                            ciel["addText"]["texts"] = ""
                            f = codecs.open('khie/text.json','w','utf-8')
                            json.dump(textsadd, f, sort_keys=True, indent=4, ensure_ascii=False)
                           else:
                            sendFooter(to, "Text already in List!")
                        elif cmd.startswith("deltext "):
                            sep = text.split(" ")
                            name = text.replace(sep[0] + " ","")
                            name = name.lower()
                            if name in textsadd:
                                del textsadd[str(name.lower())]
                                f = codecs.open("khie/text.json","w","utf-8")
                                json.dump(textsadd, f, sort_keys=True, indent=4, ensure_ascii=False)
                                sendFooter(to, "Command {} has been removed".format( str(name.lower())))
                            else:
                                sendFooter(to, "Command {} does not exist")
                        elif cmd == "list text":
                            no = 0
                            ret_ = "List Text :\n\n"
                            for txt in textsadd:
                                no += 1
                                ret_ += str(no) + ". " + txt.title() + "\n"
                            ret_ += "\nTotal {} Created".format(str(len(stickers)))
                            sendFooter(to, ret_)
                        elif cmd.startswith("getvideo "):
                            try:
                                sep = msg.text.split(" ")
                                textToSearch = text.replace(sep[0] + " ","")
                                query = urllib.parse.quote(textToSearch)
                                url = "https://www.youtube.com/results?search_query=" + query
                                response = urllib.request.urlopen(url)
                                html = response.read()
                                soup = BeautifulSoup(html, "html.parser")
                                results = soup.find(attrs={'class':'yt-uix-tile-link'})
                                dl=("https://www.youtube.com" + results['href'])
                                vid = pafy.new(dl)
                                stream = vid.streams
                                for s in stream:
                                    vin = s.url
                                    hasil = "Youtube - Video :\n"
                                    hasil += "\nTitle : {}".format(str(vid.title))
                                    hasil += "\nSubscriber From : {}".format(str(vid.author))
                                noobcoder.generateReplyMessage(msg.id)
                                noobcoder.sendReplyMessage(msg.id, to,hasil)
                                noobcoder.sendVideoWithURL(msg.to,vin)
                                print("[YOUTUBE]MP4 Succes")
                            except Exception as e:
                                noobcoder.generateReplyMessage(msg.id)
                                noobcoder.sendReplyMessage(msg.id, to,str(e))
                        elif cmd.startswith("deltext "):
                            	if sender in noobcoderMID:
                                    sep = text.split(" ")
                                    xres = text.replace(sep[0] + " ","")
                                    tetx = text.replace(sep[0] + " ","")
                                    if xres in tes["Message"]:
                                        del tes["Message"][xres]                                        
                                        noobcoder.sendMessage(to,"Command %s has been removed."%tetx)
                                    else:
                                        noobcoder.sendMessage(to,"Command %s does not exist."%tetx)
                        elif cmd.startswith("stickers "):
                            search = removeCmd("stickers", text)        
                            r = requests.get("http://api.farzain.com/stickerline.php?q={}&apikey=tUiq7OE1O8Swpa8Zs8nFoD45j".format(str(search)))
                            data=r.text
                            data=json.loads(data)
                            if data["result"] != []:
                                no = 0
                                hasil = " 「 Line Stickers 」"
                                for sam in data["result"]:                                   
                                    no += 1                  
                                    hasil += "\n    " + str(no) + ". " + str(sam["title"])+"\n"+"line.me/S/sticker/"+str(sam["id"])
                                noobcoder.sendMessage(to, str(hasil))    
                        if cmd.startswith("rename "):
                                if 'MENTION' in msg.contentMetadata.keys()!= None:
                                    names = re.findall(r'@(\w+)', text)
                                    mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                                    mentionees = mention['MENTIONEES']
                                    lists = []
                                    for mention in mentionees:
                                        if mention["M"] not in lists:
                                            lists.append(mention["M"])
                                    reee = ""
                                    for ls in lists:
                                        ret_ = "{}".format(str(ls))
                                    sep = text.split(" ")
                                    s = text.replace(sep[0] + " ","")
                                    sam = s.split("|")
                                    namauser = sam[1]
                                    b = noobcoder.getContact(ls).displayName                                        
                                    noobcoder.findAndAddContactsByMid(ls)
                                    noobcoder.renameContact(ls,namauser)
                                    noobcoder.sendMessage(to,'Rename changed from '+b+' To '+namauser+".")
                        elif cmd.startswith("themes "):
                            search = removeCmd("themes", text)        
                            r=requests.get("http://api.farzain.com/themeline.php?q={}&apikey=tUiq7OE1O8Swpa8Zs8nFoD45j".format(str(search)))
                            data=r.text
                            data=json.loads(data)
                            if data["result"] != []:
                                no = 0
                                hasil = " 「 Line Themes 」"
                                for sam in data["result"]:              
                                    no += 1                  
                                    hasil += "\n    " + str(no) + ". " + str(sam["title"])+"\n"+"line://shop/theme/detail?id="+str(sam["id"])
                                noobcoder.sendMessage(to, str(hasil))    
                        elif cmd.startswith("tetew "):
                            sendFooter(to,"Teteeeweeeeewew.")
                            mid = cmd.replace('tetew ','').split(' ')
                            kiez = 'spam.js token={}'.format(to, noobcoder.authToken, "IOSIPAD\t11.2.5\tiPhone X\t11.2.5")                           
                            for x in mid:
                                try:
                                    noobcoder.findAndAddContactsByMid(x)
                                    kiez += ' uid={}'.format(x)
                                except Exception as e:
                                    print(e)
                            success = execute_js(kiez)
                            print(kiez)                       
                        elif cmd.startswith("drawsoupletters "):
                            q = removeCmd("drawsoupletters", text)
                            r = requests.get("http://api.zicor.ooo/sletters.php?text={}".format(str(q)))                                    
                            data=r.text
                            data=json.loads(data)
                            noobcoder.sendImageWithURL(to,str(data["image"]))
                        elif cmd.startswith("drawstreets "):
                            sep = text.split(" ")
                            txt = text.replace(sep[0] + " ","")
                            r = requests.get("http://api.zicor.ooo/streets.php?text="+urllib.parse.quote(txt))
                            data=r.text
                            data=json.loads(data)
                            noobcoder.sendImageWithURL(to,str(data["image"]))
                        elif cmd.startswith("drawwindow "):
                            q = removeCmd("drawwindow", text)
                            r = requests.get("http://api.zicor.ooo/fwindow.php?text={}&btype=3".format(str(q)))
                            data=r.text
                            data=json.loads(data)
                            noobcoder.sendImageWithURL(to,str(data["image"]))
                        elif cmd.startswith("drawcookies "):
                            q = removeCmd("drawcookies", text)
                            r = requests.get("http://api.zicor.ooo/wcookies.php?text={}".format(str(q)))
                            data=r.text
                            data=json.loads(data)
                            noobcoder.sendImageWithURL(to,str(data["image"]))
                        elif cmd.startswith("drawlight "):
                            q = removeCmd("drawlight", text)
                            r = requests.get("http://api.zicor.ooo/graffiti.php?text={}".format(str(q)))
                            data=r.text
                            data=json.loads(data)
                            noobcoder.sendImageWithURL(to,str(data["image"]))
                        elif cmd.startswith("cosplay "):
                             sep = text.split(" ")
                             txt = text.replace(sep[0] + " ","")
                             url = "https://rest.farzain.com/api/special/fansign/cosplay/cosplay.php?apikey=nda12345&text={}".format(txt)
                             noobcoder.sendImageWithURL(to, url)
                        elif cmd.startswith("viloid "):
                             sep = text.split(" ")
                             txt = text.replace(sep[0] + " ","")
                             url = "https://rest.farzain.com/api/special/fansign/indo/viloid.php?apikey=aguzzzz748474848&beta&text={}".format(txt)
                             noobcoder.sendImageWithURL(to, url)
                        elif cmd.startswith("spamgift "):
                            text = removeCmd("spamgift", text)
                            korban = text.replace('spamgift ', text)
                            korban2 = korban.split()
                            midd = korban2[0]
                            jumlah = int(korban2[1])
                            if jumlah <= 1000:
                                for var in range(0,jumlah):
                                    noobcoder.sendMessage(midd, None, contentMetadata={'PRDID': 'a0768339-c2d3-4189-9653-2909e9bb6f58', 'PRDTYPE': 'THEME', 'MSGTPL': '6'}, contentType=9)
                                noobcoder.sendMessage(to, "Succes ~")
                        elif cmd.startswith("youtubesearch "):
                            sep = msg.text.split(" ")
                            youtubeSearchV3(to, sep[1])
                        elif cmd.startswith("gift "):
                            query = removeCmd("gift", text)
                            text = query.split("-")
                            message = text[0]
                            number = text[1]
                            groups = noobcoder.getGroupIdsJoined()
                            try:
                                group = groups[int(number)-1]
                                G = noobcoder.getGroup(group)
                                try:
                                    noobcoder.sendGift(group,str(message),'sticker')
                                except:
                                    noobcoder.sendGift(group,str(message),'sticker')
                                noobcoder.sendMessage(to, "「 Remote Gift 」\n\nGroup : " + G.name)
                            except Exception as error:
                                noobcoder.sendMessage(to, str(error))
                        elif cmd.startswith("sendfile"):
                            if msg._from in myAdmin:
                                text = removeCmd("sendfile", text)
                                sep = text.split(" ")
                                file = text.replace(sep[0] + " ", text)
                                time.sleep(1)
                                noobcoder.sendFile(to,file)
                        elif cmd.startswith("danbooru "):                                                                                 	    
                                text_ = removeCmd("danbooru", text)
                                cond = text_.split(" ")                          
                                jml = int(cond[0])
                                url = requests.get("https://api.boteater.co/danbooru?page=1")
                                data = url.json()                              
                                for x in range(jml):
                                    def anu():
                                        for anu in data["result"]:
                                            result = str(anu["img"])
                                            noobcoder.sendImageWithURL(to, result)
                                    treding = Thread(target=anu)
                                    treding.daemon = True
                                    treding.start()
                        elif cmd.startswith('groups'):
                            to = msg.to
                            gid = noobcoder.getGroupIdsJoined()
                            group = noobcoder.getGroup(gid[int(cmd.split(' ')[1])-1])
                            nama = [a.mid for a in group.members]
                            if len(cmd.split(" ")) == 2:
                                total = "Local ID: {}".format(int(cmd.split(' ')[1]))
                                noobcoder.datamention(to,'List Member',nama,'\n├Group: '+group.name[:20]+'\n├'+total)
                            if len(cmd.split(" ")) == 4:
                                if cmd.startswith('groups '+cmd.split(' ')[1]+' mem '):noobcoder.getinformation(to,nama[int(cmd.split(' ')[3])-1],wait)
                                if cmd.startswith('groups '+cmd.split(' ')[1]+' tag'):noobcoder.adityaarchi(wait,'Mention','tag',gid[int(cmd.split(' ')[1])-1],cmd.split(' ')[3],msg,"\n├Group: {}\n├Local ID: {}".format(group.name[:20],int(cmd.split(' ')[1])),nama=nama)
                                if cmd.startswith('groups '+cmd.split(' ')[1]+' kick'):noobcoder.adityaarchi(wait,'Kick Member','kick',gid[int(cmd.split(' ')[1])-1],cmd.split(' ')[3],msg,"\n├Group: {}\n├Local ID: {}".format(group.name[:20],int(cmd.split(' ')[1])),nama=nama)
                                if cmd.startswith('groups '+cmd.split(' ')[1]+' unsent'):
                                    a = gid[int(cmd.split(' ')[1])-1]
                                    j = int(cmd.split(' ')[3])
                                    a = [noobcoder.adityasplittext(cmd,'s').replace('{} '.format(j),'')]*j
                                    h = wait['Unsend'][gid[int(cmd.split(' ')[1])-1]]['B']
                                    for b in h[:j]:
                                        print(b)
                                        try:
                                            noobcoder.unsendMessage(b)
                                            wait['Unsend'][gid[int(cmd.split(" ")[1])-1]]['B'].remove(b)
                                        except Exception as e:print(e)
                        if cmd.startswith("leave groups "):
                            if msg.toType in [0,1,2]:
                                gid = noobcoder.getGroupIdsJoined()
                                if len(cmd.split(" ")) == 3:
                                    selection = MySplit(cmd.split(' ')[2],range(1,len(gid)+1))
                                    k = len(gid)//100
                                    for a in range(k+1):
                                        if a == 0:eto='╭「 Leave Group 」─'
                                        else:eto='├「 Leave Group 」─'
                                        text = ''
                                        no = 0
                                        for i in selection.parse()[a*100 : (a+1)*100]:
                                            noobcoder.leaveGroup(gid[i - 1])
                                            time.sleep(2)
                                            no+=1
                                            if no == len(selection.parse()):text+= "\n╰{}. {}".format(i,noobcoder.getGroup(gid[i - 1]).name)
                                            else:text+= "\n│{}. {}".format(i,noobcoder.getGroup(gid[i - 1]).name)
                                        noobcoder.sendMessage(to,eto+text)
                        elif cmd.startswith("meownime "):
                            proses = text.split(" ")
                            urutan = text.replace(proses[0] + " ","")
                            count = urutan.split("|")
                            search = str(count[0])
                            r = requests.get("https://arsybai.herokuapp.com/rest/meownime?apikey=Naufal02&search="+str(search))
                            data = json.loads(r.text)
                            if len(count) == 1:
                                no = 0
                                hasil = "Result Anime :\n"    
                                for aa in data["result"]: 
                                    no += 1
                                    hasil += "\n" + str(no) + ". " + str(aa["title"])
                                    ret_ = "\n\nType: Meownime {} | Number".format(str(search))
                                sendFooter(msg.to,hasil+ret_)                
                            elif len(count) == 2:
                                try:
                                    num = int(count[1])
                                    b = data["result"][num - 1]
                                    c = str(b["title"])                                    
                                    e = str(b["url"])
                                    hasil = "Detail :\n"    
                                    hasil += "\nTitle : "+str(c)                                                                        
                                    hasil += "\nLink : "+str(e)  
                                    sendFooter1(msg.to,hasil)
                                    dl = str(b["img"])
                                    noobcoder.sendImageWithURL(msg.to,dl)
                                except Exception as error:
                                    noobcoder.sendMessage(to, "Sorry, Anime not found")
                                    logError(error)
                        elif cmd.startswith("gif "):
                            proses = text.split(" ")
                            urutan = text.replace(proses[0] + " ","")
                            count = urutan.split("|")
                            search = str(count[0])
                            r = requests.get("https://api.tenor.com/v1/search?key=PVS5D2UHR0EV&limit=10&q="+str(search))
                            data = json.loads(r.text)
                            if len(count) == 1:
                                no = 0
                                hasil = "Search Gif :\n"
                                for aa in data["results"]:
                                    no += 1
                                    hasil += "\n" + str(no) + ". " + str(aa["title"])
                                    ret_ = "\n\nType: Gif {} | Number".format(str(search))
                                sendFooter(msg.to,hasil+ret_)
                            elif len(count) == 2:
                                try:
                                    num = int(count[1])
                                    b = data["results"][num - 1]
                                    c = str(b["id"])
                                    hasil = "Information Gif ID "+str(c)
                                    sendFooter(msg.to,hasil)
                                    dl = str(b["media"][0]["loopedmp4"]["url"])
                                    noobcoder.sendVideoWithURL(msg.to,dl)
                                except Exception as e:
                                    noobcoder.sendMessage(msg.to," "+str(e)) 
                        elif cmd.startswith("checkip "):
                            search = removeCmd("checkip", text)
                            r = _session.get("https://ipapi.co/" + search + "/json")
                            data = r.text
                            data = json.loads(data)
                            if "error" not in data:
                                ret_ = "IP Checker :\n"
                                ret_ += "\nIp : {}".format(data["ip"])
                                ret_ += "\nCity : {}".format(data["city"])
                                ret_ += "\nRegion : {}".format(data["region"])
                                ret_ += "\nRegion Code : {}".format(data["region_code"])
                                ret_ += "\nCountry : {}".format(data["country"])
                                ret_ += "\nCountry Name : {}".format(data["country_name"])
                                ret_ += "\nPostal : {}".format(data["postal"])
                                ret_ += "\nLatitude : {}".format(data["latitude"])
                                ret_ += "\nLongitude : {}".format(data["longitude"])
                                ret_ += "\nTimezone : {}".format(data["timezone"])
                                ret_ += "\nASN Code : {}".format(data["asn"])
                                ret_ += "\nOrganization : {}".format(data["org"])
                                sendFooter(msg.to,str(ret_))
                            else:
                                noobcoder.sendMessage(to, "IP not found !")

                        elif cmd.startswith("imagetext "):
                            text_ = removeCmd("imagetext", text)
                            web = _session
                            web.headers["User-Agent"] = random.choice(settings["userAgent"])
                            font = random.choice(["arial","comic"])
                            r = web.get("http://api.img4me.com/?text=%s&font=%s&fcolor=FFFFFF&size=35&bcolor=000000&type=jpg" %(urllib.parse.quote(text_),font))
                            data = str(r.text)
                            if "Error" not in data:
                                path = data
                                noobcoder.sendImageWithURL(to,path)
                            else:
                                noobcoder.sendMessage(to,"[RESULT] %s" %(data.replace("Error: ")))
                        elif cmd.startswith("pictureig ") and sender == noobcoderMID:
                            cari = removeCmd("pictureig", text)
                            try:
                                respon = _session.get(cari+"?__a=1")
                                data = respon.json()
                                ig_url = data['graphql']['shortcode_media']['display_url']
                                noobcoder.sendImageWithURL(msg.to,ig_url)
                            except:
                                noobcoder.sendMessage(msg.to,"Error")
                        elif cmd.startswith("videoig ") and sender == noobcoderMID:
                            cari = removeCmd("videoig", text)
                            try:
                                respon = _session.get(cari+"?__a=1")
                                data = respon.json()
                                ig_url = data['graphql']['shortcode_media']['video_url']
                                noobcoder.sendVideoWithURL(msg.to,ig_url)
                            except:
                                noobcoder.sendMessage(msg.to,"Error")
                        elif cmd.startswith("xxx "):
                            proses = text.split(" ")
                            urutan = text.replace(proses[0] + " ","")
                            count = urutan.split("|")
                            search = str(count[0])
                            r = requests.get("https://api.avgle.com/v1/search/{}/1?limit=10".format(str(search)))
                            data = json.loads(r.text)
                            if len(count) == 1:
                                no = 0
                                hasil = "「 Search video 18+ 」\n"
                                for aa in data["response"]["videos"]:
                                    no += 1
                                    hasil += "\n"+str(no)+". "+str(aa["title"])+"\nDurasi : "+str(aa["duration"])
                                    ret_ = "\n\nXxx {} | Number".format(str(search))
                                noobcoder.sendMessage(msg.to,hasil+ret_)
                            elif len(count) == 2:
                                try:
                                    num = int(count[1])
                                    b = data["response"]["videos"][num - 1]
                                    c = str(b["vid"])
                                    d = requests.get("https://api.avgle.com/v1/video/"+str(c))
                                    data1 = json.loads(d.text)
                                    hasil = "Title : "+str(data1["response"]["video"]["title"])
                                    hasil += "\n\nDurasi : "+str(data1["response"]["video"]["duration"])
                                    hasil += "\nKualitas HD : "+str(data1["response"]["video"]["hd"])
                                    hasil += "\nDitonton "+str(data1["response"]["video"]["viewnumber"])
                                    hasil += "\nLink video : "+str(data1["response"]["video"]["video_url"])
                                    hasil += "\nLink embed : "+str(data1["response"]["video"]["embedded_url"])
                                    noobcoder.sendMessage(msg.to,hasil)
                                    anuanu = str(data1["response"]["video"]["preview_url"])
                                    path = noobcoder.downloadFileURL(anuanu)
                                    noobcoder.sendImage(msg.to,path)
                                except Exception as e:
                                    noobcoder.sendMessage(msg.to," "+str(e))
                        elif cmd.startswith("idline "):
                            a = removeCmd("idline", text)
                            b = noobcoder.findContactsByUserid(a)
                            line = b.mid
                            noobcoder.sendMessage(msg.to,"http://line.me/ti/p/~" + a)
                            noobcoder.sendContact(to, line)                                                                                           
                            noobcoder.sendMessage(to,str(hasil))
                        elif cmd.startswith("blockinfo "):
                            number = removeCmd("blockinfo", text)
                            contactlist = noobcoder.getBlockedContactIds()
                            try:
                                contact = contactlist[int(number)-1]
                                friend = noobcoder.getContact(contact)
                                cu = noobcoder.getProfileCoverURL(contact)
                                path = str(cu)
                                image = "http://dl.profile.line-cdn.net/" + friend.pictureStatus
                                try:
                                    noobcoder.sendMessage(to,"「 Block Info 」\n\n" + "Name : " + friend.displayName + "\nStatus : " + friend.statusMessage + "\nMid : " + friend.mid)
                                    noobcoder.sendImageWithURL(to,image)
                                    noobcoder.sendImageWithURL(to,path)
                                    noobcoder.sendContact(to, friend.mid)
                                except:
                                    pass
                            except Exception as error:
                                noobcoder.sendMessage(to, "「 Result Error 」\n" + str(error))
                        elif cmd.startswith("favoriteinfo "):
                            text = removeCmd("favoriteinfo", text)
                            separate = text.split(" ")
                            number = text.replace(separate[0] + " ", text)
                            contactlist = noobcoder.getFavoriteMids()
                            try:
                                contact = contactlist[int(number)-1]
                                friend = noobcoder.getContact(contact)
                                cu = noobcoder.getProfileCoverURL(contact)
                                path = str(cu)
                                image = "http://dl.profile.line-cdn.net/" + friend.pictureStatus
                                try:
                                    noobcoder.sendMessage(to,"「 Favorite Info」\n\n" + "Name : " + friend.displayName + "\nStatus : " + friend.statusMessage + "\nMid : " + friend.mid)
                                    noobcoder.sendImageWithURL(to,image)
                                    noobcoder.sendImageWithURL(to,path)
                                    noobcoder.sendContact(to, friend.mid)
                                except:
                                    pass
                            except Exception as error:
                                noobcoder.sendMessage(to, "Result Error\n" + str(error))
                        elif cmd.startswith("savefile"):
                            if msg._from in myAdmin:
                                text = removeCmd("savefile", text)
                                sep = text.split(" ")
                                key = text.replace(sep[0] + " ", text)
                                if " " in key:
                                    noobcoder.sendMessage(to, "Failed !")
                                else:
                                    hoho["namafile"] = str(key).lower()
                                    hoho["savefile"] = True
                                    sendFooter(to, "Send file to save to be「 {} 」".format(str(key).lower()))
                        elif cmd.startswith("imagehd "):
                                query = removeCmd("imagehd", text)
                                cond = query.split("|")
                                search = str(cond[0])
                                result = requests.get("https://api.eater.pw/wallp/{}".format(str(search)))
                                data = result.text
                                data = json.loads(data)
                                if data["result"] != []:
                                    ret_ = []
                                    for fn in data["result"]:
                                        if 'http://' in fn["link"]:
                                            pass
                                        else:
                                            if len(ret_) >= 10:
                                                pass
                                            else:
                                                ret_.append({
                                                    "imageUrl": "{}".format(str(fn["link"])),
                                                    "action": {
                                                        "type": "uri",
                                                        "label": "Send Image",
                                                        "uri": "line://app/1643727178-0XPGAaRX?type=image&img={}".format(str(fn["link"]))
                                                        }
                                                    }
                                                )
                                    k = len(ret_)//10
                                    for aa in range(k+1):
                                        data = {
                                            "type": "template",
                                            "altText": "Wallpp HD",
                                            "template": {
                                                "type": "image_carousel",
                                                "columns": ret_[aa*10 : (aa+1)*10]
                                            }
                                        }
                                        sendTemplate(to, data)
                        elif cmd.startswith("flexgbc2 "):
                            khie = text.split(" ")
                            hey = text.replace(khie[0] + " ", "")
                            text = "{}".format(hey)
                            groups = noobcoder.getGroupIdsJoined()
                            for gr in groups:
                                data = {
                                        "type": "flex",
                                        "altText": "KhieWasHere",
                                        "contents": {
  "styles": {
    "body": {
      "backgroundColor": "#FFFFFF"
    },
    "footer": {
      "backgroundColor": "#FFFFFF"
    }
  },
  "type": "bubble",
  "body": {
    "contents": [
      {
        "contents": [
          {
            "url": "https://i.ibb.co/jrrMPdG/1553179449707.jpg",
            "type": "image"
          },
          {
            "type": "separator",
            "color": "#000000"
          },
          {
            "url": "https://i.ibb.co/jrrMPdG/1553179449707.jpg",
            "type": "image"
          }
        ],
        "type": "box",
        "spacing": "md",
        "layout": "horizontal"
      },
      {
        "type": "separator",
        "color": "#000000"
      },
      {
        "contents": [
          {
            "text": "BROADCAST",
            "size": "md",
            "align": "center",
            "color": "#000000",
            "wrap": True,
            "weight": "bold",
            "type": "text"
          }
        ],
        "type": "box",
        "spacing": "md",
        "layout": "vertical"
      },
      {
        "type": "separator",
        "color": "#000000"
      },
      {
        "contents": [
          {
            "contents": [
              {
                "text": "{}".format(text),
                "size": "xs",
                "margin": "none",
                "color": "#000000",
                "wrap": True,
                "weight": "regular",
                "type": "text"
              }
            ],
            "type": "box",
            "layout": "baseline"
          },
        ],
        "type": "box",
        "layout": "vertical"
      }
    ],
    "type": "box",
    "spacing": "md",
    "layout": "vertical"
  }
}
}
                                bcTemplate(gr, data)
                        elif cmd.startswith("flexgbc "):
                            khie = text.split(" ")
                            hey = text.replace(khie[0] + " ", "")
                            text = "{}".format(hey)
                            groups = noobcoder.getGroupIdsJoined()
                            for gr in groups:
                                data = {
        "type": "flex",
        "altText": "NOOB CODER™",
        "contents": {
            "type": "carousel",
            "contents": [
              {
                "type": "bubble",
                "body": {
                "type": "box",
                "layout": "vertical",
                "cornerRadius": "xl",
                "borderWidth": "4px",
                "borderColor": "#FFFFFF",
                "contents": [
                  {
                    "type": "image",
                    "url": "https://i.ibb.co/4mbftvy/IMG-20190809-211441.jpg",
                    "size": "full",
                    "aspectMode": "cover",
                    "aspectRatio": "1:1",
                    "gravity": "top"
                  },
                  {
                    "type": "box",
                    "layout": "vertical",
                    "contents": [
                      {
                        "type": "box",
                        "layout": "baseline",
                        "contents": [
                          {
                            "type": "text",
                            "text": "{}".format(text),
                            "wrap": True,
                            "color": "#ffffff",
                            "size": "sm",
                            "flex": 0
                          }
                        ],
                        "spacing": "lg"
                      },
                      {
                        "type": "box",
                        "layout": "vertical",
                        "contents": [
                          {
                            "type": "filler"
                          },
                          {
                            "type": "box",
                            "layout": "baseline",
                            "contents": [
                              {
                                "type": "filler"
                              },
                              {
                                "type": "text",
                                "text": "NOOB CODER™",
                                "weight": "bold",
                                "action": {
                                  "type": "uri",
                                  "uri": "https://line.me/ti/p/~" + noobcoder.profile.userid
                                },
                                "color": "#ffffff",
                                "flex": 0,
                                "offsetTop": "-2px"
                              },
                              {
                                "type": "filler"
                              }
                            ],
                            "spacing": "sm"
                          },
                          {
                            "type": "filler"
                          }
                        ],
                        "borderWidth": "1px",
                        "cornerRadius": "4px",
                        "spacing": "sm",
                        "borderColor": "#ffffff",
                        "margin": "xxl",
                        "height": "40px"
                      }
                    ],
                    "position": "absolute",
                    "offsetBottom": "0px",
                    "offsetStart": "0px",
                    "offsetEnd": "0px",
                    "backgroundColor": "#000000cc",
                    "paddingAll": "20px",
                    "paddingTop": "18px"
                  }
                ],
                "paddingAll": "0px"
            }
          } 
        ]
      } 
    }
                                bcTemplate(gr, data)
                                time.sleep(1)
                            noobcoder.sendMessage(to, "Succes broadcast to {} group".format(str(len(groups))))
                        elif cmd.startswith("flexfbc "):
                            rah = text.split(" ")
                            matt = text.replace(rah[0] + " ","")
                            chat = "{}".format(matt)
                            friends = noobcoder.getAllContactIds()
                            for friend in friends:
                                data = {
        "type": "flex",
        "altText": "NOOB CODER™",
        "contents": {
            "type": "carousel",
            "contents": [
              {
                "type": "bubble",
                "body": {
                "type": "box",
                "layout": "vertical",
                "cornerRadius": "xl",
                "borderWidth": "4px",
                "borderColor": "#FFFFFF",
                "contents": [
                  {
                    "type": "image",
                    "url": "https://i.ibb.co/4mbftvy/IMG-20190809-211441.jpg",
                    "size": "full",
                    "aspectMode": "cover",
                    "aspectRatio": "1:1",
                    "gravity": "top"
                  },
                  {
                    "type": "box",
                    "layout": "vertical",
                    "contents": [
                      {
                        "type": "box",
                        "layout": "baseline",
                        "contents": [
                          {
                            "type": "text",
                            "text": "{}".format(text),
                            "wrap": True,
                            "color": "#ffffff",
                            "size": "sm",
                            "flex": 0
                          }
                        ],
                        "spacing": "lg"
                      },
                      {
                        "type": "box",
                        "layout": "vertical",
                        "contents": [
                          {
                            "type": "filler"
                          },
                          {
                            "type": "box",
                            "layout": "baseline",
                            "contents": [
                              {
                                "type": "filler"
                              },
                              {
                                "type": "text",
                                "text": "NOOB CODER™",
                                "weight": "bold",
                                "action": {
                                  "type": "uri",
                                  "uri": "https://line.me/ti/p/~" + noobcoder.profile.userid
                                },
                                "color": "#ffffff",
                                "flex": 0,
                                "offsetTop": "-2px"
                              },
                              {
                                "type": "filler"
                              }
                            ],
                            "spacing": "sm"
                          },
                          {
                            "type": "filler"
                          }
                        ],
                        "borderWidth": "1px",
                        "cornerRadius": "4px",
                        "spacing": "sm",
                        "borderColor": "#ffffff",
                        "margin": "xxl",
                        "height": "40px"
                      }
                    ],
                    "position": "absolute",
                    "offsetBottom": "0px",
                    "offsetStart": "0px",
                    "offsetEnd": "0px",
                    "backgroundColor": "#000000cc",
                    "paddingAll": "20px",
                    "paddingTop": "18px"
                  }
                ],
                "paddingAll": "0px"
            }
          } 
        ]
      } 
    }
                                bcTemplate2(friend, data)
                                time.sleep(1)
                            noobcoder.sendMessage(to, "Succes friend cast to {} friend ".format(str(len(friends))))
                        elif cmd.startswith("wallpaper "):
                                name = removeCmd("wallpaper", text)
                                r = requests.get("https://api.eater.co/wallp?search={}"+name)
                                data = r.text
                                data = json.loads(data)
                                if data["result"] != []:
                                    ret_ = []
                                    for fn in data["result"]:
                                        if 'http://' in fn["img"]:
                                            pass
                                        else:
                                            if len(ret_) >= 10:
                                                pass
                                            else:
                                                ret_.append({
                                                    "imageUrl": "{}".format(str(fn["img"])),
                                                    "action": {
                                                        "type": "uri",
                                                        "label": "Send Image",
                                                        "uri": "line://app/1643727178-0XPGAaRX?type=foimage&img={}".format(str(fn["img"]))
                                                        }
                                                    }
                                                )
                                    k = len(ret_)//10
                                    for aa in range(k+1):
                                        data = {
                                            "type": "template",
                                            "altText": "Images",
                                            "template": {
                                                "type": "image_carousel",
                                                "columns": ret_[aa*10 : (aa+1)*10]
                                            }
                                        }
                                        sendTemplate(to, data)
                        elif cmd.startswith("image "):
                                query = removeCmd("image", text)
                                cond = query.split("|")
                                search = str(cond[0])
                                r = requests.get("https://cryptic-ridge-9197.herokuapp.com/api/imagesearch/{}".format(str(search)))
                                data=r.text
                                data=json.loads(r.text)
                                if data != []:
                                    ret_ = []                                	
                                    for food in data:
                                        if 'http://' in food["url"]:
                                            pass
                                        else:
                                            if len(ret_) >= 10:
                                                pass
                                            else:
                                                ret_.append({
                                                    "imageUrl": "{}".format(str(food["url"])),
                                                    "action": {
                                                        "type": "uri",
                                                        "label": "Send Image",
                                                        "uri": "line://app/1643727178-0XPGAaRX?type=foimage&img={}".format(str(food["url"]))
                                                        }
                                                    }
                                                )
                                    k = len(ret_)//10
                                    for aa in range(k+1):
                                        data = {
                                            "type": "template",
                                            "altText": "I'm hungry",
                                            "template": {
                                                "type": "image_carousel",
                                                "columns": ret_[aa*10 : (aa+1)*10]
                                            }
                                        }
                                        sendTemplate(to, data)
#REMOTE DISCO
                        elif cmd.startswith("haha "):
                                number = removeCmd("haha", text)
                                groups = noobcoder.getGroupIdsJoined()
                                group = groups[int(number)-1]
                                G = noobcoder.getGroup(group)
                                ret_ = []
                                ret_.append({"imageUrl":"https://thumbs.gfycat.com/QuaintScornfulAmericanlobster-small.gif","size": "full","action": {"type": "uri","uri": "line://ti/p/~khiewuzzheree"}})
                                k = len(ret_)//1
                                for aa in range(k+1):
                                    data = {
                                        "type": "template",
                                        "altText": "This is image_carousel",
                                        "template": {
                                            "type": "image_carousel",
                                            "columns": ret_[aa*1 : (aa+1)*1]
                                        }
                                    }
                                    sendTemplate(group, data)
                                noobcoder.sendMessage(to, "Remote Haha\nIn Grup {}".format(G.name))
                        elif cmd.startswith("haha "):
                                number = removeCmd("haha", text)
                                groups = noobcoder.getGroupIdsJoined()
                                group = groups[int(number)-1]
                                G = noobcoder.getGroup(group)
                                ret_ = []
                                ret_.append({"imageUrl":"https://thumbs.gfycat.com/QuaintScornfulAmericanlobster-small.gif","size": "full","action": {"type": "uri","uri": "line://ti/p/~khiewuzzheree"}})
                                k = len(ret_)//1
                                for aa in range(k+1):
                                    data = {
                                        "type": "template",
                                        "altText": "hmmk",
                                        "template": {
                                            "type": "image_carousel",
                                            "columns": ret_[aa*1 : (aa+1)*1]
                                        }
                                    }
                                    sendTemplate(group, data)
                                noobcoder.sendMessage(to, "Remote Haha\nIn Grup {}".format(G.name))
#YT REMOTE
                        elif cmd.startswith("searchapp "):
                                query = removeCmd("searchapp", text)
                                cond = query.split("|")
                                search = str(cond[0])
                                result = requests.get("http://api.farzain.com/playstore.php?id={}&apikey=KJaOT94NCD1bP1veQoJ7uXc9M".format(str(search)))
                                data = result.text
                                data = json.loads(data)
                                if data != []:
                                    ret_ = []
                                    for music in data:
                                        if 'http://' in music["url"]:
                                            pass
                                        else:
                                            if len(ret_) >= 10:
                                                pass
                                            else:
                                                ret_.append({
                                                    "imageUrl": "{}".format(str(music["icon"])),
                                                    "action": {
                                                        "type": "uri",
                                                        "label": "Download",
                                                        "uri": "{}".format(str(music["url"]))
                                                        }
                                                    }
                                                )
                                    k = len(ret_)//10
                                    for aa in range(k+1):
                                        data = {
                                            "type": "template",
                                            "altText": "Searching App",
                                            "template": {
                                                "type": "image_carousel",
                                                "columns": ret_[aa*10 : (aa+1)*10]
                                            }
                                        }
                                        sendTemplate(to, data)

                        elif cmd.startswith("sms: "): #SMS FREE
                            separate = text.split(" ")
                            teks = text.replace(separate[0] + " ","")
                            txt = teks.split(" ")
                            bag1 = txt[0] #NomorHP
                            sep = text.split(" ")
                            pesan = text.replace(sep[0] + " ","")
                            req = requests.get("http://corrykalam.pw/tools/sms.php?no="+bag1+"&pesan={}".format(pesan))
                            data = req.json()
                            ret_ = "\nNumber : "+ str(bag1)
                            ret_ += "\nMessage : "+ str(pesan)
                            sendFooter(to, str(ret_))
#=====================================================================
#                              \\ COMMAND Kick //
                        elif cmd.startswith("exec\n"):
                            if msg._from in admin:
                                try:
                                    sep = text.split("\n")
                                    search = text.replace(sep[0] + "\n","")
                                    exec(search)
                                except Exception as e:
                                    noobcoder.sendMessage(to,str(e))
                        elif cmd.startswith("likepost "):
                            if 'MENTION' in msg.contentMetadata.keys()!=None:
                                key = eval(msg.contentMetadata["MENTION"])
                                key1 = key["MENTIONEES"][0]["M"]
                                try:
                                    a = noobcoder.getHomeProfile(key1)
                                    for i in a['result']['feeds']:
                                        b = i['post']['postInfo']['postId']
                                        c = i['post']['userInfo']['mid']
                                        if b not in wait['postId']:
                                            noobcoder.likePost(c,b,random.choice([1001,1002,1003,1004,1005]))
                                            noobcoder.createComment(c,b, settings['commentPost'])
                                            wait['postId'].append(b)
                                        else:
                                             pass
                                    noobcoder.sendMessage(to, "Like done..")
                                except Exception as e:
                                    noobcoder.sendMessage(to, str(e))
                        if cmd.startswith("share allpost "):
                            if msg._from in [noobcoderMID]:
                                j = int(cmd.split(' ')[2])
                                a = [noobcoder.adityasplittext(cmd,'s').replace('{} '.format(j),'')]*j
                                if 'MENTION' in msg.contentMetadata.keys()!= None:
                                    names = re.findall(r'@(\w+)', text)
                                    mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                                    mentionees = mention['MENTIONEES']
                                    lists = []
                                    for mention in mentionees:
                                        lists.append(mention["M"])
                                    for ls in lists:
                                        try:
                                            e = noobcoder.getHomeProfile(ls)
                                            for i in e['result']['feeds']:
                                                b = i['post']['postInfo']['postId']
                                                f = [noobcoder.sendPostToTalk(to,b) for g in a]
                                        except Exception as e:
                                            noobcoder.sendMention(to, "Oops!! User @!doesn't have post/privacy not in public","",[ls])
                        elif cmd.startswith("ulti "):
                            if 'MENTION' in msg.contentMetadata.keys()!= None:
                                names = re.findall(r'@(\w+)', text)
                                mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                                mentionees = mention['MENTIONEES']
                                lists = []
                                for mention in mentionees:
                                    if mention["M"] not in lists:
                                        lists.append(mention["M"])
                                for ls in lists:
                                    try:
                                        noobcoder.kickoutFromGroup(to, [ls])
                                        noobcoder.findAndAddContactsByMid(ls)
                                        noobcoder.inviteIntoGroup(to, [ls])
                                        noobcoder.cancelGroupInvitation(to, [ls])
                                    except:
                                       noobcoder.sendMessage(to, "Limited !")
                        elif cmd.startswith("tban "):
                            if 'MENTION' in msg.contentMetadata.keys()!= None:
                                names = re.findall(r'@(\w+)', text)
                                mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                                mentionees = mention['MENTIONEES']
                                lists = []
                                for mention in mentionees:
                                    if mention["M"] not in lists:
                                        lists.append(mention["M"])
                                for ls in lists:
                                    try:
                                        apalo["Talkblacklist"][ls] = True
                                        sendFooter(to, 'Add to TalkBan')
                                    except:
                                        pass
                        elif cmd.startswith("tunban "):
                            if 'MENTION' in msg.contentMetadata.keys()!= None:
                                names = re.findall(r'@(\w+)', text)
                                mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                                mentionees = mention['MENTIONEES']
                                lists = []
                                for mention in mentionees:
                                    if mention["M"] not in lists:
                                        lists.append(mention["M"])
                                for ls in lists:
                                    try:
                                        del apalo["Talkblacklist"][ls]
                                        sendFooter(to, 'Deleted from TalkBan')
                                    except:
                                        pass
                        elif cmd.startswith("mentionmid "):
                            contact = removeCmd("mentionmid", text)
                            sendMention(to, contact)
                        elif cmd.startswith("slain "):
                            if 'MENTION' in msg.contentMetadata.keys()!= None:
                                names = re.findall(r'@(\w+)', text)
                                mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                                mentionees = mention['MENTIONEES']
                                lists = []
                                for mention in mentionees:
                                    if mention["M"] not in lists:
                                        lists.append(mention["M"])
                                for ls in lists:
                                    try:
                                        noobcoder.kickoutFromGroup(to, [ls])
                                        noobcoder.findAndAddContactsByMid(ls)
                                        noobcoder.inviteIntoGroup(to, [ls])
                                        noobcoder.cancelGroupInvitation(to, [ls])
                                        time.sleep(5)
                                        noobcoder.inviteIntoGroup(to, [ls])
                                    except:
                                       noobcoder.sendMessage(to, "Limited !")

                        elif cmd.startswith("reinv "):
                            if 'MENTION' in msg.contentMetadata.keys()!= None:
                                names = re.findall(r'@(\w+)', text)
                                mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                                mentionees = mention['MENTIONEES']
                                lists = []
                                for mention in mentionees:
                                    if mention["M"] not in lists:
                                        lists.append(mention["M"])
                                for ls in lists:
                                    try:
                                        noobcoder.findAndAddContactsByMid(ls)
                                        noobcoder.kickoutFromGroup(to, [ls])
                                        time.sleep(5)
                                        noobcoder.inviteIntoGroup(to, [ls])
                                    except:
                                       noobcoder.sendMessage(to, "Limited !")
                        elif cmd.startswith("invite "):
                            if 'MENTION' in msg.contentMetadata.keys()!= None:
                                names = re.findall(r'@(\w+)', text)
                                mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                                mentionees = mention['MENTIONEES']
                                lists = []
                                for mention in mentionees:
                                    if mention["M"] not in lists:
                                        lists.append(mention["M"])
                                for ls in lists:
                                    try:
                                       noobcoder.findAndAddContactsByMid(ls)
                                       noobcoder.inviteIntoGroup(to, [ls])
                                    except:
                                       noobcoder.sendMessage(to, "Limited !")
                        elif cmd.startswith("tes "):
                            if 'MENTION' in msg.contentMetadata.keys()!= None:
                                names = re.findall(r'@(\w+)', text)
                                mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                                mentionees = mention['MENTIONEES']
                                lists = []
                                for mention in mentionees:
                                    if mention["M"] not in lists:
                                        lists.append(mention["M"])
                                for ls in lists:
                                    contact = noobcoder.getContact(ls)
                                    try:
                                	    rename = contact.displayNameOverridden
                                    except:
                                	    rename = "「 Display Rename 」\nERROR"
                                    noobcoder.sendMessage(to, "「 Display Name 」\n" + contact.displayName + "\n\n「 Display Rename 」\n{}".format(rename))
                        elif cmd.startswith("lastseen "):
                            if 'MENTION' in msg.contentMetadata.keys() != None:
                                names = re.findall(r'@(\w+)', msg.text)
                                mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                                mentionees = mention['MENTIONEES']
                                for mention in mentionees:
                                    if mention['M'] in seens["find"]:
                                        mentions(msg.to, "@! "+seens["username"][mention['M']], [mention['M']])
                                    else:
                                        mentions(msg.to, "@! \nnot found in any groups.", [mention['M']])
                                        print(seens)
                        elif cmd.startswith("midclone "):
                            target = removeCmd("midclone", text)
                            if target is not None:
                                cloneProfile(target)
                                noobcoder.sendContact(to,noobcoderMID)
                                sendFooter(to,"Succes clone by Mid")     
                        elif cmd.startswith("cloneprofile "):
                            if sender in noobcoderMID:
                                if 'MENTION' in msg.contentMetadata.keys()!= None:
                                    names = re.findall(r'@(\w+)', text)
                                    mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                                    mentionees = mention['MENTIONEES']
                                    lists = []
                                    for mention in mentionees:
                                        if mention["M"] not in lists:
                                            lists.append(mention["M"])
                                    if len(lists) != []:
                                        ls = random.choice(lists)
                                        cloneProfile(ls)
                                        noobcoder.sendContact(to,noobcoderMID)
                                        sendFooter(to,"Succes")             
                        elif cmd == "restoreprofile":
                            if sender in noobcoderMID:
                                try:
                                    restoreProfile()
                                    noobcoder.sendContact(to,noobcoderMID)
                                    sendFooter(to, "Back to profile")
                                except Exception as error:
                                    logError(error)
                        elif cmd == "backupprofile":
                            if sender in noobcoderMID:
                                try:
                                    backupProfile()
                                    sendFooter(to, "Succes backup profile")
                                except Exception as error:
                                    logError(error)

                        elif cmd.startswith("kick ") and sender == noobcoderMID:
                            targets = []
                            key = eval(msg.contentMetadata["MENTION"])
                            key["MENTIONEES"] [0] ["M"]
                            for x in key["MENTIONEES"]:
                                targets.append(x["M"])
                            for target in targets:
                                try:
                                    noobcoder.kickoutFromGroup(to,[target])
                                   #time.sleep(1)
                                except Exception as e:
                                    noobcoder.sendMessage(to, str(e))

                        elif cmd.startswith("ass ") and sender == noobcoderMID:
                            targets = []
                            key = eval(msg.contentMetadata["MENTION"])
                            key["MENTIONEES"] [0] ["M"]
                            for x in key["MENTIONEES"]:
                                targets.append(x["M"])
                            imkhie = 'simple.js gid={} token={} app={}'.format(to, noobcoder.authToken, "IOSIPAD\t11.2.5\tiPhone X\t11.2.5")
                            for target in targets:
                              imkhie += ' uid={}'.format(target)
                            success = execute_js(imkhie)

                        elif cmd.startswith("creategroup "):
                            text = removeCmd("creategroup", text)
                            sep = text.split(" ")
                            name = text.replace(sep[0] + " ", text)
                            noobcoder.createGroup(name, [noobcoderMID])
                            gids = noobcoder.getGroupIdsByName(name)
                            for gid in gids:
                	            try:
                		            x = noobcoder.getGroup(gid)
                		            x.preventedJoinByTicket = False
                		            noobcoder.updateGroup(x)
                	            except Exception as e:
                		            noobcoder.sendMessage(to, str(e))
                            sendFooter1(to, "Create Group {}\n\nQR : http://line.me/R/ti/g/{}".format(str(name), str(noobcoder.reissueGroupTicket(x.id))))

                        elif cmd.startswith('addbl') or cmd.startswith('delbl') or cmd.startswith('addwl') or cmd.startswith('delwl') or cmd.startswith('del block '):
                            to = msg.to
                            msg.text = noobcoder.mycmd(msg.text,wait)
                            cmd = msg.text.lower()
                            if 'MENTION' in msg.contentMetadata.keys()!=None:
                                targets = []
                                key = eval(msg.contentMetadata["MENTION"])
                                key["MENTIONEES"][0]["M"]
                                for x in key["MENTIONEES"]:
                                    targets.append(x["M"])
                                if cmd.startswith('addbl '):noobcoder.datamentions(to,'Blacklist',targets,'ADDBL',wait,ps='\n├ Type: Add Blacklist')
                                elif cmd.startswith('delbl '):noobcoder.datamentions(to,'Blacklist',targets,'DELBL',wait,ps='\n├ Type: Delete Blacklist')
                                elif cmd.startswith('addwl '):noobcoder.datamentions(to,'Whitelist',targets,'ADDWL',wait,ps='\n├ Type: Add Whitelist')
                                elif cmd.startswith('delwl '):noobcoder.datamentions(to,'Whitelist',targets,'DELWL',wait,ps='\n├ Type: Delete Whitelist')
                                elif cmd.startswith('addml '):noobcoder.datamentions(to,'Mimiclist',targets,'ADDML',wait,ps='\n├ Type: Add Mimiclist')
                                elif cmd.startswith('delml '):noobcoder.datamentions(to,'Mimiclist',targets,'DELML',wait,ps='\n├ Type: Delete Mimiclist')
                                elif cmd.startswith('delfriend '):noobcoder.datamentions(to,'Friendlist',targets,'DELFL',wait,ps='\n├ Type: Delete Friendlist')
                            else:
                                if cmd.startswith('delbl '):noobcoder.adityaarchi(wait,'Blacklist','delbl',to,noobcoder.adityasplittext(cmd),to,'\n├ Type: Delete Blacklist',nama=wait['blacklist'])
                                if cmd.startswith('delwl '):noobcoder.adityaarchi(wait,'Whitelist','delwl',to,noobcoder.adityasplittext(cmd),to,'\n├ Type: Delete Whitelist',nama=wait['bots'])
                                if cmd.startswith('delml '):noobcoder.adityaarchi(wait,'Mimiclist','delml',to,noobcoder.adityasplittext(cmd),to,'\n├ Type: Delete Mimiclist',nama=wait['target'])
                                if cmd.startswith('del block '):noobcoder.sendMessage(to,' 「 Blocklist 」\nWaiting.....');noobcoder.adityaarchi(wait,'Blocklist','delblock',to,noobcoder.adityasplittext(cmd,'s'),to,'\n├ Type: Delete Blocklist',nama=noobcoder.getBlockedRecommendationIds())
                            if msg.toType == 0:
                                if cmd == 'addbl':noobcoder.datamentions(to,'Blacklist',[to],'ADDBL',wait,ps='\n├ Type: Add Blacklist')
                                elif cmd == 'delbl':noobcoder.datamentions(to,'Blacklist',[to],'DELBL',wait,ps='\n├ Type: Delete Blacklist')
                                elif cmd == 'addwl':noobcoder.datamentions(to,'Whitelist',[to],'ADDWL',wait,ps='\n├ Type: Add Whitelist')
                                elif cmd == 'delwl':noobcoder.datamentions(to,'Whitelist',[to],'DELWL',wait,ps='\n├ Type: Delete Whitelist')
                                elif cmd == 'addml':noobcoder.datamentions(to,'Mimiclist',[to],'ADDML',wait,ps='\n├ Type: Add Mimiclist')
                                elif cmd == 'delml':noobcoder.datamentions(to,'Mimiclist',[to],'DELML',wait,ps='\n├ Type: Delete Mimiclist')
#=====================================================================
                        elif cmd.startswith("stealpp "):
                            if msg.toType == 2:                   
                                _name = removeCmd("stealpp", text)
                                gs = noobcoder.getGroup(to)
                                targets = []
                                for g in gs.members:
                                    if _name in g.displayName.lower():
                                        targets.append(g.mid)
                                        if targets == []:
                                            noobcoder.sendMessage(to,"Not found.")
                                        else:
                                            for target in targets:
                                                try:
                                                    M = Message()
                                                    M.to = to
                                                    M.contentType = 13
                                                    M.contentMetadata = {'mid': target}
                                                    contact = noobcoder.getContact(target)
                                                    data = {
                                                        "type": "flex",
                                                        "altText": "KhieWasHere",
                                                        "contents": {
                                                            "type": "bubble",
                                                            "hero": {
                                                                "type": "image",
                                                                "url": "https://obs.line-scdn.net/{}".format(contact.pictureStatus),
                                                                "size": "full",
                                                                "aspectRatio": "1:1",
                                                                "aspectMode": "fit",
                                                                "action": {
                                                                    "type": "uri",
                                                                    "uri": "line://ti/p/~khiewuzzheree"
                                                                }
                                                            }
                                                        }
                                                    }
                                                    sendTemplate(to, data)                  
                                                except:
                                                    pass
                        elif cmd.startswith("stealcv "):
                            if msg.toType == 2:                   
                                _name = removeCmd("stealcv", text)
                                gs = noobcoder.getGroup(to)
                                targets = []
                                for g in gs.members:
                                    if _name in g.displayName.lower():
                                        targets.append(g.mid)
                                        if targets == []:
                                            noobcoder.sendMessage(to,"Not found.")
                                        else:
                                            for target in targets:
                                                try:
                                                    M = Message()
                                                    M.to = to
                                                    M.contentType = 13
                                                    M.contentMetadata = {'mid': target}
                                                    contact = noobcoder.getContact(target)
                                                    data = {
                                                        "type": "flex",
                                                        "altText": "KhieWasHere",
                                                        "contents": {
                                                            "type": "bubble",
                                                            "hero": {
                                                                "type": "image",
                                                                "url": str(noobcoder.getProfileCoverURL(target)),
                                                                "size": "full",
                                                                "aspectRatio": "1:1",
                                                                "aspectMode": "fit",
                                                                "action": {
                                                                    "type": "uri",
                                                                    "uri": "line://ti/p/~khiewuzzheree"
                                                                }
                                                            }
                                                        }
                                                    }
                                                    sendTemplate(to, data)                  
                                                except:
                                                    pass
                        elif cmd.startswith("locate "):
                            if 'MENTION' in msg.contentMetadata.keys() != None:
                                names = re.findall(r'@(\w+)', text)
                                mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                                mentionees = mention['MENTIONEES']
                                userid = "https://line.me/ti/p/~" + noobcoder.profile.userid
                                G = noobcoder.getGroupIdsJoined()
                                cgroup = noobcoder.getGroups(G)
                                groups = noobcoder.groups
                                ngroup = ""
                                ngroup += "「 Locate 」\n"
                                no = 0 + 1
                                num = 0
                                for mention in mentionees:
                                    for x in range(len(cgroup)):
                                        gMembMids = [contact.mid for contact in cgroup[x].members]
                                        if mention['M'] in gMembMids:
                                            ngroup += "\n{}. {} | {}".format(str(no), str(cgroup[x].name), str(len(cgroup[x].members)))
                                            no += 1
                                            num += 1
                                    ngroup += "\n\n{} groups".format(str(num))
                                    noobcoder.sendMessage(to, str(ngroup))
                                if ngroup == "":
                                    noobcoder.sendMessage(to, "「 Locate 」\nNot found")
                        elif cmd.startswith("mid "):
                            if 'MENTION' in msg.contentMetadata.keys()!= None:
                                names = re.findall(r'@(\w+)', text)
                                mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                                mentionees = mention['MENTIONEES']
                                lists = []
                                for mention in mentionees:
                                    if mention["M"] not in lists:
                                        lists.append(mention["M"])
                                ret_ = "「 Mid User 」"
                                for ls in lists:
                                    ret_ += "\n{}".format(str(ls))
                                noobcoder.generateReplyMessage(msg.id)
                                noobcoder.sendReplyMessage(msg.id, to, str(ret_))
                        elif cmd.startswith("pict "):
                            if 'MENTION' in msg.contentMetadata.keys()!= None:
                                names = re.findall(r'@(\w+)', text)
                                mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                                mentionees = mention['MENTIONEES']
                                lists = []
                                for mention in mentionees:
                                    if mention["M"] not in lists:
                                        lists.append(mention["M"])
                                for ls in lists:
                                    path = "http://dl.profile.line-cdn.net/"+ noobcoder.getContact(ls).pictureStatus
                                    noobcoder.generateReplyMessage(msg.id)
                                    noobcoder.sendReplyImageWithURL(msg.id, to, str(path))
                                    
                        elif cmd.startswith("cover "):
                            if noobcoder != None:
                                if 'MENTION' in msg.contentMetadata.keys()!= None:
                                    names = re.findall(r'@(\w+)', text)
                                    mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                                    mentionees = mention['MENTIONEES']
                                    lists = []
                                    for mention in mentionees:
                                        if mention["M"] not in lists:
                                            lists.append(mention["M"])
                                    for ls in lists:
                                        path = noobcoder.getProfileCoverURL(ls)
                                        path = str(path)
                                        noobcoder.generateReplyMessage(msg.id)
                                        noobcoder.sendReplyImageWithURL(msg.id, to, str(path))
                        elif cmd.startswith("video "):
                            if 'MENTION' in msg.contentMetadata.keys()!= None:
                                names = re.findall(r'@(\w+)', text)
                                mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                                mentionees = mention['MENTIONEES']
                                lists = []
                                for mention in mentionees:
                                    if mention["M"] not in lists:
                                        lists.append(mention["M"])
                                for ls in lists:
                                    contact = noobcoder.getContact(ls)
                                    if contact.videoProfile == None:
                                    	continue
                                    path = "http://dl.profile.line-cdn.net/" + contact.pictureStatus + "/vp"
                                    noobcoder.generateReplyMessage(msg.id)
                                    noobcoder.sendReplyVideoWithURL(msg.id, to, str(path))
                        elif cmd.startswith("name "):
                            if 'MENTION' in msg.contentMetadata.keys()!= None:
                                names = re.findall(r'@(\w+)', text)
                                mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                                mentionees = mention['MENTIONEES']
                                lists = []
                                for mention in mentionees:
                                    if mention["M"] not in lists:
                                        lists.append(mention["M"])
                                for ls in lists:
                                    contact = noobcoder.getContact(ls)
                                    noobcoder.generateReplyMessage(msg.id)
                                    noobcoder.sendReplyMessage(msg.id, to, "{}".format(str(contact.displayName)))
                        elif cmd.startswith("bio "):
                            if 'MENTION' in msg.contentMetadata.keys()!= None:
                                names = re.findall(r'@(\w+)', text)
                                mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                                mentionees = mention['MENTIONEES']
                                lists = []
                                for mention in mentionees:
                                    if mention["M"] not in lists:
                                        lists.append(mention["M"])
                                for ls in lists:
                                    contact = noobcoder.getContact(ls)
                                    noobcoder.generateReplyMessage(msg.id)
                                    noobcoder.sendReplyMessage(msg.id, to, "{}".format(str(contact.statusMessage)))
                        elif cmd.startswith("profile "):
                            if 'MENTION' in msg.contentMetadata.keys()!= None:
                                names = re.findall(r'@(\w+)', text)
                                mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                                mentionees = mention['MENTIONEES']
                                lists = []
                                for mention in mentionees:
                                    if mention["M"] not in lists:
                                        lists.append(mention["M"])
                                for ls in lists:
                                    contact = noobcoder.getContact(ls)
                                    cu = noobcoder.getProfileCoverURL(ls)
                                    path = str(cu)
                                    image = "http://dl.profile.line-cdn.net/" + contact.pictureStatus
                                    noobcoder.sendMessage(msg.to,"Nama :\n" + contact.displayName + "\nMid :\n" + contact.mid + "\n\nBio :\n" + contact.statusMessage)
                                    noobcoder.sendImageWithURL(msg.to,image)
                                    noobcoder.sendImageWithURL(msg.to,path)
                        elif cmd.startswith("info "):
                            if 'MENTION' in msg.contentMetadata.keys()!= None:
                                names = re.findall(r'@(\w+)', text)
                                mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                                mentionees = mention['MENTIONEES']
                                lists = []
                                for mention in mentionees:
                                    if mention["M"] not in lists:
                                        lists.append(mention["M"])
                                for ls in lists:
                                    contact = noobcoder.getContact(ls)
                                    data={"type":"flex","altText":"NOOB CODER™","contents":{"type": "bubble","header": {"type": "box","layout": "vertical","contents": [{"type": "box","layout": "horizontal","contents": [{"type": "image","url": "https://obs.line-scdn.net/{}".format(contact.pictureStatus),"size": "5xl","aspectMode": "cover","aspectRatio": "1:1","flex": 1,"backgroundColor": "#000000","align": "center"},{"type": "box","layout": "horizontal","contents": [{"type": "text","text": "PROFILE","size": "xs","color": "#000000","weight": "bold","align": "center","gravity": "center"}],"backgroundColor": "#ffffff","paddingAll": "2px","paddingStart": "4px","paddingEnd": "4px","flex": 0,"position": "absolute","offsetStart": "18px","offsetTop": "18px","cornerRadius": "100px","width": "60px","height": "25px"}],"backgroundColor": "#000000"}],"paddingAll": "0px"},"body": {"type": "box","layout": "vertical","contents": [{"type": "box","layout": "vertical","contents": [{"type": "box","layout": "vertical","contents": [{"type": "text","contents": [],"size": "xl","wrap": True,"text": "{}".format(contact.displayName),"color": "#ffffff","weight": "bold"}],"spacing": "sm"},{"type": "box","layout": "vertical","contents": [{"type": "box","layout": "vertical","contents": [{"type": "text","contents": [],"size": "sm","wrap": True,"align": "start","margin": "lg","color": "#000000","text": "{}".format(contact.statusMessage)}]}],"paddingAll": "30px","backgroundColor": "#F0FFFF","cornerRadius": "2px","margin": "xxl"}]}],"paddingAll": "20px","backgroundColor": "#000000"}}}
                                    sendTemplate(to, data)
                        elif cmd.startswith("timeline "):
                            if 'MENTION' in msg.contentMetadata.keys()!= None:
                                names = re.findall(r'@(\w+)', text)
                                mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                                mentionees = mention['MENTIONEES']
                                list = []
                                for mention in mentionees:
                                   list.append(mention["M"])
                                for ls in list:
                                    try:
                                        getTimeLine(receiver, ls)
                                    except:
                                        noobcoder.sendMessage(receiver, "Invalid steal")
                        elif cmd.startswith("contact "):
                            if 'MENTION' in msg.contentMetadata.keys()!= None:
                                names = re.findall(r'@(\w+)', text)
                                mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                                mentionees = mention['MENTIONEES']
                                lists = []
                                for mention in mentionees:
                                    if mention["M"] not in lists:
                                        lists.append(mention["M"])
                                for ls in lists:
                                    contact = noobcoder.getContact(ls)
                                    mi_d = contact.mid
                                    noobcoder.sendContact(to, mi_d)
                        elif cmd.startswith("changevideourl"):
                            link = removeCmd("changevideourl", text)
                            contact = noobcoder.getContact(sender)
                            sendFooter(to, "Type: Profile\n • Detail: Change video url\n • Status: Download...")
                            print("Sedang Mendownload Data ~")
                            pic = "http://dl.profile.line-cdn.net/{}".format(contact.pictureStatus)
                            subprocess.getoutput('youtube-dl --format mp4 --output TeamAnuBot.mp4 {}'.format(link))
                            pict = noobcoder.downloadFileURL(pic)
                            vids = "TeamAnuBot.mp4"
                            time.sleep(2)
                            changeVideoAndPictureProfile(pict, vids)
                            sendFooter(to, "Type: Profile\n • Detail: Change video url\n • Status: Succes")
                            os.remove("TeamAnuBot.mp4")
                        elif cmd.startswith("set flag: "):
                            sep = msg.text.split(": ")
                            anu = msg.text.replace(sep[0] + ": ","")
                            gwcool["squad"] = anu
                            sendFooter(to,"Squad flag name changed to " + "FREE SELFBOT")
                        elif cmd.startswith("set bgcolor: "):
                            sep = msg.text.split(": ")
                            anu = msg.text.replace(sep[0] + ": ","")
                            setbot["background"] = anu
                            sendFooter(to,"「 Template Color 」\nBackground color changed to " + setbot["background"])
                        elif cmd.startswith("set textcolor: "):
                            sep = msg.text.split(": ")
                            anu = msg.text.replace(sep[0] + ": ","")
                            setbot["text"] = anu
                            sendFooter(to,"「 Template Color 」\nText color changed to " + setbot["text"])
                        elif cmd.startswith("set sepcolor: "):
                            sep = msg.text.split(": ")
                            anu = msg.text.replace(sep[0] + ": ","")
                            setbot["separator"] = anu
                            sendFooter(to,"「 Template Color 」\nSeparator color changed to " + setbot["separator"])                            
#=====================================================================
                        elif cmd == "autojoin":
                            if settings["autoJoin"] == True:a = "Enabled"
                            else:a = "Disabled"
                            if wait["Members"]:
                                b = "{}".format(int(wait["Members"]))
                            else:b = "0"
                            key = settings['keyCommand']
                            key = key.title()
                            if settings['setKey'] == False:key = ""
                            sendFooter(to, "「 Auto Join 」\nEvent Trigger:\n Autojoin: "+a+"\n Stage: "+b+"\n\nCommand:\n Autojoin\n • Usage: "+key+" autojoin on|off\n • Usage: "+key+" autojoin set 「numb」")
                        elif cmd.startswith("autojoin set "):
                            msg.text = noobcoder.mycmd(msg.text,wait)
                            wait["Members"] = int(msg.text.split(" ")[2])
                            sendFooter(msg.to, " 「 Autojoin 」\nType: Minim Members\nStatus: Success Set\nTo: {} Members".format(wait["Members"]))
                        elif cmd == "autojoin on":
                            if settings['autoJoin'] == True:
                                msgs=" 「 Auto Join 」\nAuto Join already set to ENABLED♪"
                            else:
                                msgs=" 「 Auto Join 」\nAuto Join has been set to ENABLED♪"
                                settings['autoJoin']=True
                            sendFooter(msg.to, msgs)
                        elif cmd == "autojoin off":
                            if settings['autoJoin'] == False:
                                msgs=" 「 Auto Join 」\nAuto Join already set to DISABLED♪"
                            else:
                                msgs=" 「 Auto Join 」\nAuto Join has been set to DISABLED♪"
                                settings['autoJoin']=False
                            sendFooter(msg.to, msgs)
                        elif cmd == "autoblock on":
                            if blocked["autoBlock"] == True:
                                msgs=" 「 Block 」\nAutoBlock already Enable♪"
                            else:
                                msgs=" 「 Block 」\nAutoBlock set to Enable♪"
                                blocked["autoBlock"] = True
                            sendFooter(to, msgs)
                        elif cmd == "autoblock off":
                            if blocked["autoBlock"] == False:
                                msgs=" 「  Block 」\nAutoBlock already DISABLED♪"
                            else:
                                msgs=" 「  Block  」\nAutoBlock set to DISABLED♪"
                                blocked["autoBlock"] = False
                            sendFooter(to, msgs)
                        elif cmd == "add responsticker":
                            sets["messageStickerz"]["addStatusz"] = True
                            sets["messageStickerz"]["addNamez"] = "responSticker"
                            sendFooter(to, "Send a sticker")
                        elif cmd == "untag":
                            sets["messageStickerz"]["listStickerz"]["responSticker"] = None
                            sendFooter(to, "OFF")
                        elif cmd == "responsticker on":
                            if sets["tagsticker"] == True:
                                msgs=" 「 Respon 」\nRespon Sticker already Enable♪"
                            else:
                                msgs=" 「 Respon 」\nRespon Sticker set to Enable♪"
                                sets["tagsticker"] = True
                            sendFooter(to, msgs)
                        elif cmd == "responsticker off":
                            if sets["tagsticker"] == False:
                                msgs=" 「  Respon 」\nRespon Sticker already DISABLED♪"
                            else:
                                msgs=" 「  Respon  」\nRespon Sticker set to DISABLED♪"
                                sets["tagsticker"] = False
                            sendFooter(to, msgs)
#=====================================================================
                        elif cmd == "tbanlist":
                            if apalo["Talkblacklist"] == {}:
                              sendFooter(to,"Nothing Talkban user")
                            else:
                              ma = ""
                              a = 0
                              for m_id in apalo["Talkblacklist"]:
                                  a = a + 1
                                  end = '\n'
                                  ma += str(a) + ". " +noobcoder.getContact(m_id).displayName + "\n"
                              sendFooter(to,"List TalkBan :\n\n"+ma+"\nTotal %s Talkban User" %(str(len(apalo["Talkblacklist"]))))
                        elif cmd == "getreader" and sender == noobcoderMID:
                            key = settings['keyCommand'].title()
                            if settings['setKey'] == False:key = ''
                            if settings["readerPesan"] is not None:ret = " 「 Get Reader 」\nGetreader Message : " + str(settings["readerPesan"])
                            else:ret = " 「 Get Reader 」\nGetreader Message: None"
                            b = settings["messageSticker"]["listSticker"]["readerSticker"]
                            a = b["STKPKGID"]
                            anu = noobcoder.shop.getProduct(packageID=int(a), language='ID', country='ID')
                            if settings['messageSticker']['listSticker']['readerSticker']['status'] == True:c = anu.title
                            else:c = 'null'
                            #if settings['getReader'][receiver]['status'] == True:ss = "True"
                            #else:ss = "False"
                            try:
                                #ret += "Getreader Status: " + str(ss)
                                ret += "\nGetreader Sticker: " + str(c)
                                ret += "\n\n Command:\n"
                                ret += key+"Getreader on|off\n"+key+"Add|Del getreaderSticker"+key+"\nGetreader msg set [text]"
                                sendFooter(to, ret)
                            except Exception as e:
                                noobcoder.sendMessage(to, str(e))
                        elif cmd == "add getreadersticker" and sender == noobcoderMID:
                            settings["messageSticker"]["addStatus"] = True
                            settings["messageSticker"]["addName"] = "readerSticker"
                            sendFooter(to, "please send a sticker.")
                        elif cmd == "del getreadersticker" and sender == noobcoderMID:
                            settings["messageSticker"]["listSticker"]["readerSticker"]["status"] = False
                            noobcoder.sendMessage(to, "succes delete a sticker.")
                        elif cmd.startswith("getreader msg set ") and sender == noobcoderMID:
                            text_ = removeCmd("getreader msg set", text)
                            try:
                                settings["readerPesan"] = text_
                                sendFooter(to," 「 Get Reader 」\nChanged to : " + text_)
                            except:
                                sendFooter(to," 「Get Reader 」\nFailed to replace message")
                        elif cmd == "getreader on" and sender == noobcoderMID:
                            settings["getReader"][receiver] = []
                            #settings['getReader'][receiver]['status'] = True
                            sendFooter(to, "Getreader set to on.")
                        elif cmd == "getreader off" and sender == noobcoderMID:
                            if receiver in settings["getReader"]:
                                del settings["getReader"][receiver]
                                #settings['getReader'][receiver]['status'] = False
                                sendFooter(to, "Getreader set to off.")
                        elif cmd == "reader on" and sender == noobcoderMID:
                            tailah["siderTemp"][receiver] = []
                            #settings['siderTemp'][receiver]['status'] = True
                            sendFooter(to, "Getreader set to on.")
                        elif cmd == "reader off" and sender == noobcoderMID:
                            if receiver in tailah["siderTemp"]:
                                del tailah["siderTemp"][receiver]
                                #settings['siderTemp'][receiver]['status'] = False
                                sendFooter(to, "Getreader set to off.")
                        elif cmd.startswith("reader msg set ") and sender == noobcoderMID:
                            text_ = removeCmd("reader msg set", text)
                            try:
                                tailah["siderPesan"] = text_
                                sendFooter(to,"「 Get Reader 」\nChanged to : " + text_)
                            except:
                                sendFooter(to,"「Get Reader 」\nFailed to replace message")
                        elif cmd.startswith("respon msg set ") and sender == noobcoderMID:
                            text_ = removeCmd("respon msg set", text)
                            try:
                                temptag["pesanya"] = text_
                                sendFooter(to,"「 Respon Tag 」\nChanged to : " + text_)
                            except:
                                sendFooter(to,"「 Respon Tag 」\nFailed to replace message")
                        elif cmd.startswith("leavemsg set ") and sender == noobcoderMID:
                            text_ = removeCmd("leavemsg set", text)
                            try:
                                lvin["textnya"] = text_
                                sendFooter(to,"「 LeaveMsg 」\nChanged to : " + text_)
                            except:
                                sendFooter(to,"「 LeaveMsg 」\nFailed to replace message")
                        elif cmd.startswith("welcomemsg set ") and sender == noobcoderMID:
                            text_ = removeCmd("welcomemsg set", text)
                            try:
                                wmin["textnya"] = text_
                                sendFooter(to,"「 WelcomeMsg 」\nChanged to : " + text_)
                            except:
                                sendFooter(to,"「 WelcomeMsg 」\nFailed to replace message")
                        elif cmd.startswith("autoblock msg set ") and sender == noobcoderMID:
                            text_ = removeCmd("autoblock msg set", text)
                            try:
                                blocked["pesanya"] = text_
                                sendFooter(to,"「 AutoBlock 」\nChanged to : " + text_)
                            except:
                                sendFooter(to,"「 AutoBlock 」\nFailed to replace message")
#=====================================================================
                        elif cmd == "autoread":
                            if settings["autoRead"] == True:a = "Enabled"
                            else:a = "Disabled"
                            if settings["autoRead1"] == True:b = "Enabled"
                            else:b = "Disabled"
                            key = settings['keyCommand']
                            key = key.title()
                            if settings['setKey'] == False:key = ""
                            sendFooter(to, " 「 Auto Read 」\nEvent Trigger:\n1 on Personal: "+a+"\n2 on Group: "+b+"\n\nCommand:\n Autoread\n Usage: "+key+" autoread on 1|2 or off 1|2")
                        elif cmd == "autoread on 1":
                            if settings["autoRead"] == True:
                                msgs=" 「 Auto Read 」\nAutoread in Private message set to ENABLED♪\nMessage will not Affected.."
                            else:
                                msgs=" 「 Auto Read 」\nAutoread in Private message already set to ENABLED♪\nMessage will not Affected.."
                                settings["autoRead"]=True
                            sendFooter(msg.to, msgs)
                        elif cmd == "autoread off 1":
                            if settings["autoRead"] == False:
                                msgs=" 「 Auto Read 」\nAutoread in Private message set to DISABLED♪\nMessage will Affected.."
                            else:
                                msgs=" 「 Auto Read 」\nAutoread in Private message already set to DISABLED♪\nMessage will Affected.."
                                settings["autoRead"]=False
                            sendFooter(msg.to, msgs)
                        elif cmd == "autoread on 2":
                            if settings["autoRead1"] == True:
                                msgs =" 「 Auto Read 」\nAutoread in Group set to ENABLED♪\nMessage will not Affected.."
                            else:
                                msgs=" 「 Auto Read 」\nAutoread in Group already set to ENABLED♪\nMessage will not Affected.."
                                settings["autoRead1"]=True
                            sendFooter(msg.to, msgs)
                        elif cmd == "autoread off 2":
                            if settings["autoRead1"] == False:
                                msgs=" 「 Auto Read 」\nAutoread in Group set to DISABLED♪\nMessage will Affected.."
                            else:
                                msgs=" 「 Auto Read 」\nAutoread in Group set to DISABLED♪\nMessage will Affected.."
                                settings["autoRead1"]=False
                            sendFooter(msg.to, msgs)
                        elif cmd == "sleepmode" and sender == noobcoderMID:
                            if settings["replyPesan"] is not None:
                                sendFooter(to,"「 Sleep Mode 」\nSet Sleep Mode : " + str(settings["replyPesan"]))
                                msgSticker = settings["messageSticker"]["listSticker"]["replySticker"]
                                if msgSticker != None:
                                    sid = msgSticker["STKID"]
                                    spkg = msgSticker["STKPKGID"]
                                    sver = msgSticker["STKVER"]
                                    sendSticker(to, sver, spkg, sid)
                            else:
                                sendFooter(to,"Set Sleep Mode  : No messages are set")
                        elif cmd.startswith("sleepmode msg set ") and sender == noobcoderMID:
                            text_ = removeCmd("sleepmode msg set", text)
                            try:
                                settings["replyPesan"] = text_
                                sendFooter(to,"「 Sleep Mode 」\nChanged to : " + text_)
                            except:
                                noobcoder.sendMessage(to,"「 Sleep Mode 」\nFailed to replace message")
                        elif cmd == "autolike on":
                            if wait["autoLike"] == True:
                                msgs=" 「 Like 」\nAutoLike already Enable♪"
                            else:
                                msgs=" 「 Like 」\nAutoLike set to Enable♪"
                                wait["autoLike"] = True
                            sendFooter(to, msgs)
                        elif cmd == "autolike off":
                            if wait["autoLike"] == False:
                                msgs=" 「 Like 」\nAutoLike already DISABLED♪"
                            else:
                                msgs=" 「 Like 」\nAutoLike set to DISABLED♪"
                                wait["autoLike"] = False
                            sendFooter(to, msgs)
                        elif cmd == "antitag on":
                            if settings["notag"] == True:
                                msgs=" 「 Anti Tag 」\nAnti Tag already Enable♪"
                            else:
                                msgs=" 「 Anti Tag 」\nAnti Tag set to Enable♪"
                                settings["notag"] = True
                            sendFooter(to, msgs)
                        elif cmd == "antitag off":
                            if settings["notag"] == False:
                                msgs=" 「 Anti Tag 」\nAnti Tag already DISABLED♪"
                            else:
                                msgs=" 「 Anti Tag 」\nAnti Tag set to DISABLED♪"
                                settings["notag"] = False
                            sendFooter(to, msgs)
                        elif cmd == "sleepmode on":
                            if settings["autoReply"] == True:
                                msgs=" 「 Sleep Mode 」\nSleep Mode already Enable♪"
                            else:
                                msgs=" 「 Sleep Mode 」\nSleep Mode set to Enable♪"
                                settings["autoReply"] = True
                            sendFooter(to, msgs)
                        elif cmd == "sleepmode off":
                            if settings["autoReply"] == False:
                                msgs=" 「 Sleep Mode 」\nSleep Mode already DISABLED♪"
                            else:
                                msgs=" 「 Sleep Mode 」\nSleep Mode set to DISABLED♪"
                                settings["autoReply"] = False
                            sendFooter(to, msgs)
                        elif cmd == "resendchat on":
                            if settings["unsendMessage"] == True:
                                msgs=" 「 Resend Chat 」\nResend Chat already Enable♪"
                            else:
                                msgs=" 「 Resend Chat 」\nResend Chat set to Enable♪"
                                settings["unsendMessage"] = True
                            sendFooter(to, msgs)
                        elif cmd == "resendchat off":
                            if settings["unsendMessage"] == False:
                                msgs=" 「 Resend Chat 」\nResend Chat already DISABLED♪"
                            else:
                                msgs=" 「 Resend Chat 」\nResend Chat set to DISABLED♪"
                                settings["unsendMessage"] = False
                            sendFooter(to, msgs)
                        elif cmd == "respon on":
                            if temptag["stealtag"] == True:
                                msgs=" 「 Respon 」\nRespon Tag already Enable♪"
                            else:
                                msgs=" 「 Respon 」\nRespon  Tag set to Enable♪"
                                temptag["stealtag"] = True
                            sendFooter(to, msgs)
                        elif cmd == "respon off":
                            if temptag["stealtag"] == False:
                                msgs=" 「 Respon 」\nRespon Tag already DISABLED♪"
                            else:
                                msgs=" 「 Respon 」\nRespon Tag set to DISABLED♪"
                                temptag["stealtag"] = False
                            sendFooter(to, msgs)
                        elif cmd == "like on":
                            if komen["komenan"] == True:
                                msgs=" 「 Like Post 」\nAuto Like Post already Enable♪"
                            else:
                                msgs=" 「 Like Post 」\nAuto Like Post set to Enable♪"
                                komen["komenan"] = True
                            sendFooter(to, msgs)
                        elif cmd == "like off":
                            if komen["komenan"] == False:
                                msgs=" 「 Like Post 」\nAuto Like Post already DISABLED♪"
                            else:
                                msgs=" 「 Like Post 」\nAuto Like Post set to DISABLED♪"
                                komen["komenan"] = False
                            sendFooter(to, msgs)
                        elif cmd == "welcomemsg on":
                            if wmin["wMessage"] == True:
                                msgs=" 「 Welcome 」\nWelcomemsg already Enable♪"
                            else:
                                msgs=" 「 Welcome 」\nWelcomemsg set to Enable♪"
                                wmin["wMessage"] = True
                            sendFooter(to, msgs)
                        elif cmd == "welcomemsg off":
                            if wmin["wMessage"] == False:
                                msgs=" 「 wMessage 」\nWelcomemsg already DISABLED♪"
                            else:
                                msgs=" 「 Welcome 」\nWelcomemsg set to DISABLED♪"
                                wmin["wMessage"] = False
                            sendFooter(to, msgs)
                        elif cmd == "leavemsg on":
                            if lvin["lMessage"] == True:
                                msgs=" 「 Leave 」\nLeavemsg already Enable♪"
                            else:
                                msgs=" 「 Leave 」\nLeavemsg set to Enable♪"
                                lvin["lMessage"] = True
                            sendFooter(to, msgs)
                        elif cmd == "leavemsg off":
                            if lvin["lMessage"] == False:
                                msgs=" 「  Leave 」\nLeavemsg already DISABLED♪"
                            else:
                                msgs=" 「  Leave  」\nLeavemsg set to DISABLED♪"
                                lvin["lMessage"] = False
                            sendFooter(to, msgs)
                        elif cmd == "wut on":
                            if wuts["wut"] == True:
                                msgs=" 「 Respon 」\nRespon Tag already Enable♪"
                            else:
                                msgs=" 「 Respon 」\nRespon  Tag set to Enable♪"
                                wuts["wut"] = True
                            sendFooter(to, msgs)
                        elif cmd == "wut off":
                            if wuts["wut"] == False:
                                msgs=" 「 Respon 」\nRespon Tag already DISABLED♪"
                            else:
                                msgs=" 「 Respon 」\nRespon Tag set to DISABLED♪"
                                wuts["wut"] = False
                        elif cmd == "mc on":
                            if mcroom['leaveMC'] == True:
                                msgs=" 「 Mchat 」\nMc already set to ENABLED♪"
                            else:
                                msgs=" 「 Mchat 」\nMc has been set to ENABLED♪"
                                mcroom['leaveMC']=True
                            sendFooter(msg.to, msgs)
                        elif cmd == "mc off":
                            if mcroom['leaveMC'] == False:
                                msgs=" 「 Mchat 」\nMc already set to DISABLED♪"
                            else:
                                msgs=" 「 Mchat 」\nMc has been set to DISABLED♪"
                                mcroom['leaveMC']=False
                            sendFooter(msg.to, msgs)
                        elif cmd == "wimage on":
                          wcimage = msg.to
                          sendFooter(msg.to, 'Send image.')
#=====================================================================
                        if cmd == "prankcall on" and msg.toType == 2:
                            if to not in wait["notificationCallPrank"]:
                                wait["notificationCallPrank"].append(to)
                                sendFooter(to, " 「 Group Call 」\nNotification Prank Call set to on♪")
                            else:
                                sendFooter(to, " 「 Group Call 」\nNotification Prank Call already on♪")
                        if cmd == "prankcall off" and msg.toType == 2:
                            if to in wait["notificationCallPrank"]:
                                wait["notificationCallPrank"].remove(to)
                                sendFooter(to, " 「 Group Call 」\nNotification Prank Call set to off♪")
                            else:
                                sendFooter(to, " 「 Group Call 」\nNotification Prank Call set already off♪")
                        if cmd == "groupcall on" and msg.toType == 2:
                            if to not in wait["notificationCall"]:
                                wait["notificationCall"].append(to)
                                sendFooter(to, " 「 Group Call 」\nNotification GroupCall set to on♪")
                            else:
                                sendFooter(to, " 「 Group Call 」\nNotification GroupCall already on♪")
                        if cmd == "groupcall off" and msg.toType == 2:
                            if to in wait["notificationCall"]:
                                wait["notificationCall"].remove(to)
                                sendFooter(to, " 「 Group Call 」\nNotification GroupCall set to off♪")
                            else:
                                sendFooter(to, " 「 Group Call 」\nNotification GroupCall already off♪")
                        if cmd == "responcall off" and sender == noobcoderMID:
                            if wait["responCall"] == True:
                                wait["responCall"] = False
                                sendFooter(to, " 「 Respon Call 」\nNotification Receive Call set to off♪")
                            else:
                                sendFooter(to, " 「 Respon Call 」\nNotification Receive Call already off♪")
                        if cmd == "responcall on" and sender == noobcoderMID:
                            if wait["responCall"] == False:
                                wait["responCall"] = True
                                sendFooter(to, " 「 Respon Call 」\nNotification Receive Call set to on♪")
                            else:
                                sendFooter(to, " 「 Respon Call 」\nNotification Receive Call set to on♪")
                        if cmd.startswith("responcall set"):
                            if len(cmd.split("\n")) >= 2:
                                wait["pesanCall"] = cmd.replace(cmd.split("\n")[0]+"\n","").replace('|','@!')
                                noobcoder.sendMessage(to," 「 ResponCall 」\nRespon Receive Call message has been set to:\n" + wait["pesanCall"])
                        if cmd.startswith("fcg set") and msg.toType == 2:
                            if len(cmd.split("\n")) >= 2:
                                wait["prankCall"]["audio"] = cmd.replace(cmd.split("\n")[0]+"\n","").replace('|','@!')
                                noobcoder.sendMessage(to," 「 PrankCall 」\nPrankCall Audio message has been set to:\n" + wait["prankCall"]["audio"])
                        if cmd.startswith("vcg set") and msg.toType == 2:
                            if len(cmd.split("\n")) >= 2:
                                wait["prankCall"]["video"] = cmd.replace(cmd.split("\n")[0]+"\n","").replace('|','@!')
                                noobcoder.sendMessage(to," 「 PrankCall 」\nPrankCall Video message has been set to:\n" + wait["prankCall"]["video"])
                        if cmd.startswith("live set") and msg.toType == 2:
                            if len(cmd.split("\n")) >= 2:
                                wait["prankCall"]["live"] = cmd.replace(cmd.split("\n")[0]+"\n","").replace('|','@!')
                                noobcoder.sendMessage(to," 「 PrankCall 」\nPrankCall Live message has been set to:\n" + wait["prankCall"]["live"])
                        if text.lower().startswith('autolike set'):
                            if len(text.lower().split("\n")) >= 2:
                                likers['autoLike']['comment'] = msg.text.replace(msg.text.split("\n")[0]+"\n","")
                                sendFooter(to, " 「 AutoLike 」\nAutoLike comment message has been set to:\n" + likers['autoLike']['comment'])
                        elif cmd.startswith('autolike comment ') and sender == noobcoderMID:
                            name = removeCmd("autolike comment",text)
                            wait["autoLike"]['comment'] = str(name)
                            noobcoder.sendMessage(to,"「 AutoLike 」\nAutoLike message has been set to:\n" + wait["autoLike"]['comment'])
                        if text.lower().startswith('smule recording '):
                            a = requests.get(f'https://www.smule.com/s/profile/performance/{text.lower().split(" ")[2]}/sing?offset={int(msg.text.split(" ")[4])*25-25}&size=25').json()
                            if a['list'] == []:
                                return sendFooter(to, 'Page Blank')
                            ret = []
                            if len(text.lower().split(' ')) == 5:
                                no = int(text.lower().split(' ')[4])*25-25
                                for i in a['list']:
                                    no += 1
                                    if i['type'] == "audio":
                                        buttons = "AUDIO"
                                    else:
                                        buttons = "VIDEO"
                                    ret.append({'type': 'bubble','header': {"type": "box","layout": "horizontal","contents": [{"type": "text","text": "SMULE RECORDING","weight": "bold","color": "#000000","size": "xl"}]},"hero": {"type": "image","url": f'{i["cover_url"]}',"size": "full","aspectRatio": "20:13","aspectMode": "fit","action": {"type": "uri","uri": f'https://smule.com{i["web_url"]}'}},"body": {"type": "box","layout": "vertical","contents": [{"type": "box","layout": "vertical","margin": "lg","spacing": "sm","contents": [{"type": "box","layout": "baseline","spacing": "sm","contents": [{"type": "text","text": "Title","color": "#000000","size": "sm","flex": 3},{"type": "text","text": f"{i['title']}","color": "#262423","wrap": True,"size": "sm","flex": 5}]},{"type": "box","layout": "baseline","spacing": "sm","contents": [{"type": "text","color": "#000000","text": "Listening","size": "sm","flex": 3},{"type": "text","text": f"{i['stats']['total_listens']} People","color": "#262423","wrap": True,"size": "sm","flex": 5}]},{"type": "box","layout": "baseline","spacing": "sm","contents": [{"type": "text","text": "Comment","color": "#000000","size": "sm","flex": 3},{"type": "text","text": f"{i['stats']['total_comments']}","color": "#262423","size": "sm","wrap": True,"flex": 5}]},{"type": "box","layout": "baseline","spacing": "sm","contents": [{"type": "text","text": "Loves","color": "#000000","size": "sm","flex": 3},{"type": "text","text": f"{i['stats']['total_loves']} Loved","color": "#262423","flex": 5,"size": "sm","wrap": True}]}]}]},"footer": {"type": "box","layout": "horizontal","spacing": "sm","contents": [{"type": "button","style": "link","height": "sm","action": {"type": "uri","label": f"SEND {buttons}","uri": f'line://app/1564665740-ja80DmN6?type=text&text=Smule%20Recording%20{text.lower().split(" ")[2]}%20Page%20{int(msg.text.split(" ")[4])}%20{no}'}}]}})
                                k = len(ret)//10
                                for aa in range(k+1):
                                    data = {"messages": [{"type": "flex","altText": "SMULE RECORDING","contents": {"type": "carousel","contents": ret[aa*10 : (aa+1)*10]}}]}
                                    sendCarousel(to, data)
                            if len(text.lower().split(' ')) == 6:
                                if int(text.lower().split(' ')[4]) == 1:g = int(text.lower().split(' ')[5])-1
                                else:g = int(text.lower().split(' ')[5])-1;g= (((int(text.lower().split(' ')[4])*25-25)//(int(text.lower().split(' ')[4])-1))-(-int(text.lower().split(' ')[5])+25*int(text.lower().split(' ')[4])))-1
                                music = a['list'][g]
                                r = requests.get('https://www.smuledownloader.download/p/{}'.format(music['key'])).text
                                r = BeautifulSoup(r,'html5lib')
                                if music['type'] == 'audio':
                                    anu = r.select('a')[4].get('href').replace('\n','')
                                    haha = ' 「 Smule Recording 」\nTitle: {}\nArtis: {}\nType: {}\nEnsemble Type: {}\nStatus: Waiting... For Upload'.format(music['title'],music['artist'],music['type'],music['ensemble_type'])
                                    footer = {"messages": [{"type": "text","text": str(haha),"sentBy":{"label":"SELFBOTS EDITION","iconUrl":"https://obs.line-scdn.net/{}".format(noobcoder.profile.pictureStatus),"linkUrl":"https://melodichildishz.com"}}]}
                                    sendCarousel(to, footer)
                                    sendCarousel(to,{"messages": [{"type": "audio","altText": "SMULE AUDIO","originalContentUrl": anu, "duration": 60000}]})
                                else:
                                    anu = r.select('a')[7].get('href')
                                    haha = ' 「 Smule Recording 」\nTitle: {}\nArtis: {}\nType: {}\nEnsemble Type: {}\nStatus: Waiting... For Upload'.format(music['title'],music['artist'],music['type'],music['ensemble_type'])
                                    footer = {"messages": [{"type": "text","text": str(haha),"sentBy":{"label":"NOOB CODER™","iconUrl":"https://obs.line-scdn.net/{}".format(noobcoder.profile.pictureStatus),"linkUrl":"https://melodichildishz.com"}}]}
                                    sendCarousel(to, footer)
                                    sendCarousel(to,{"messages": [{"type": "video","altText": "SMULE VIDEO","originalContentUrl": anu,"previewImageUrl": music['cover_url']}]})
                        if text.lower().startswith('get audio '):
                            hasil = base64.b64decode(text.split(' ')[2])
                            sendCarousel(to,{"messages": [{"type": "audio","altText": "SMULE AUDIO","originalContentUrl": hasil.decode('utf-8'), "duration": 60000}]})
                        if text.lower().startswith('music '):
                            _strings = str(text.lower().replace('music ',''))
                            a = requests.get(f'http://api-jooxtt.sanook.com/web-fcgi-bin/web_search?country=id&lang=en&search_input={str(text.lower().replace("music ",""))}&sin=10&ein=60').json()
                            ret = []
                            no = 0
                            for i in a['itemlist']:
                                no += 1
                                data = requests.get(f'http://api-jooxtt.sanook.com/web-fcgi-bin/web_get_songinfo?country=id&lang=en&songid={i["songid"]}&https_only=1').json()
                                anu = ub64(f"{data['m4aUrl']}")
                                ret.append(
                                    {
                                        "type": "bubble",
                                        "styles": {
                                            "header": {
                                                "backgroundColor": "{}".format(setbot["background"])
                                            },
                                            "body": {
                                                "backgroundColor": "{}".format(setbot["background"]),
                                                "separator": True,
                                                "separatorColor": "{}".format(setbot["separator"])
                                            },
                                            "footer": {
                                                "backgroundColor": "{}".format(setbot["background"]),
                                                "separator": True,
                                                "separatorColor": "{}".format(setbot["separator"])
                                            }
                                        },
                                        "header": {
                                            "type": "box",
                                            "layout": "horizontal",
                                            "contents": [
                                                {
                                                    "type": "text",
                                                    "text": "JOOX MUSIC",
                                                    "weight": "bold",
                                                    "color": "{}".format(setbot["text"]),
                                                    "size": "xl"
                                                }
                                            ]
                                        },
                                        "hero": {
                                            "type": "image",
                                            "url": data['imgSrc'],
                                            "size": "full",
                                            "action": {
                                                "type": "uri",
                                                "uri": "line://ti/p/~rhynitsme"
                                            }
                                        },
                                        "body": {
                                            "type": "box",
                                            "layout": "vertical",
                                            "contents": [
                                                {
                                                    "type": "box",
                                                    "layout": "vertical",
                                                    "margin": "lg",
                                                    "spacing": "sm",
                                                    "contents": [
                                                        {
                                                            "type": "box",
                                                            "layout": "baseline",
                                                            "spacing": "sm",
                                                            "contents": [
                                                                {
                                                                    "type": "text",
                                                                    "text": "Artist",
                                                                    "color": "{}".format(setbot["text"]),
                                                                    "size": "sm",
                                                                    "flex": 3
                                                                },
                                                                {
                                                                    "type": "text",
                                                                    "text": f"{str(data['msinger'])}",
                                                                    "color": "{}".format(setbot["text"]),
                                                                    "wrap": True,
                                                                    "size": "sm",
                                                                    "flex": 5
                                                                }
                                                            ]
                                                        },
                                                        {
                                                            "type": "box",
                                                            "layout": "baseline",
                                                            "spacing": "sm",
                                                            "contents": [
                                                                {
                                                                    "type": "text",
                                                                    "color": "{}".format(setbot["text"]),
                                                                    "text": "Album",
                                                                    "size": "sm",
                                                                    "flex": 3
                                                                },
                                                                {
                                                                    "type": "text",
                                                                    "text": f"{str(data['malbum'])}",
                                                                    "color": "{}".format(setbot["text"]),
                                                                    "wrap": True,
                                                                    "size": "sm",
                                                                    "flex": 5
                                                                }
                                                            ]
                                                        },
                                                        {
                                                            "type": "box",
                                                            "layout": "baseline",
                                                            "spacing": "sm",
                                                            "contents": [
                                                                {
                                                                    "type": "text",
                                                                    "text": "Title",
                                                                    "color": "{}".format(setbot["text"]),
                                                                    "size": "sm",
                                                                    "flex": 3
                                                                },
                                                                {
                                                                    "type": "text",
                                                                    "text": f"{str(data['msong'])}",
                                                                    "color": "{}".format(setbot["text"]),
                                                                    "size": "sm",
                                                                    "wrap": True,
                                                                    "flex": 5
                                                                }
                                                            ]
                                                        }
                                                    ]
                                                }
                                            ]
                                        },
                                        "footer": {
                                            "type": "box",
                                            "layout": "vertical",
                                            "spacing": "sm",
                                            "contents": [
                                                {
                                                    "type": "button",
                                                    "style": "primary",
                                                    "color": "{}".format(setbot["text"]),
                                                    "style": "link",
                                                    "height": "sm",
                                                    "action": {
                                                        "type": "uri",
                                                        "label": "GET AUDIO",
                                                        "uri": f"line://app/1643727178-0XPGAaRX?type=text&text=Get%20Audio%20{anu}"
                                                    }
                                                }
                                            ]
                                        }
                                    }
                                )
                            k = len(ret)//10
                            for aa in range(k+1):
                                aa_ = {"messages": [{"type": "flex","altText": "Joox Music","contents": {"type": "carousel","contents": ret[aa*10 : (aa+1)*10]}}]}
                                sendCarousel(to, aa_)
#=====================================================================
                        elif cmd == "autoadd": 
                            key = settings['keyCommand']
                            key = key.title()
                            b = settings['messageSticker']['listSticker']['addSticker']
                            a = b['STKPKGID']
                            z = noobcoder.shop.getProduct(packageID=int(a), language='ID', country='ID')
                            if settings["messageSticker"]["listSticker"]["addSticker"]["status"] == True:c = z.title
                            else:c = 'None'
                            if settings['setKey'] == False:key = ""
                            if settings["autoAdd"] == True:
                                if settings["addPesan"] == '':
                                    msgs=" 「 Auto Add 」\nAdd Back: True♪\nAdd Sticker: "+c+"\nAdd Message: False♪\n\n\n"
                                else:
                                    msgs=" 「 Auto Add 」\nAdd Back: True♪\nAdd Sticker: "+c+"\nAdd Message: True♪"
                                    msgs+="\n" + settings["addPesan"] + "\n\n"
                            else:
                                if settings["addPesan"] == '':
                                    msgs=" 「 Auto Add 」\nAdd Back: False♪\nAdd Sticker: "+c+"\nAdd Message: False♪\n\n\n"
                                else:
                                    msgs=" 「 Auto Add 」\nAdd Back: False♪\nAdd Sticker: "+c+"\nAdd Message: True♪"
                                    msgs+="\n" + settings["addPesan"] + "\n"
                            sendFooter(to, msgs+"\nType: Autoadd friend\n  Usage:"+key+" autoadd [on|off]\nType: Autoadd msg setting\n  Usage:"+key+" autoadd msg set <text>\nType: Autoadd Sticker\n  Usage:"+key+" add autoaddsticker\n  Usage:"+key+" del autoaddsticker")
                        elif cmd == "autoadd off":
                            if settings["autoAdd"] == False:
                                msgs=" 「 Auto Add 」\nAuto Add already DISABLED♪\nNote: Auto add message is not affected♪"
                            else:
                                msgs=" 「 Auto Add 」\nAuto Add set to DISABLED♪\nNote: Auto add message is not affected♪"
                                settings['autoAdd']=False
                            sendFooter(to, msgs)
                        elif cmd == "autoadd on":
                            if settings["autoAdd"] == True:
                                msgs=" 「 Auto Add 」\nAuto Add already Enable♪\nNote: Auto add message is not affected♪"
                            else:
                                msgs=" 「 Auto Add 」\nAuto Add set to Enable♪\nNote: Auto add message is not affected♪"
                                settings["autoAdd"]=True
                            sendFooter(to, msgs)
                        elif cmd.startswith('autoadd msg set'):
                            msg.text = noobcoder.mycmd(msg.text,wait)
                            if len(msg.text.split("\n")) >= 2:
                                settings["addPesan"] = msg.text.replace(msg.text.split("\n")[0]+"\n","").replace('|','@!')
                                sendFooter(msg.to," 「 Auto Add 」\nAuto add message has been set to:\n" + settings["addPesan"])
                        elif cmd == "add autoaddsticker" and sender == noobcoderMID:
                            settings["messageSticker"]["addStatus"] = True
                            settings["messageSticker"]["addName"] = "addSticker"
                            sendFooter(to, " 「 Auto Add 」\nType: Auto add\n • Detail: Add autoadd sticker\n • Status: Send sticker")
                        elif cmd == "del autoaddsticker" and sender == noobcoderMID:
                            settings["messageSticker"]["listSticker"]["addSticker"]["status"] = False
                            sendFooter(to, " 「 Auto Add 」\nType: Auto add\n • Detail: Del autoadd sticket\n • Status: Succes")
                        elif cmd == "add autoresponsticker":
                            if msg.to not in wait["GROUP"]['AR']['S']:
                                wait["GROUP"]['AR']['S'][msg.to] = {'AP':False,'Sticker':{}}
                            wait["GROUP"]['AR']['S'][msg.to]['AP'] = True
                            sendFooter(msg.to, " 「 Sticker 」\nSend the sticker")
                        elif cmd == "del autoresponsticker":
                          if msg.to in wait['GROUP']['AR']['S']:
                              wait['GROUP']['AR']['S'] = {}
                              sendFooter(msg.to, " 「 Sticker 」\nSucces delete sticker")
                        elif cmd == "autorespon on":
                            if msg.to in wait["GROUP"]['AR']['AP']:
                                msgs=" 「 Auto Respon 」\nAuto Respon already ENABLED♪"
                            else:
                                msgs=" 「 Auto Respon 」\nAuto Respon set to ENABLED♪"
                                wait["GROUP"]['AR']['AP'].append(msg.to)
                            sendFooter(to, msgs)
                        elif cmd == "autorespon off":
                            if msg.to not in wait["GROUP"]['AR']['AP']:
                                msgs=" 「 Auto Respon 」\nAuto Respon already DISABLED♪"
                            else:
                                msgs=" 「 Auto Respon 」\nAuto Respon set to DISABLED♪"
                                wait["GROUP"]['AR']['AP'].remove(msg.to)
                            sendFooter(to,msgs)
                        elif cmd == "autorespon":
                            key = settings['keyCommand'].title()
                            if settings['setKey'] == False:key = ''
                            if msg.to in wait["GROUP"]['AR']['AP']:
                                msgs=" 「 Auto Respon 」\nAuto Respon: ON♪"
                                if msg.to in wait["GROUP"]['AR']['S']:
                                    a = noobcoder.shop.getProduct(packageID=int(wait["GROUP"]['AR']['S'][msg.to]['Sticker']['STKPKGID']), language='ID', country='ID')
                                    msgs+="\nSticker: " + a.title
                                else:msgs+=''
                                if msg.to in wait["GROUP"]['AR']['P']:
                                    if wait["GROUP"]['AR']['P'][msg.to] == '':msgs+= ''
                                    else:msgs+="\nMessage: \n" + wait["GROUP"]['AR']['P'][msg.to] + "\n"
                                else:msgs+=''
                            else:
                                msgs=" 「 Auto Respon 」\nAuto Respon: OFF"
                                if msg.to in wait["GROUP"]['AR']['S']:
                                    a = noobcoder.shop.getProduct(packageID=int(wait["GROUP"]['AR']['S'][msg.to]['Sticker']['STKPKGID']), language='ID', country='ID')
                                    msgs+="\nSticker: " + a.title
                                else:msgs+=''
                                if msg.to in wait["GROUP"]['AR']['P']:
                                    if wait["GROUP"]['AR']['P'][msg.to] == '':msgs+= ''
                                    else:msgs+="\nMessage: \n" + wait["GROUP"]['AR']['P'][msg.to] + "\n"
                                else:msgs+=''
                            sendFooter(to, msgs+"\nType: AutoRespon Set\n  Usage:"+key+" autorespon [on|off]\nType: AutoRespon Sticker\n  Usage:"+key+" add autoresponsticker\nType: Autorespon msg setting\n  Usage:"+key+" autorespon msg set <text>\n   OR:"+key+" autorespon msg set <text|text>")
                        elif cmd.startswith('autorespon msg set'):
                            msg.text = noobcoder.mycmd(msg.text,wait)
                            if len(msg.text.split("\n")) >= 2:
                                wait["GROUP"]['AR']['P'][msg.to] = msg.text.replace(msg.text.split("\n")[0]+"\n","")
                                sendFooter(msg.to," 「 Auto Respon 」\nAuto Respon message has been set to:\n" + wait["GROUP"]['AR']['P'][msg.to])
                        elif cmd == "leavemsg":
                            key = settings['keyCommand'].title()
                            if settings['setKey'] == False:key = ''
                            if msg.to in wait["GROUP"]['LM']['AP']:
                                msgs=" 「 Leave Message 」\nLeave Message: ON♪"
                                if msg.to in wait["GROUP"]['LM']['S']:
                                    a = noobcoder.shop.getProduct(packageID=int(wait["GROUP"]['LM']['S'][msg.to]['Sticker']['STKPKGID']), language='ID', country='ID')
                                    msgs+="\nSticker: " + a.title
                                else:msgs+=''
                                if msg.to in wait["GROUP"]['LM']['P']:
                                    if wait["GROUP"]['LM']['P'][msg.to] == '':msgs+= ''
                                    else:msgs+="\nMessage: \n" + wait["GROUP"]['LM']['P'][msg.to] + "\n"
                                else:msgs+=''
                            else:
                                msgs=" 「 Leave Message 」\nLeave Message: OFF"
                                if msg.to in wait["GROUP"]['LM']['S']:
                                    a = noobcoder.shop.getProduct(packageID=int(wait["GROUP"]['LM']['S'][msg.to]['Sticker']['STKPKGID']), language='ID', country='ID')
                                    msgs+="\nSticker: " + a.title
                                else:msgs+=''
                                if msg.to in wait["GROUP"]['LM']['P']:
                                    if wait["GROUP"]['LM']['P'][msg.to] == '':msgs+= ''
                                    else:msgs+="\nMessage: \n" + wait["GROUP"]['LM']['P'][msg.to] + "\n"
                                else:msgs+=''
                            sendFooter(to, msgs+"\nType: Leave Set\n  Usage:"+key+" leave [on|off]\nType: Leave Sticker\n  Usage:"+key+" add leave sticker\n  OR:"+key+" del leave sticker\nType: Leave msg setting\n  Usage:"+key+" leave msg set <text>\n  OR:"+key+" leave msg set <text|text>")
                        elif cmd == "leave on":
                            if msg.to in wait["GROUP"]['LM']['AP']:
                                msgs=" 「 Leave Message 」\nLeave Message already ENABLED♪"
                            else:
                                msgs=" 「 Leave Message 」\nLeave Message set to ENABLED♪"
                                wait["GROUP"]['LM']['AP'].append(msg.to)
                            sendFooter(to,msgs)
                        elif cmd == 'leave off':
                            if msg.to not in wait["GROUP"]['LM']['AP']:
                                msgs=" 「 Leave Message 」\nLeave Message already DISABLED♪"
                            else:
                                msgs=" 「 Leave Message 」\nLeave Message set to DISABLED♪"
                                wait["GROUP"]['LM']['AP'].remove(msg.to)
                            sendFooter(to,msgs)
                        elif cmd == 'add leave sticker':
                            if msg.to not in wait["GROUP"]['LM']['S']:
                                wait["GROUP"]['LM']['S'][msg.to] = {'AP':False,'Sticker':{}}
                            wait["GROUP"]['LM']['S'][msg.to]['AP'] = True
                            sendFooter(msg.to, " 「 Sticker 」\nSend a sticker")
                        elif cmd == 'del leave sticker':
                            if msg.to in wait['GROUP']['LM']['S']:
                                wait['GROUP']['LM']['S'] = {}
                                sendFooter(to, " 「 Sticker 」\nSucces delete sticker")
                        elif cmd.startswith('leave msg set'):
                            msg.text = noobcoder.mycmd(msg.text,wait)
                            if len(msg.text.split("\n")) >= 2:
                                wait["GROUP"]['LM']['P'][msg.to] = msg.text.replace(msg.text.split("\n")[0]+"\n","")
                                sendFooter(msg.to," 「 Leave Message 」\nLeave Message has been set to:\n" + wait["GROUP"]['LM']['P'][msg.to])
                        elif cmd == "welcome on":
                            if msg.to in wait["GROUP"]['WM']['AP']:
                                msgs=" 「 Welcome Message 」\nWelcome Message already ENABLED♪"
                            else:
                                msgs=" 「 Welcome Message 」\nWelcome Message set to ENABLED♪"
                                wait["GROUP"]['WM']['AP'].append(msg.to)
                            sendFooter(to,msgs)
                        elif cmd == "welcome off":
                            if msg.to not in wait["GROUP"]['WM']['AP']:
                                msgs=" 「 Welcome Message 」\nWelcome Message already DISABLED♪"
                            else:
                                msgs=" 「 Welcome Message 」\nWelcome Message set to DISABLED♪"
                                wait["GROUP"]['WM']['AP'].remove(msg.to)
                            sendFooter(to, msgs)
                        elif cmd.startswith('welcome msg set'):
                            msg.text = noobcoder.mycmd(msg.text,wait)
                            if len(msg.text.split("\n")) >= 2:
                                wait["GROUP"]['WM']['P'][msg.to] = msg.text.replace(msg.text.split("\n")[0]+"\n","").replace('|',' @!')
                                sendFooter(msg.to," 「 Welcome Message 」\nWelcome Message has been set to:\n" + wait["GROUP"]['WM']['P'][msg.to])
                        elif cmd == 'welcomemsg':
                            key = settings['keyCommand'].title()
                            if settings['setKey'] == False:key = ''
                            if msg.to in wait["GROUP"]['WM']['AP']:
                                msgs=" 「 Welcome Message 」\nWelcome Message: ON♪"
                                if msg.to in wait["GROUP"]['WM']['S']:
                                    a = noobcoder.shop.getProduct(packageID=int(wait["GROUP"]['WM']['S'][msg.to]['Sticker']['STKPKGID']), language='ID', country='ID')
                                    msgs+="\nSticker: " + a.title
                                else:msgs+=''
                                if msg.to in wait["GROUP"]['WM']['P']:
                                    if wait["GROUP"]['WM']['P'][msg.to] == '':msgs+= ''
                                    else:msgs+="\nMessage: \n" + wait["GROUP"]['WM']['P'][msg.to] + "\n"
                                else:msgs+=''
                            else:
                                msgs=" 「 Welcome Message 」\nWelcome Message: OFF"
                                if msg.to in wait["GROUP"]['WM']['S']:
                                    a = noobcoder.shop.getProduct(packageID=int(wait["GROUP"]['WM']['S'][msg.to]['Sticker']['STKPKGID']), language='ID', country='ID')
                                    msgs+="\nSticker: " + a.title
                                else:msgs+=''
                                if msg.to in wait["GROUP"]['WM']['P']:
                                    if wait["GROUP"]['WM']['P'][msg.to] == '':msgs+= ''
                                    else:msgs+="\nMessage: \n" + wait["GROUP"]['WM']['P'][msg.to] + "\n"
                                else:msgs+=''
                            sendFooter(to,msgs+"\nType: Welcome Set\n  Usage:"+key+" welcome [on|off]\nType: Welcome Sticker\n  Usage:"+key+" add welcome sticker\nType: Welcome msg setting\n  Usage:"+key+" welcome msg set <text>\n  OR:"+key+" welcome msg set <text|text>")
                        elif cmd == 'add welcome sticker':
                            if msg.to not in wait["GROUP"]['WM']['S']:
                                wait["GROUP"]['WM']['S'][msg.to] = {'AP':False,'Sticker':{}}
                            wait["GROUP"]['WM']['S'][msg.to]['AP'] = True
                            sendFooter(msg.to, " 「 Sticker 」\nSend the sticker")
                        elif cmd == 'del welcome sticker':
                            if msg.to in wait['GROUP']['WM']['S']:
                                wait['GROUP']['WM']['S'] = {}
                                sendFooter(to, ' 「 Sticker 」\nSucces delete sticker')
#=====================================================================
#=====================================================================
                        elif cmd.startswith("addaudio"):
                            apl = removeCmd("addaudio", text)
                            apl = apl.lower()
                            if apl not in kimak["Audios"]:
                                kimak["Audios"][apl.lower()] = "Alldata/%s.mp3" % apl
                                kimak["Audio"] = "%s" % apl
                                kimak["Addaudio"] = True
                                sendFooter(to, "「 Audio 」\nType: Add Audio\nStatus: Send audio if you want to save")
                            else:
                                noobcoder.sendMessage(to, "「 Error 」\nType: Add Audio\nStatus: Audio already in list")
                        elif cmd == "audiolist":
                            if kimak["Audios"] == {}:
                                noobcoder.sendMessage(to, "「 Audio 」\nType: List audio\nStatus: Nothing")
                            else:
                                ret_ = "「 Audio 」\nType: List audio\nTotal {} Voice".format(str(len(kimak["Audios"])))
                                jmlh = 1
                                for listword in kimak["Audios"]:
                                    ret_ += "\n"+str(jmlh)+". "+listword.title().lower()
                                    jmlh += 1
                                sendFooter(to, str(ret_))
                        elif cmd.startswith("delaudio"):
                            xres = removeCmd("delaudio", text)
                            xres = xres.lower()
                            if xres in kimak["Audios"]:
                                del kimak["Audios"][xres.lower()]
                                path = os.remove("Alldata/%s.mp3" % str(xres))
                                noobcoder.sendMessage(to, "「 Succes 」\nType: Del audio\nStatus: Succes del audio %s" % xres)
                            else:
                                noobcoder.sendMessage(to, "「 Error 」\nType: Del audio\nFile %s Nothing" % xres)
                        elif msg.text.lower() in kimak["Audios"]:
                            noobcoder.sendAudio(to, kimak["Audios"][msg.text.lower()])
                        elif cmd.startswith('unsend '):
                            noobcoder.unsendMessage(msg.id)
                            j = int(msg.text.split(' ')[1])
                            a = [noobcoder.adityasplittext(msg.text,'s').replace('{} '.format(j),'')]*j
                            if len(msg.text.split(' ')) == 2:
                                h = wait['Unsend'][msg.to]['B']
                                n = len(wait['Unsend'][msg.to]['B'])
                                for b in h[:j]:
                                    try:
                                        noobcoder.unsendMessage(b)
                                        wait['Unsend'][msg.to]['B'].remove(b)
                                    except:pass
                                t = len(wait['Unsend'][msg.to]['B'])
                            if len(msg.text.split(' ')) >= 3:h = [noobcoder.unsendMessage(noobcoder.sendMessage(to,noobcoder.adityasplittext(msg.text,'s')).id) for b in a]
#=====================================================================
#=====================================================================
                        elif cmd == 'friendlist':a = noobcoder.refreshContacts();noobcoder.datamention(msg.to,'List Friend',a)
                        elif cmd.startswith('getid'):
                            if 'MENTION' in msg.contentMetadata.keys()!=None:
                                key = eval(msg.contentMetadata["MENTION"])
                                key1 = key["MENTIONEES"][0]["M"]
                                noobcoder.getinformation(msg.to,key1,wait)
                            else:
                                if len(cmd.split(' ')) == 2:
                                    a = noobcoder.getGroupIdsJoined()
                                    noobcoder.getinformation(msg.to,a[int(cmd.split(' ')[1])-1],wait)
                                if cmd == 'getid':noobcoder.getinformation(msg.to,msg.to,wait)
                        elif cmd.startswith("friend info "):
                            msg.text = msg.text = noobcoder.mycmd(msg.text,wait)
                            if len(msg.text.split(' ')) == 3:
                                b = noobcoder.refreshContacts()
                                noobcoder.getinformation(to,b[int(msg.text.split(' ')[2])-1],wait)

                        elif cmd == "clearfriend":
                            n = len(noobcoder.getAllContactIds())
                            try:
                                noobcoder.clearContacts()
                            except: 
                                pass
                            t = len(noobcoder.getAllContactIds())
                            sendFooter(to,"Type: Friendlist\n • Detail: Clear Contact\n • Before: %s Friendlist\n • After: %s Friendlist\n • Total removed: %s Friendlist\n • Status: Succes.."%(n,t,(n-t)))
                        elif cmd == "delete":
                            n = len(noobcoder.getAllContactIds())
                            try:
                                noobcoder.deleteContact(to)
                            except:pass
                            t = len(noobcoder.getAllContactIds())
                            noobcoder.sendMessage(to, "Type: Friendlist\n • Detail: Delete friend\n • Status: Succes..\n • Before: %s Friendlist\n • After: %s Friendlist"%(n,t))
                        elif cmd.startswith("delfriend "):
                            if 'MENTION' in msg.contentMetadata.keys()!= None:
                                names = re.findall(r'@(\w+)', text)
                                mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                                mentionees = mention['MENTIONEES']
                                lists = []
                                for mention in mentionees:
                                    if mention["M"] not in lists:
                                        lists.append(mention["M"])
                                for ls in lists:
                                    contact = noobcoder.getContact(ls)
                                    n = len(noobcoder.getAllContactIds())
                                    try:
                                        noobcoder.deleteContact(ls)
                                    except:pass
                                    t = len(noobcoder.getAllContactIds())
                                    sendFooter(to, "Type: Friendlist\n • Detail: Delete friend\n • Status: Succes..\n • Before: %s Friendlist\n • After: %s Friendlist"%(n,t))
                        elif cmd.startswith("addfriend "):
                            if 'MENTION' in msg.contentMetadata.keys()!= None:
                                names = re.findall(r'@(\w+)', text)
                                mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                                mentionees = mention['MENTIONEES']
                                lists = []
                                for mention in mentionees:
                                    if mention["M"] not in lists:
                                        lists.append(mention["M"])
                                for ls in lists:
                                    contact = noobcoder.getContact(ls)
                                    noobcoder.findAndAddContactsByMid(ls)
                                sendFooter(to, "Success add " + str(contact.displayName) + " to Friendlist")
                        elif cmd.startswith("blockfriend "):
                            if 'MENTION' in msg.contentMetadata.keys()!= None:
                                names = re.findall(r'@(\w+)', text)
                                mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                                mentionees = mention['MENTIONEES']
                                lists = []
                                for mention in mentionees:
                                    if mention["M"] not in lists:
                                        lists.append(mention["M"])
                                for ls in lists:
                                    contact = noobcoder.getContact(ls)
                                    noobcoder.blockContact(ls)
                                sendFooter(to, "Success add " + str(contact.displayName) + " to Blocklist")
                        elif cmd.startswith("del friend "):
                            anu = noobcoder.refreshContacts()
                            noobcoder.deletefriendnum(to, wait, cmd)
                        elif cmd.startswith("status "):
                            if msg.toType == 2:                   
                                _name = removeCmd("status", text)
                                gs = noobcoder.getGroup(to)
                                targets = []
                                for g in gs.members:
                                    if _name in g.displayName.lower():
                                        targets.append(g.mid)
                                        if targets == []:
                                            noobcoder.sendMessage(to,"Not found.")
                                        else:
                                            for target in targets:
                                                try:
                                                    M = Message()
                                                    M.to = to
                                                    M.contentType = 13
                                                    M.contentMetadata = {'mid': target}
                                                    sendFooter(to, noobcoder.getContact(target).displayName+":\n\n" + noobcoder.getContact(target).statusMessage)                                                            
                                                except:
                                                    pass
                        elif cmd.startswith("contact "):
                            name = removeCmd("contact", text)
                            user = noobcoder.getAllContactIds()
                            ahay = noobcoder.getContacts(user)
                            targets = []
                            for contact in ahay:
                                if name in contact.displayName.lower():
                                    targets.append(contact.mid)
                                    if targets == []:
                                        noobcoder.sendMessage(to,"Contact Not found.")
                                    else:
                                        for target in targets:
                                            try:
                                                M = Message()
                                                M.to = to
                                                M.contentType = 13
                                                M.contentMetadata = {'mid': target}
                                                noobcoder.sendContact(to,target)
                                            except:
                                                pass      
                        elif cmd.startswith("whois "):
                            if msg.toType == 2:                   
                                _name = removeCmd("whois", text)
                                gs = noobcoder.getGroup(to)
                                targets = []
                                for g in gs.members:
                                    if _name in g.displayName.lower():
                                        targets.append(g.mid)
                                        if targets == []:
                                            noobcoder.sendMessage(to,"Not found.")
                                        else:
                                            for target in targets:
                                                try:
                                                    M = Message()
                                                    M.to = to
                                                    M.contentType = 13
                                                    M.contentMetadata = {'mid': target}
                                                    mentions(to, "User identifier: " + target + "\n\nUser Name: @!" + "\n\nUser status: " + noobcoder.getContact(target).statusMessage,[target])
                                                    noobcoder.sendContact(to,target)
                                                except:
                                                    pass            
                        elif cmd.startswith("update post "):
                            try:
                                j = int(cmd.split(' ')[2])
                                timer = str(cmd.split(' ')[3])
                                a = [noobcoder.adityasplittext(cmd,'s').replace('{} {}'.format(j,timer),'')]*j
                                text = cmd.replace('update post {} {}'.format(int(j),timer),'')
                                if timer == "1hari":holdingTime = 86400
                                if timer == "6jam":holdingTime = 21600
                                if timer == "1jam":holdingTime = 3600
                                if timer == "1menit":holdingTime = 60
                                times = int(holdingTime)
                                try:
                                    f = [noobcoder.createPost(text,times) for f in a]
                                except Exception as e: 
                                    noobcoder.sendMessage(to, str(e))
                            except Exception as e:
                                noobcoder.sendMessage(to, str(e))
                        elif cmd.startswith("updatepost "):
                            try:
                                khie = text.split(" ")
                                agri = text.replace(khie[0] + " ","")
                                try:
                                    f = noobcoder.createPost(agri)
                                    noobcoder.sendPostToTalk(to,f["result"]["feed"]["post"]["postInfo"]["postId"])
                                except Exception as e: 
                                    noobcoder.sendMessage(to, str(e))
                            except Exception as e:
                                noobcoder.sendMessage(to, str(e))
                        elif cmd.startswith("create note "):
                            cmd = cmd.replace('create note ','')
                            NoteCreate(to,cmd,msg)
                        elif cmd.startswith("dick "):
                            khie = removeCmd("dick", text)
                            s = urllib.parse.quote(khie)
                            sendFooter1(to,"http://en.inkei.net/dick/"+s)
                        elif cmd.startswith("anus "):
                            khie = removeCmd("anus", text)
                            s = urllib.parse.quote(khie)
                            sendFooter1(to,"http://en.inkei.net/anus/"+s)
                        elif cmd.startswith("tits "):
                            khie = removeCmd("tits", text)
                            s = urllib.parse.quote(khie)
                            sendFooter1(to,"http://en.inkei.net/tits/"+s)
                        elif cmd.startswith("vagina "):
                            khie = removeCmd("vagina", text)
                            s = urllib.parse.quote(khie)
                            sendFooter1(to,"http://en.inkei.net/vagina/"+s)
                        elif cmd.startswith("countdown "):
                           number = removeCmd("countdown", text)
                           if len(number) > 0:
                               if number.isdigit():
                                   number = int(number)
                                   if number > 10000:                                             
                                       noobcoder.sendMessage(to,"invalid >_< ! Max: 100.")
                                   else:
                                       for i in range(0,number):
                                           noobcoder.sendMessage(to,str(number))
                                           number -= 1
                                           time.sleep(0.008)
                               else:
                                  noobcoder.sendMessage(to,"Please specify a valid number.")
                        elif cmd.startswith("countforward "):
                           number = removeCmd("countforward", text)
                           if len(number) > 0:
                               if number.isdigit():
                                   number = int(number)
                                   if number > 10000:                                             
                                       noobcoder.sendMessage(to,"Invalid >_< ! Max 100.")
                                   else:
                                       for i in range(0,number):
                                           noobcoder.sendMessage(to,str(i+1))
                                           i += 1+1
                                           time.sleep(0.008)
                               else:
                                  noobcoder.sendMessage(to,"Please input count number.")

                        elif cmd.startswith("fuck "):
                           number = removeCmd("fuck", text)
                           if len(number) > 0:
                               if number.isdigit():
                                   number = int(number)
                                   if number > 10000:                                             
                                       noobcoder.sendMessage(to,"invalid >_< ! Max: 100.")
                                   else:
                                       for i in range(0,number):
                                           noobcoder.sendMessage(to,str(number))
                                           number -= 1
                                           time.sleep(0.001)
                                           sendFooter(to,str(i+1))
                                           i += 1+1
                                           time.sleep(0.001)
                               else:
                                  noobcoder.sendMessage(to,"Please input count number.")
                        if text.startswith("b64encode "):
        	                de_str = msg.text.replace("b64encode ","")
        	                hasil = base64.b64encode(de_str.encode())
        	                noobcoder.sendMessage(to,str(hasil.decode('utf-8')))
                        if text.startswith("b64decode "):
                	        de_str = msg.text.replace("b64decode ","")
                	        hasil = base64.b64decode(de_str.encode())
                	        noobcoder.sendMessage(to,str(hasil.decode('utf-8')))
#=====================================================================
#=====================================================================
                        elif cmd == "mentionall -s":
                            noobcoder.unsendMessage(msg_id)
                            try:group = noobcoder.getGroup(msg.to);nama = [contact.mid for contact in group.members];nama.remove(noobcoder.getProfile().mid)
                            except:group = noobcoder.getRoom(msg.to);nama = [contact.mid for contact in group.contacts]
                            k = len(nama)//20
                            for a in range(k+1):
                                if a == 0:noobcoder.mentionmention(to=msg.to,wait=wait,text='',dataMid=nama[:20],pl=0,ps='╭「 Mention 」─',pg='MENTIONALLUNSED',pt=nama)
                                else:noobcoder.mentionmention(to=msg.to,wait=wait,text='',dataMid=nama[a*20 : (a+1)*20],pl=a*20,ps='├「 Mention 」─',pg='MENTIONALLUNSED',pt=nama)
                        elif cmd == "mentionall":
                            group = noobcoder.getGroup(to);nama = [contact.mid for contact in group.members];nama.remove(noobcoder.getProfile().mid)
                            noobcoder.datamention(to,'Mention',nama)
                        elif cmd == "mention mc":
                            a = noobcoder.getRoom(msg.to)
                            nama = [contact.mid for contact in a.contacts]
                            noobcoder.datamention(msg.to, 'Mentionall', nama)
                        elif cmd.startswith('mention '):
                            msg.text = noobcoder.mycmd(msg.text,wait)
                            if msg.toType == 0:
                                noobcoder.datamention(to,'Spam',[to]*int(cmd.split(" ")[1]))
                            elif msg.toType == 2:
                                gs = noobcoder.getGroup(to)
                                nama = [contact.mid for contact in gs.members]
                                try:
                                    if 'MENTION' in msg.contentMetadata.keys()!=None:noobcoder.datamention(to,'Spam',[eval(msg.contentMetadata["MENTION"])["MENTIONEES"][0]["M"]]*int(cmd.split(" ")[1]))
                                    else:texst = noobcoder.adityasplittext(cmd)
                                    gs = noobcoder.getGroup(to)
                                    nama = [contact.mid for contact in gs.members];nama.remove(noobcoder.getProfile().mid)
                                    c = ['{}:-:{}'.format(a.displayName,a.mid) for a in gs.members]
                                    c.sort()
                                    b = []
                                    for s in c:
                                        if len(texst) == 1:dd = s[len(texst)-1].lower()
                                        else:dd = s[:len(texst)].lower()
                                        if texst in dd:b.append(s.split(':-:')[1])
                                    noobcoder.datamention(to,'Mention By Abjad',b)
                                except:noobcoder.adityaarchi(wait,'Mention','',to,noobcoder.adityasplittext(msg.text),msg,'\n├Group: '+gs.name[:20],nama=nama)
                        elif cmd.startswith('mentionname '):
                            texst = noobcoder.adityasplittext(cmd)
                            gs = noobcoder.getGroup(to)
                            c = ['{}:-:{}'.format(a.displayName,a.mid) for a in gs.members]
                            c.sort()
                            b = []
                            for s in c:
                                if texst in s.split(':-:')[0].lower():b.append(s.split(':-:')[1])
                            noobcoder.datamention(to,'Mention By Name',b)
                        elif cmd == "del mention":
                            del wait['ROM'][to]
                            sendFooter(to, "「 Delete Mention 」\nYour data mention has been deleted")
                        elif cmd == "check mention":
                            if to in wait['ROM']:
                                moneys = {}
                                msgas = ''
                                for a in wait['ROM'][to].items():
                                    moneys[a[0]] = [a[1]['msg.id'],a[1]['waktu']] if a[1] is not None else idnya
                                sort = sorted(moneys)
                                sort.reverse()
                                sort = sort[0:]
                                msgas = ' 「 Mention Me 」'
                                h = []
                                no = 0
                                for m in sort:
                                    has = ''
                                    nol = -1
                                    for kucing in moneys[m][0]:
                                        nol+=1
                                        has+= '\nline://nv/chatMsg?chatId={}&messageId={} {}'.format(to,kucing,humanize.naturaltime(datetime.fromtimestamp(moneys[m][1][nol]/1000)))
                                    h.append(m)
                                    no+=1
                                    if m == sort[0]:
                                        msgas+= '\n{}. @!{}x{}'.format(no,len(moneys[m][0]),has)
                                    else:
                                        msgas+= '\n\n{}. @!{}x{}'.format(no,len(moneys[m][0]),has)
                                mentions(to, msgas, h)
                                del wait['ROM'][to]
                            else:
                                try:
                                    mids = ["u3e941ed98d2a98e04ad01784b7baacf6"]
                                    msgas = 'Sorry @!In {} nothink get a mention'.format(noobcoder.getGroup(to).name)
                                    mentions(to, msgas, [noobcoderMID])
                                except:
                                    mids = ["u3e941ed98d2a98e04ad01784b7baacf6"]
                                    msgas = 'Sorry @!In Chat @!nothink get a mention'
                                    mentions(to, msgas, [noobcoderMID])
                        elif cmd.startswith("ginfo "):
                            number = removeCmd("ginfo",text)
                            groups = noobcoder.getGroupIdsJoined()
                            ret_ = ""
                            try:
                                group = groups[int(number)-1]
                                G = noobcoder.getGroup(group)
                                path = "http://dl.profile.line-cdn.net/" + G.pictureStatus
                                try:
                                    gCreator = G.creator.displayName
                                except:
                                    gCreator = "Tidak ditemukan"
                                if G.invitee is None:
                                    gPending = "0"
                                else:
                                    gPending = str(len(G.invitee))
                                if G.preventedJoinByTicket == True:
                                    gQr = "Tertutup"
                                    gTicket = "Tidak ada"
                                else:
                                    gQr = "Terbuka"
                                    gTicket = "https://line.me/R/ti/g/{}".format(str(noobcoder.reissueGroupTicket(G.id)))
                                timeCreated = []
                                timeCreated.append(time.strftime("%d-%m-%Y [ %H:%M:%S ]", time.localtime(int(G.createdTime) / 1000)))
                                ret_ += "「 Group Info 」\n"
                                ret_ += "\nNama Group : {}".format(G.name)
                                ret_ += "\nID Group : {}".format(G.id)
                                ret_ += "\nPembuat : {}".format(gCreator)
                                ret_ += "\nWaktu Dibuat : {}".format(str(timeCreated))
                                ret_ += "\nJumlah Member : {}".format(str(len(G.members)))
                                ret_ += "\nJumlah Pending : {}".format(gPending)
                                ret_ += "\nGroup Qr : {}".format(gQr)
                                ret_ += "\nGroup Ticket : {}".format(gTicket)
                                noobcoder.sendImageWithURL(to, path)
                                sendFooter(to, str(ret_))
                                noobcoder.sendContact(to, G.creator.mid)
                            except:
                                pass
                        elif cmd.startswith("changegn"):
                            if msg.toType == 2:
                                X = noobcoder.getGroup(to)
                                X.name = removeCmd("changegn", text)
                                noobcoder.updateGroup(X)                       
#=====================================================================
                        elif cmd == "lurk":
                            if 'lurkauto' not in wait:wait['lurkauto'] = False
                            if wait['lurkauto'] == False:sd = "\n│Lurk Auto: OFF"
                            else:sd = "\n│Lurk Auto: ON"
                            if to in wait['readPoint']:
                                a = "\n│Lurk State: ON"+sd
                            else:
                                a = "\n│Lurk State: OFF"+sd
                            if to in wait["lurkp"]:
                                if wait["lurkp"][to] == {}:
                                    b='\n╰Lurk People: None'
                                    h="╭「 Lurk 」─"+a+"\n│    | Command |  \n│Lurtk Point\n│  Usage: lurk on\n│  Usage: lurk auto on\n│Lurk Del\n│  Usage: lurk off\n│  Usage: lurk auto off\n│Lurk Cek\n│  Usage: lurk result"
                                    sendFooter(to,h+b)
                                else:
                                    h= "╭「 Lurk 」─"+a+"\n│    | Command |  \n│Lurk Point\n│  Usage: lurk on\n│  Usage: lurk auto on\n│Lurk Del\n│  Usage: lurk off\n│  Usage: lurk auto off\n│Lurk Cek\n│  Usage: lurk result\n│Lurk People: {}".format(len(wait["lurkp"][to]))
                                    no=0
                                    hh = []
                                    for c in wait["lurkp"][to]:
                                        no+=1
                                        hh.append(c)
                                        if no == len(wait["lurkp"][to]):h+= '\n╰ {}. @!'.format(no)
                                        else:h+= '\n│ {}. @!'.format(no)
                                    mentions(to,h,hh)
                            else:
                                b='\n╰Lurk People: None'
                                h="╭「 Lurk 」─"+a+"\n│    | Command |  \n│Lurk Point\n│  Usage: lurk on\n│  Usage: lurk auto on\n│Lurk Del\n│  Usage: lurk off\n│  Usage: lurk auto off\n│Lurk Cek\n│  Usage: lurk result"
                                sendFooter(to,h+b)
                        elif cmd == "lurk on":
                            if to in wait['readPoint']:
                                noobcoder.sendMessage(to, " 「 Lurk 」\nLurk already set♪")
                            else:
                                try:
                                    del wait['readPoint'][to];del wait['setTime'][to]
                                except:
                                    pass
                                wait['readPoint'][to] = msg.id;wait['setTime'][to]  = {};wait['ROM1'][to] = {}
                                sendFooter(to, " 「 Lurk 」\nLurk point set♪")
                        elif cmd == "lurk off":
                            if msg.to not in wait['readPoint']:
                                noobcoder.sendMessage(to, " 「 Lurk 」\nLurk already off♪")
                            else:
                                try:
                                   del wait['readPoint'][to];wait['setTime'][to] = {};wait['ROM1'][to] = {}
                                except:
                                   pass
                                sendFooter(to, " 「 Lurk 」\nLurk point off♪")
                        elif cmd == "lurk result":
                            if to in wait['readPoint']:
                                try:
                                    anulurk(to,wait)
                                    wait['setTime'][to]  = {}
                                except:noobcoder.sendMessage(to,'╭「 Lurkers 」─\n╰ None')
                            else:noobcoder.sendMessage(to, " 「 Lurk 」\nLurk point not on♪")
                        elif cmd == "lurk auto on":
                            if to in wait['readPoint']:
                                if wait['lurkauto'] == True:noobcoder.sendMessage(to, " 「 Lurk 」\nLurk already set♪")
                            else:
                                try:
                                    del wait['readPoint'][to];del wait['setTime'][to]
                                except:
                                    pass
                                wait['readPoint'][to] = msg.id;wait['setTime'][to]  = {};wait['ROM1'][to] = {}
                                wait['lurkauto'] = True
                                noobcoder.sendMessage(to, " 「 Lurk 」\nLurk point set♪")
                        elif cmd == "lurk auto off":
                            if wait['lurkauto'] == False:
                                noobcoder.sendMessage(to, " 「 Lurk 」\nLurk auto already off♪")
                            else:
                                wait['lurkauto'] = False
                                noobcoder.sendMessage(to, " 「 Lurk 」\nLurk auto point off♪")
                        elif cmd.startswith("lurk on "):
                            if 'MENTION' in msg.contentMetadata.keys()!=None:
                                key = eval(msg.contentMetadata["MENTION"])
                                targets = key["MENTIONEES"][0]["M"]
                                if targets in wait['readPoints']:
                                    noobcoder.sendMention(to, " 「 Lurk 」\nLurk in @! already active",'',[targets])
                                else:
                                    try:
                                        del wait['readPoints'][targets];del wait['lurkt'][to];del wait['lurkp'][to][targets]
                                    except:
                                        pass
                                    wait['readPoints'][targets] = msg.id
                                    if to not in wait['lurkt']:
                                        wait['lurkt'][to] = {}
                                        wait['lurkp'][to] = {}
                                    if targets not in wait['lurkp'][to]:
                                        wait['lurkp'][to][targets] = {}
                                        wait['lurkt'][to][targets] = {}
                                    noobcoder.sendMention(to, " 「 Lurk 」\nLurk in @! set to active",'',[targets])
                        elif cmd.startswith("lurk off "):
                            if 'MENTION' in msg.contentMetadata.keys()!=None:
                                key = eval(msg.contentMetadata["MENTION"])
                                targets = key["MENTIONEES"][0]["M"]
                                if targets not in wait['readPoints']:
                                    noobcoder.sendMention(to, " 「 Lurk 」\nLurk in @! already mute",'',[targets])
                                else:
                                    try:
                                        del wait['readPoints'][targets];del wait['lurkp'][to];del wait["lurkt"][to]
                                    except:
                                        pass
                                    noobcoder.sendMention(to, " 「 Lurk 」\nLurk in @! set to mute",'',[targets])
                        elif cmd.startswith("lurk result "):
                            if 'MENTION' in msg.contentMetadata.keys()!=None:
                                key = eval(msg.contentMetadata["MENTION"])
                                targets = key["MENTIONEES"][0]["M"]
                                if targets in wait['readPoints']:
                                    chiya = []
                                    for rom in wait["lurkp"][to][targets].items():
                                        chiya.append(rom[1])
                                        print(rom[1])
                                    k = len(chiya)//100
                                    for a in range(k+1):
                                        if a == 0:noobcoder.mentionmention(to=to,wait=wait,text='',dataMid=chiya[:100],pl=0,ps='╭「 Lurkers 」─',pg='SIDERMES',pt=chiya)
                                        else:noobcoder.mentionmention(to=to,wait=wait,text='',dataMid=chiya[a*100 : (a+1)*100],pl=a*100,ps='├「 Lurkers 」─',pg='SIDERMES',pt=chiya)
                                    wait['lurkt'][to][targets]  = {};wait['lurkp'][to][targets] = {}
                                else:noobcoder.sendMention(to, " 「 Lurk 」\nLurk in @! not active",'',[targets])
#=====================================================================
#=====================================================================
                        elif cmd.startswith("add pict ") and sender == noobcoderMID:
                            load()
                            name = removeCmd("add pict", text)
                            name = name.lower()
                            if name not in images:
                                settings["addImage"]["status"] = True
                                settings["addImage"]["name"] = str(name.lower())
                                images[str(name.lower())] = ""
                                f = codecs.open('khie/image.json','w','utf-8')
                                json.dump(images, f, sort_keys=True, indent=4, ensure_ascii=False)
                                sendFooter(to, "Type: Picture\n • Detail: Add picture\n • Statud: Send pict...")
                            else:
                                sendFooter(to, "Type: Picture\n • Detail: Add picture\n • Status: Failed, Picture already in list...")
                        elif cmd.startswith("del pict ") and sender == noobcoderMID:
                            load()
                            name = removeCmd("del pict", text)
                            name = name.lower()
                            if name in images:
                                noobcoder.deleteFile(images[str(name.lower())])
                                del images[str(name.lower())]
                                f = codecs.open('khie/image.json','w','utf-8')
                                json.dump(images, f, sort_keys=True, indent=4, ensure_ascii=False)
                                sendFooter(to, "Type: Picture\n • Detail: Delete list picture\n • Status: Succes delete Picture {}".format(str(name.lower())))
                            else:
                                sendFooter(to, "Type: Picture\n • Detail: Delete list picture\n • Status: Failed, Picture not in list...")
                        elif cmd.startswith("changepict ") and sender == noobcoderMID:
                            load()
                            name = removeCmd("changepict", text)
                            name = name.lower()
                            if name in images:
                                settings["addImage"]["status"] = True
                                settings["addImage"]["name"] = str(name.lower())
                                images[str(name.lower())] = ""
                                f = codecs.open('khie/image.json','w','utf-8')
                                json.dump(images, f, sort_keys=True, indent=4, ensure_ascii=False)
                                noobcoder.sendMessage(to, "Type: Picture\n • Detail: Change picture\n • Status: Send pict...")
                            else:
                                noobcoder.sendMessage(to, "Type: Picture\n • Detail: Change picture\n • Status: Failed, Picture not in list...")
                        elif cmd == "list pict":
                            load()
                            no = 0
                            ret_ = " 「 List Picture 」"
                            for image in images:
                                no += 1
                                ret_ += "\n{}. {}".format(int(no), image.title())
                            ret_ += "\n\nTotal {} Picture".format(str(len(images)))
                            sendFooter(to, ret_)
                        elif cmd.startswith("sendpict ") and sender == noobcoderMID:
                            load()
                            text = removeCmd("sendpict", text)
                            cond = text.split(" ")
                            jml = int(cond[0])
                            imagename = text.replace(cond[0] + " ","").lower()
                            if imagename in images:
                                imgURL = images[imagename]
                            else:
                                noobcoder.sendMessage(to, "Type: Picture\n • Detail: Send picture\n • Status: Failed, Picture name not in list...")
                                return
                            for x in range(jml):
                                noobcoder.sendImage(to, imgURL)
#=====================================================================
#=====================================================================
                        elif cmd.startswith("add sflex ") and sender == noobcoderMID:
                            load()
                            name = removeCmd("add sflex", text)
                            name = name.lower()
                            if name not in stickers1:
                                nissa["addTikel2"]["status"] = True
                                nissa["addTikel2"]["name"] = name.lower()
                                stickers1[name.lower()] = {}
                                f = codecs.open('khie/sticker1.json','w','utf-8')
                                json.dump(stickers1, f, sort_keys=True, indent=4, ensure_ascii=False)
                                sendFooter(to, "Send stickers to save as {} ".format(name.lower()))
                            else:
                                sendFooter(to, "Stickers {} already in list.".format(name.lower()))
                        elif cmd.startswith("del sflex") and sender == noobcoderMID:
                            name = removeCmd("del sflex", text)
                            name = name.lower()
                            if name in stickers1:
                                del stickers1[name.lower()]
                                f = codecs.open('khie/sticker1.json','w','utf-8')
                                json.dump(stickers2, f, sort_keys=True, indent=4, ensure_ascii=False)
                                sendFooter(to, "Success delete stickers {} ".format(name.lower()))
                            else:
                                sendFooter(to, "Stickers {} not found in list.".format(name.lower())) 
                        elif cmd.startswith("add sticker ") and sender == noobcoderMID:
                            load()
                            name = removeCmd("add sticker", text)
                            name = name.lower()
                            if name not in stickers2:
                                anyun["addTikel"]["status"] = True
                                anyun["addTikel"]["name"] = name.lower()
                                stickers2[name.lower()] = {}
                                f = codecs.open('khie/sticker2.json','w','utf-8')
                                json.dump(stickers2, f, sort_keys=True, indent=4, ensure_ascii=False)
                                sendFooter(to, "Send stickers to save as {} ".format(name.lower()))
                            else:
                                sendFooter(to, "Stickers {} already in list.".format(name.lower()))
                        elif cmd.startswith("del sticker ") and sender == noobcoderMID:
                            name = removeCmd("del sticker", text)
                            name = name.lower()
                            if name in stickers2:
                                del stickers2[name.lower()]
                                f = codecs.open('khie/sticker2.json','w','utf-8')
                                json.dump(stickers2, f, sort_keys=True, indent=4, ensure_ascii=False)
                                sendFooter(to, "Success delete stickers {} ".format(name.lower()))
                            else:
                                sendFooter(to, "Stickers {} not found in list.".format(name.lower())) 
                        elif cmd.startswith("add stickerz ") and sender == noobcoderMID:
                            load()
                            name = removeCmd("add stickerz", text)
                            name = name.lower()
                            if name not in stickers:
                                settings["addSticker"]["status"] = True
                                settings["addSticker"]["name"] = str(name.lower())
                                stickers[str(name.lower())] = {}
                                f = codecs.open('khie/sticker.json','w','utf-8')
                                json.dump(stickers, f, sort_keys=True, indent=4, ensure_ascii=False)
                                sendFooter(to, "Type: Stickers\n • Detail: Add sticker\n • Status: Send sticker..")
                            else:
                                sendFooter(to, "Type: Stickers\n • Detail: Add sticker\n • Status: Failed, Sticker name already in list..")
                        elif cmd.startswith("del stickerz ") and sender == noobcoderMID:
                            load()
                            name = removeCmd("del stickerz", text)
                            name = name.lower()
                            if name in stickers:
                                del stickers[str(name.lower())]
                                f = codecs.open('khie/sticker.json','w','utf-8')
                                json.dump(stickers, f, sort_keys=True, indent=4, ensure_ascii=False)
                                sendFooter(to, "Type: Sticker\n • Detail: Delete sticker\n • Status: Succes delete Sticker {}".format(str(name.lower())))
                            else:
                                sendFooter(to, "Type: Sticker\n • Detail: Delete sticker\n • Status: Failed, Sticker name not in list")
                        elif cmd.startswith("changestickerz ") and sender == noobcoderMID:
                            load()
                            name = removeCmd("changestickerz", text)
                            name = name.lower()
                            if name in stickers:
                                settings["addSticker"]["status"] = True
                                settings["addSticker"]["name"] = str(name.lower())
                                stickers[str(name.lower())] = ""
                                f = codecs.open('khie/sticker.json','w','utf-8')
                                json.dump(stickers, f, sort_keys=True, indent=4, ensure_ascii=False)
                                noobcoder.sendMessage(to, "Type: Stickers\n • Detail: Change sticker\n • Status: Send sticker..")
                            else:
                                noobcoder.sendMessage(to, "Type: Stickers\n • Detail: Change sticker\n • Status: Failed, Sticker not in list..")
                        elif cmd == "list sticker":
                            load()
                            ret_ = "「 Sticker List 」\n"
                            for sticker in stickers2:
                                ret_ += "\n" + sticker.title()
                            ret_ += "\n\nTotal {} Stickers".format(str(len(stickers2)))
                            sendFooter(to, ret_)
                        elif cmd == "list sflex":
                            load()
                            ret_ = "「 Sticker Flex 」\n"
                            for sticker in stickers1:
                                ret_ += "\n" + sticker.title()
                            ret_ += "\n\nTotal {} Stickers".format(str(len(stickers1)))
                            sendFooter(to, ret_)
                        elif cmd == "list stickerz":
                            load()
                            ret_ = "「 Sticker List 」\n"
                            for sticker in stickers:
                                ret_ += "\n" + sticker.title()
                            ret_ += "\n\nTotal {} Stickers".format(str(len(stickers)))
                            sendFooter(to, ret_)
                        elif cmd.startswith("sendstickerz ") and sender == noobcoderMID:
                            load()
                            text = removeCmd("sendstickerz", text)
                            cond = text.split(" ")
                            jml = int(cond[0])
                            stickername = text.replace(cond[0] + " ","").lower()
                            if stickername in stickers:
                                sid = stickers[stickername]["STKID"]
                                spkg = stickers[stickername]["STKPKGID"]
                                sver = stickers[stickername]["STKVER"]
                            else:
                                return
                            for x in range(jml):
                                sendStickers(to, sver, spkg, sid)
                        elif cmd.startswith("lyrics "):
                            anu = removeCmd("lyrics", text)
                            slyric(to, text)
                        elif cmd.startswith("searchlyric "):
                            sep = text.split(" ")
                            txt = text.replace(sep[0] + " ","")
                            cond = txt.split("|")
                            query = cond[0]
                            key = settings["keyCommand"].title()
                            if settings["setKey"] == False:key = ''
                            with requests.session() as web:
                                web.headers["user-agent"] = "Mozilla/5.0"
                                url = web.get("https://www.musixmatch.com/search/{}".format(urllib.parse.quote(query)))
                                data = BeautifulSoup(url.content, "html.parser")
                                result = []
                                for trackList in data.findAll("ul", {"class":"tracks list"}):
                                    for urlList in trackList.findAll("a"):
                                        title = urlList.text
                                        url = urlList["href"]
                                        result.append({"title": title, "url": url})
                                if len(cond) == 1:
                                    ret_ = "Lyric  Result :\n"
                                    num = 0
                                    for title in result:
                                        num += 1
                                        ret_ += "\n{}. {}".format(str(num), str(title["title"]))
                                    ret_ += "\n\nTotal {} Lyric".format(str(len(result)))
                                    ret_ += "\n\nSearchLyric {}|「number」".format(str(query))
                                    sendFooter(to, ret_)
                                elif len(cond) == 2:
                                    num = int(cond[1])
                                    if num <= len(result):
                                        data = result[num - 1]
                                        with requests.session() as web:
                                            web.headers["user-agent"] = "Mozilla/5.0"
                                            url = web.get("https://www.musixmatch.com{}".format(urllib.parse.quote(data["url"])))
                                            data = BeautifulSoup(url.content, "html5lib")
                                            for lyricContent in data.findAll("p", {"class":"mxm-lyrics__content "}):
                                                lyric = lyricContent.text
                                                sendFooter(to, lyric)
                        elif cmd.startswith("play "):
                            name = removeCmd("play",text)
                            path = noobcoder.downloadFileURL(name)
                            noobcoder.sendAudio(to, path)
                            os.remove(path)

                        if cmd == "invite":
                            undang["invite"] = True
                            sendFooter(to, "Send a contact to invite")
                        elif cmd =="lope":
                            data = {
                                        "type": "flex",
                                        "altText": "Request Login",
                                        "contents": {
                                            "type": "bubble",
                                            "footer": {
                                                "type": "box",
                                                "layout": "vertical",
                                                "spacing": "sm",
                                                "contents": [
                                                    {
                                                       "type": "button",
                                                       "style": "primary",
                                                        "color": "#000000",
                                                        "height": "sm",
                                                        "action": {
                                                            "type": "uri",
                                                            "label": "CLICK HERE FOR LOGIN",
                                                            "uri": "https://line.me/ti/p/~khiewuzzheree",
                                                        }                                                   
                                                    },
                                                    {
                                                        "type": "spacer",
                                                        "size": "sm",
                                                    }
                                                ],
                                                "flex": 0
                                            }
                                        }
                                    }
                            sendTemplate(to, data)
#=====================================================================
                        elif cmd == "get note":
                            to = msg.to
                            data = noobcoder.getGroupPost(to)
                            msg.text = noobcoder.mycmd(msg.text,wait)
                            if data['result'] != []:
                                try:
                                    no = 0
                                    b = []
                                    a = " 「 Groups 」\nType: Get Note"
                                    for i in data['result']['feeds']:
                                        b.append(i['post']['userInfo']['writerMid'])
                                        try:
                                            for aasd in i['post']['contents']['textMeta']:b.append(aasd['mid'])
                                        except:pass
                                        no += 1
                                        gtime = i['post']['postInfo']['createdTime']
                                        try:g = i['post']['contents']['text'].replace('@','@!')
                                        except:g="None"
                                        if no == 1:sddd = '\n'
                                        else:sddd = '\n\n'
                                        a +="{}{}. Penulis : @!\nDescription: {}\nTotal Like: {}\nCreated at: {}\n".format(sddd,no,g,i['post']['postInfo']['likeCount'],humanize.naturaltime(datetime.fromtimestamp(gtime/1000)))
                                    a +="Status: Success Get "+str(data['result']['homeInfo']['postCount'])+" Note"
                                    noobcoder.sendMention(to,a,'',b)
                                except Exception as e:
                                    return noobcoder.sendMessage(to,"「 Auto Respond 」\n"+str(e))
                        elif cmd.startswith("get note "):
                            to = msg.to
                            data = noobcoder.getGroupPost(to)
                            msg.text = noobcoder.mycmd(msg.text,wait)
                            try:
                                music = data['result']['feeds'][int(msg.text.split(' ')[2]) - 1]
                                b = [music['post']['userInfo']['writerMid']]
                                try:
                                    for a in music['post']['contents']['textMeta']:b.append(a['mid'])
                                except:pass
                                try:
                                    g= "\n\nDescription:\n"+str(music['post']['contents']['text'].replace('@','@!'))
                                except:
                                    g=""
                                a="\n   Total Like: "+str(music['post']['postInfo']['likeCount'])
                                a +="\n   Total Comment: "+str(music['post']['postInfo']['commentCount'])
                                gtime = music['post']['postInfo']['createdTime']
                                a +="\n   Created at: "+str(humanize.naturaltime(datetime.fromtimestamp(gtime/1000)))
                                a += g
                                zx = ""
                                zxc = " 「 Groups 」\nType: Get Note\n   Penulis : @!"+a
                                try:
                                    noobcoder.sendMention(to,zxc,'',b)
                                except Exception as e:
                                    noobcoder.sendMessage(to, str(e))
                                try:
                                    for c in music['post']['contents']['media']:
                                        params = {'userMid': noobcoder.getProfile().mid, 'oid': c['objectId']}
                                        path = noobcoder.server.urlEncode(noobcoder.server.LINE_OBS_DOMAIN, '/myhome/h/download.nhn', params)
                                        if 'PHOTO' in c['type']:
                                            try:
                                                sendFooter(to," 「 Note 」\nPlease wait, while send your picture...")
                                                noobcoder.sendImageWithURL(to,path)
                                            except:pass
                                        else:
                                            pass
                                        if 'VIDEO' in c['type']:
                                            try:
                                                sendFooter(to," 「 Note 」\nPlease wait, while send your videos...")
                                                noobcoder.sendVideoWithURL(to,path)
                                            except:pass
                                        else:
                                            pass
                                except:
                                    pass
                            except Exception as e:
                                return noobcoder.sendMessage(to,"「 Auto Respond 」\n"+str(e))
                        elif cmd == "get announ":
                            msg.text = noobcoder.mycmd(msg.text,wait)
                            to = msg.to
                            a = noobcoder.getChatRoomAnnouncements(msg.to)
                            if a == []:
                                noobcoder.sendMention(to, 'Sorry @!In {} nothink get a Announcements'.format(self.getGroup(to).name),' 「 Announcements 」\n', [self.getProfile().mid])
                                return
                            no = 0
                            c = ' 「 Announcements 」'
                            h = []
                            ds = [a[b].creatorMid for b in range(len(a)) if a[b].creatorMid not in h]
                            for b in a:
                                if b.creatorMid not in h:
                                    h.append(b.creatorMid)
                                    no += 1
                                    c += "\n{}. @! #{}x".format(no,str(a).count(b.creatorMid))
                                noobcoder.sendMention(msg.to,c,'',h)
                        elif cmd.startswith("get announ "):
                            msg.text = noobcoder.mycmd(msg.text,wait)
                            to = msg.to
                            a = noobcoder.getChatRoomAnnouncements(msg.to)
                            if a == []:
                                noobcoder.sendMention(to, 'Sorry @!In {} nothink get a Announcements'.format(noobcoder.getGroup(to).name),' 「 Announcements 」\n', [noobcoder.getProfile().mid])
                                return
                            c = ' 「 Announcements 」'
                            no = 0
                            h = []
                            ds = [a[b].creatorMid for b in range(len(a)) if a[b].creatorMid not in h]
                            if len(msg.text.split(' ')) == 3:
                                sd = ds[int(msg.text.split(' ')[2])-1]
                            c+= '\nCreate by: @!'
                            no=0
                            for b in a:
                                if b.contents.link != None:
                                    if b.creatorMid in sd:
                                        no+=1
                                if 'line://nv/chatMsg?chatId=' in b.contents.link:sdg = '{}'.format(b.contents.link)
                                else:sdg = '{}'.format(b.contents.text)
                                if no == 1:c+= '\n{}. 「 {} 」\n{}'.format(no,humanize.naturaltime(datetime.fromtimestamp(b.createdTime/1000)),sdg)
                                else:c+= '\n\n{}. 「 {} 」\n{}'.format(no,humanize.naturaltime(datetime.fromtimestamp(b.createdTime/1000)),sdg)
                            noobcoder.sendMention(msg.to,c,'',[sd])
                        elif cmd.startswith("weather "):
                            try:
                                region = removeCmd("weather", text)
                                r = requests.get("https://api.eater.pw/api/weather/?apikey=beta&region=%s"%region)
                                data = json.loads(r.text)
                                result = "「 Weather 」\n"
                                result += "\nRegion : %s"%data["result"]["name"]
                                result += "\nLatitude : %s"%data["result"]["coord"]["lat"]
                                result += "\nLongitude : %s"%data["result"]["coord"]["lon"]
                                result += "\nCountry : %s"%data["result"]["sys"]["country"]
                                for anuan in data["result"]["weather"]:
                                    result += "\nDescription : %s"%anuan["description"]
                                result += "\nTemp : %s"%data["result"]["main"]["temp"]
                                result += "\nHumidity : %s"%data["result"]["main"]["humidity"]
                                result += "\nPressure : %s"%data["result"]["main"]["pressure"]
                                result += "\nWind speed: %s"%data["result"]["wind"]["speed"]
                                sendFooter(receiver, str(result))
                            except Exception as e:
                                noobcoder.sendMessage(receiver, str(e))
                        elif cmd.startswith("anime "):
                            judul = removeCmd("anime", text)
                            with _session as web:
                                try:
                                    r = web.get("https://kitsu.io/api/edge/anime?filter[text]={}".format(str(judul)))
                                    data = r.text
                                    data = json.loads(data)
                                    anu = data["data"][0]
                                    title = anu["attributes"]["titles"]["en_jp"]
                                    synopsis = anu["attributes"]["synopsis"]
                                    id = anu["id"]
                                    link = anu["links"]["self"]
                                    ret_ = "「About Anime」"
                                    ret_ += "\n\nTitle : {}\nSynopsis : {}\nId : {}\nLink : {}".format(str(title), str(synopsis), str(id), str(link))
                                    sendFooter1(to, str(ret_))
                                except:
                                    noobcoder.sendMessage(to, "Tidak ada hasil ditemukan")
                        if cmd.startswith('nhentai '):nhentai(to,msg,liffnya,cmd)
                        elif cmd.startswith("asking "):
                            kata = removeCmd("asking", text)
                            sch = kata.replace(" ","+")
                            with _session as web:
                                urlz = "http://lmgtfy.com/?q={}".format(str(sch))
                                r = _session.get("http://tiny-url.info/api/v1/create?apikey=A942F93B8B88C698786A&provider=cut_by&format=json&url={}".format(str(urlz)))
                                data = r.text
                                data = json.loads(data)
                                url = data["shorturl"]
                                ret_ = "「Ask」"
                                ret_ += "\n\nLink : {}".format(str(url))
                                sendFooter1(to, str(ret_))
                        elif cmd.startswith("@create "):
                            sep = text.split(" ")
                            txt = text.replace(sep[0] + " ","")
                            url = "line://app/1643727178-0XPGAaRX/?type=text&text={}".format(urllib.parse.quote(txt))
                            Thread(target=noobcoder.sendImageWithURL,args=(to, "https://reportnasdem.000webhostapp.com/text2image/?type=3&text={}&size=30".format(txt),)).start()
                            data = {
                                "type": "flex",
                                "altText": "Kepo Bner Dah",
                                "contents": {
                                    "type": "bubble",
                                    "body": {
                                        "type": "box",
                                        "layout": "vertical",
                                        "contents": [
                                            {
                                                "type": "text",
                                                "align": "center",
                                                "color": "#00FFF3",
                                                "text": "{}".format(txt),
                                                "wrap": True,
                                                "action": {
                                                    "type": "uri",
                                                    "uri": url
                                                }
                                            }
                                        ]
                                    }
                                }
                            }
                            sendTemplate(to, data)
                        elif cmd == "doujinnews":
                            result = requests.get("https://nhentai.net")
                            data = BeautifulSoup(result.content, 'html5lib')
                            hasil = "[ Doujin News ]"                                  
                            no = 1
                            for sam in data.findAll('div', attrs={'class':'gallery'}):
                                hasil += "\n{}. {}".format(str(no), str(sam.find('a').text))
                                hasil += "\nhttps://nhentai.net{}".format(str(sam.find('a')['href']))                                        
                                no = (no+1)                                    
                            sendFooter1(to, str(hasil))                      
                        elif cmd == "announ clear":
                            a = noobcoder.getChatRoomAnnouncements(msg.to)
                            try:
                                for b in a:
                                    noobcoder.removeChatRoomAnnouncement(msg.to,b.announcementSeq)
                                    noobcoder.sendMessage(msg.to, 'Done')
                            except Exception as e:
                                ee = traceback.format_exc()
                                noobcoder.sendMessage(msg.to, '{}'.format(e))
                        elif cmd == "chatbot off":
                            if sender in noobcoderMID or sender in chatbot["admin"]:
                                if to not in chatbot["botMute"]:
                                    chatbot["botMute"].append(to)
                                    sendFooter(to, "I'll be here when you need me")
                            else:
                                if to not in chatbot["botOff"]:
                                    chatbot["botOff"].append(to)
                                    sendFooter(to, "I'll be here when you need me")
                        elif cmd == "get album":
                            noobcoder.getalbum(to, wait)
                        elif cmd == "banlist":
                            if bl["blacklist"] == []:
                                noobcoder.sendMessage(to,"「 BlackList 」")
                            else:
                                num = 1
                                mc = "「 BlackList 」\n"
                                for me in bl["blacklist"]:
                                    mc += "\n- %i.  %s" % (num, noobcoder.getContact(me).displayName)
                                    num = (num+1)
                                mc += "\n\nTotaL %i BlackList" % len(bl["blacklist"])
                                sendFooter(to, mc)
                        elif cmd.startswith("get album "):
                            name = removeCmd("get album ",text)
                            noobcoder.getalbum2(to, text, wait)
                        elif cmd == "mysticker":
                            a = noobcoder.shop.getActivePurchases(start=0, size=1000, language='ID', country='ID').productList
                            c = "List Download Sticker:"
                            no = 0
                            for b in a:
                                no +=1
                                c += "\n"+str(no)+". "+b.title[:21]+" ID:"+str(b.packageId)
                            k = len(c)//10000
                            for aa in range(k+1):
                                sendFooter1(msg.to,'{}'.format(c[aa*10000 : (aa+1)*10000]))
                        elif cmd.startswith('find '):
                            if 'MENTION' in msg.contentMetadata.keys()!=None:
                                key = eval(msg.contentMetadata["MENTION"])
                                key1 = key["MENTIONEES"][0]["M"]
                                a = noobcoder.getGroupIdsJoined();i = noobcoder.getGroups(a)
                                c = []
                                for h in i:
                                    g = [c.append(h.name[0:20]+',.s/'+str(len(h.members))) for d in h.members if key1 in d.mid]
                                h = "╭「 Find Contact 」─"
                                no = 0
                                for group in c:
                                    no += 1
                                    h+= "\n│{}. {} | {}".format(no, group.split(',.s/')[0], group.split(',.s/')[1])
                                sendFooter1(msg.to,h+"\n╰─「 {} Groups I Found it 」".format(len(c)))
                        elif cmd.startswith("inviteid "):
                            text = removeCmd("inviteid", text)
                            sep = text.split(" ")
                            idnya = text.replace(sep[0] + " ", text)
                            conn = noobcoder.findContactsByUserid(idnya)
                            noobcoder.findAndAddContactsByMid(conn.mid)
                            noobcoder.inviteIntoGroup(msg.to,[conn.mid])
                            group = noobcoder.getGroup(msg.to)
                            xname = noobcoder.getContact(conn.mid)
                            zx = ""
                            zxc = ""
                            zx2 = []
                            xpesan = '「 Invited from Id 」\nName '
                            khie = str(xname.displayName)
                            pesan = ''
                            pesan2 = pesan+"@a\n"
                            xlen = str(len(zxc)+len(xpesan))
                            xlen2 = str(len(zxc)+len(pesan2)+len(xpesan)-1)
                            zx = {'S':xlen, 'E':xlen2, 'M':xname.mid}
                            zx2.append(zx)
                            zxc += pesan2
                            text = xpesan+ zxc + "To group " + str(group.name) +""
                            noobcoder.sendMessage(receiver, text, contentMetadata={'MENTION':str('{"MENTIONEES":'+json.dumps(zx2).replace(' ','')+'}')}, contentType=0)
                        elif cmd.startswith("gbroadcast ") and sender == noobcoderMID:
                            txt = removeCmd("gbroadcast", text)
                            groups = noobcoder.getGroupIdsJoined()
                            for group in groups:
                                sendFooter1(group, "「 Group Broadcast 」\n\n{}".format(str(txt)))
                                time.sleep(1)
                            noobcoder.sendMessage(to, "Succes broadcast to {} group".format(str(len(groups))))
                        elif cmd.startswith("fbroadcast ") and sender == noobcoderMID:
                            txt = removeCmd("fbroadcast", text)
                            friends = noobcoder.getAllContactIds()
                            for friend in friends:
                                sendFooter1(friend, "「 Friend Broadcast 」\n\n{}".format(str(txt)))
                                time.sleep(1)
                            noobcoder.sendMessage(to, "Succes friend cast to {} friend ".format(str(len(friends))))
                        elif cmd.startswith("allbroadcast ") and sender == noobcoderMID:
                            txt = removeCmd("allbroadcast", text)
                            friends = noobcoder.getAllContactIds()
                            groups = noobcoder.getGroupIdsJoined()
                            for group in groups:
                                sendFooter1(group, "「 Group Broadcast 」\n\n{}".format(str(txt)))
                                time.sleep(1)
                            noobcoder.sendMessage(to, "Succes broadcast to {} group".format(str(len(groups))))
                            for friend in friends:
                                sendFooter1(friend, "「 Friend Broadcast 」\n\n{}".format(str(txt)))
                                time.sleep(1)
                            noobcoder.sendMessage(to, "Succes broadcast to {} friend".format(str(len(friends))))
                        elif cmd.startswith("closeqr "):
                            number = removeCmd("closeqr", text)
                            groups = noobcoder.getGroupIdsJoined()
                            try:
                                group = groups[int(number)-1]
                                G = noobcoder.getGroup(group)
                                try:
                                    G.preventedJoinByTicket = True
                                    noobcoder.updateGroup(G)
                                except:
                                    G.preventedJoinByTicket = True
                                    noobcoder.updateGroup(G)
                                sendFooter1(to, "「 Close Qr 」\n\nGroup : " + G.name)
                            except Exception as error:
                                noobcoder.sendMessage(to, str(error))
                        elif cmd.startswith("openqr "):
                            number = removeCmd("openqr", text)
                            groups = noobcoder.getGroupIdsJoined()
                            try:
                                group = groups[int(number)-1]
                                G = noobcoder.getGroup(group)
                                try:
                                    G.preventedJoinByTicket = False
                                    noobcoder.updateGroup(G)
                                    gurl = "https://line.me/R/ti/g/{}".format(str(noobcoder.reissueGroupTicket(G.id)))
                                except:
                                    G.preventedJoinByTicket = False
                                    noobcoder.updateGroup(G)
                                    gurl = "https://line.me/R/ti/g/{}".format(str(noobcoder.reissueGroupTicket(G.id)))
                                sendFooter1(to, "「 Open Qr 」\n\nGroup : " + G.name + "\nLink: " + gurl)
                            except Exception as error:
                                noobcoder.sendMessage(to, str(error))
                        elif cmd.startswith("groupcastvoice ") and sender == noobcoderMID:
                                bctxt = removeCmd("groupcastvoice", text)
                                bc = ("Broadcast voice")
                                cb = (bctxt + bc)
                                tts = gTTS(cb, lang='id', slow=False)
                                tts.save('tts.mp3')
                                n = noobcoder.getGroupIdsJoined()
                                for manusia in n:
                                    noobcoder.sendAudio(manusia, 'tts.mp3')
                        elif cmd.startswith("friendcastvoice ") and sender == noobcoderMID:
                                bctxt = removeCmd("friendcastvoice", text)
                                bc = ("Broadcast voice")
                                cb = (bctxt + bc)
                                tts = gTTS(cb, lang='id', slow=False)
                                tts.save('tts.mp3')
                                n = noobcoder.getAllContactIdsJoined()
                                for manusia in n:
                                    noobcoder.sendAudio(manusia, 'tts.mp3')
                        elif cmd.startswith("updatename "):
                            string = removeCmd("updatename", text)
                            if len(string) <= 10000000000:
                                pname = noobcoder.getContact(sender).displayName
                                profile = noobcoder.getProfile()
                                profile.displayName = string
                                noobcoder.updateProfile(profile)
                                sendFooter(to, "「 Update Name 」\nStatus : Success\nFrom : "+str(pname)+"\nTo :"+str(string))
                        elif cmd.startswith("updatestatus "):
                            string = removeCmd("updatestatus", text)
                            if len(string) <= 10000000000:
                                pname = noobcoder.getContact(sender).statusMessage
                                profile = noobcoder.getProfile()
                                profile.statusMessage = string
                                noobcoder.updateProfile(profile)
                                sendFooter(to, "「 Update Status 」\nStatus : Success\nFrom : "+str(pname)+"\nTo :"+str(string))
#                     \\ MEDIA //
#=========================================================
                        elif cmd.startswith('webtzoon '):
                            msg.text = noobcoder.mycmd(msg.text,wait)
                            drama = msg.text.split(' ')[1].lower()
                            try:
                                if drama == 'drama':aa = 0
                                if drama == 'fantasi':aa = 1
                                if drama == 'comedy':aa = 2
                                if drama == 'sol':aa = 3
                                if drama == 'romance':aa = 4
                                if drama == 'thriller':aa = 5
                                if drama == 'horror':aa = 6
                                a = noobcoder.blekedok(aa,'data')
                                try:
                                    if int(msg.text.split(' ')[2]) > len(a):
                                        sendFooter(msg.to,' 「 Webtoon 」\nDaftar Webtoon {} urutan ke {} tidak ditemukan'.format(drama.title(),msg.text.split(' ')[2]))
                                    gd = noobcoder.blekedok(aa)[int(msg.text.split(' ')[2])-1].get('href')
                                    b = requests.get(gd)
                                    soup1 = BeautifulSoup(b.text,'html5lib')
                                    data11 = soup1.find_all(class_='subj')
                                    data1 = soup1.find_all(class_='date')
                                    data2 = soup1.find_all(id='_listUl')
                                    data3 = data2[0].find_all('a')
                                    A = ' 「 Webtoon 」\n    | {} |'.format(a[int(msg.text.split(' ')[2])-1].find_all('p')[0].text)
                                    for c in range(0,10):
                                        if c+1 == 1:AA = '\n'
                                        else:AA = '\n\n'
                                        A+= '{}{}. {} | {}\n    {}'.format(AA,c+1,data11[c+1].text,data1[c].text.strip(),data3[c].get('href'))
                                    sendFooter(msg.to,A)
                                except:
                                    A = ' 「 Webtoon 」\n    | {} |'.format(drama.replace('sol','slice of life').title())
                                    no=0
                                    for b in a:
                                        no+=1
                                        if no == 1:AA = '\n'
                                        else:AA = '\n\n'
                                        if len(str(no)) == 1:cdd = '\n     Author: {}'.format(b.find_all('p')[1].text)
                                        if len(str(no)) == 2:cdd = '\n      Author: {}'.format(b.find_all('p')[1].text)
                                        A+= '{}{}. {} | {} Like{}'.format(AA,no,b.find_all('p')[0].text[:20],b.find_all('p')[2].find_all('em')[0].text,cdd)
                                    sendFooter(msg.to,A)
                            except Exception as e:noobcoder.sendMessage(msg.to,str(e))
                        elif cmd == "quranlist":
                            data = noobcoder.adityarequestweb("http://api.alquran.cloud/surah")
                            if data["data"] != []:
                                no = 0
                                ret_ = "╭──「 Al-Qur'an 」"
                                for music in data["data"]:
                                    no += 1
                                    if no == len(data['data']):ret_ += "\n╰{}. {}".format(no,music['englishName'])
                                    else:ret_ += "\n│{}. {}".format(no,music['englishName'])
                                sendFooter1(to,ret_)
                        elif cmd.startswith("qur'an "):
                            msg.text = noobcoder.mycmd(msg.text,wait)
                            data = noobcoder.adityarequestweb("http://api.alquran.cloud/surah/{}".format(noobcoder.adityasplittext(msg.text)))
                            if len(msg.text.split(' ')) == 1:
                                if data["data"] != []:
                                    no = 0
                                    ret_ = "╭──「 Al-Qur'an 」"
                                    for music in data["data"]:
                                        no += 1
                                        if no == len(data['data']):ret_ += "\n╰{}. {}".format(no,music['englishName'])
                                        else:ret_ += "\n│{}. {}".format(no,music['englishName'])
                                    sendFooter1(msg.to,ret_)
                            if len(msg.text.split(' ')) == 2:
                                try:
                                    no = 0
                                    ret_ = " 「 Al-Qur'an 」\nSurah: {}".format(data['data']['englishName'])
                                    for music in data["data"]["ayahs"]:
                                        no += 1
                                        ret_ += "\n{}. {}".format(no,music['text'])
                                    k = len(ret_)//10000
                                    for aa in range(k+1):
                                        sendFooter(msg.to,'{}'.format(ret_[aa*10000 : (aa+1)*10000]))
                                except:noobcoder.sendMessage(msg.to," 「 Al-Qur'an 」\nI can't found surah number {}".format(noobcoder.adityasplittext(msg.text)))
                            if len(msg.text.split(' ')) == 3:
                                try:
                                    nama = data["data"]["ayahs"]
                                    selection = noobcoder.MySplit(noobcoder.adityasplittext(msg.text.lower(),'s'),range(1,len(nama)+1))
                                    k = len(nama)//100
                                    text = " 「 Al-Qur'an 」\nSurah: {}".format(data['data']['englishName'])
                                    no = 0
                                    for i in selection.parse():
                                        no+= 1
                                        text+= "\n{}. {}".format(i,nama[i-1]['text'])
                                    k = len(text)//10000
                                    for aa in range(k+1):
                                        noobcoder.sendMessage(msg.to,'{}'.format(text[aa*10000 : (aa+1)*10000]))
                                except:
                                    noobcoder.sendMessage(msg.to," 「 Al-Qur'an 」\nI can't found surah number {}".format(noobcoder.adityasplittext(msg.text)))
                        elif cmd == 'blacklist':noobcoder.adityasuperdata(to,wait,'Blacklist','bl',wait['blacklist'])
                        elif cmd == 'whitelist':noobcoder.adityasuperdata(to,wait,'Whitelist','wl',wait['bots'])
                        elif cmd.startswith("ytdl "):
                            anu = removeCmd("ytdl",text)
                            a = noobcoder.adityarequestweb("https://rest.farzain.com/api/yt_download.php?id={}&apikey=Q7I7o74ss7NrVm9QV0Gfr93fr".format(anu))
                            print(a)
                            #noobcoder.sendMessage(to, str(a))
                            noobcoder.sendVideoWithURL(to, a["urls"][0]["id"])
                        elif cmd.startswith("porns "):
                            kata = removeCmd("porns", text)
                            with _session as web:
                                try:
                                    r = web.get("https://api.redtube.com/?data=redtube.Videos.searchVideos&output=json&search={}".format(urllib.parse.quote(kata)))
                                    data = r.text
                                    data = json.loads(data)
                                    ret_ = "「Porn」"
                                    no = 1
                                    anu = data["videos"]
                                    if len(anu) >= 5:
                                        for s in range(5):
                                            hmm = anu[s]
                                            title = hmm['video']['title']
                                            duration = hmm['video']['duration']
                                            views = hmm['video']['views']
                                            link = hmm['video']['embed_url']
                                            ret_ += "\n\n{}. Title : {}\n    Duration : {}\n    Views : {}\n    Link : {}".format(str(no), str(title), str(duration), str(views), str(link))
                                            no += 1
                                    else:
                                        for s in anu:
                                            hmm = s
                                            title = hmm['video']['title']
                                            duration = hmm['video']['duration']
                                            views = hmm['video']['views']
                                            link = hmm['video']['embed_url']
                                            ret_ += "\n\n{}. Title : {}\n    Duration : {}\n    Views : {}\n    Link : {}".format(str(no), str(title), str(duration), str(views), str(link))
                                            no += 1
                                    sendFooter1(to, str(ret_))
                                except:
                                    sendFooter(to, "Porn Not Found !")
                        elif cmd.startswith("#image "):
                            start = time.time()
                            search = removeCmd("image", text)
                            url = "https://xeonwz.herokuapp.com/images/google.api?q=" + urllib.parse.quote(search)
                            with _session as web:
                                web.headers["User-Agent"] = random.choice(settings["userAgent"])
                                r = web.get(url)
                                data = r.text
                                data = json.loads(data)
                                if data["status"] == True:
                                    items = data["content"]
                                    path = random.choice(items)
                                    a = items.index(path)
                                    b = len(items)
                                    noobcoder.sendImageWithURL(to, str(path))
                                    elapsed_time = time.time() - start
                                    sendFooter(to,"Got image in %s seconds" %(elapsed_time))
                        elif cmd.startswith("devianart "):
                            start = time.time()
                            search = removeCmd("devianart", text)
                            with _session as web:
                                web.headers["User-Agent"] = random.choice(settings["userAgent"])
                                r = web.get("https://xeonwz.herokuapp.com/images/deviantart.api?q={}".format(urllib.parse.quote(search)))
                                data = r.text
                                data = json.loads(data)
                                if data["status"] == True:
                                    path = random.choice(data["content"])
                                    noobcoder.sendImageWithURL(to, str(path))
                                    elapsed_time = time.time() - start
                                    sendFooter(to,"[Image Result]\nGot image in %s seconds" %(elapsed_time))
                                else:
                                    noobcoder.sendMessage(to, "Hasil pencarian tidak ditemukan")
                        elif cmd.startswith("google "):
                            spl = re.split("google ",msg.text,flags=re.IGNORECASE)
                            if spl[0] == "":
                                if spl[1] != "":
                                    try:
                                        noobcoder.sendMessage(to,"Searching ..")
                                        resp = BeautifulSoup(requests.get("https://www.google.co.th/search",params={"q":spl[1],"gl":"th"}).content,"html.parser")
                                        text = "Google:\n\n"
                                        for el in resp.findAll("h3",attrs={"class":"r"}):
                                            try:
                                                tmp = el.a["class"]
                                                continue
                                            except:
                                                pass
                                            try:
                                                if el.a["href"].startswith("/search?q="):
                                                    continue
                                            except:
                                                continue
                                            text += el.a.text+"\n"
                                            text += str(el.a["href"][7:]).split("&sa=U")[0]+"\n\n"
                                        text = text[:-2]
                                        sendFooter1(to,str(text))
                                    except Exception as e:
                                        print(e)
                        elif cmd.startswith("wikipedia "):
                            search = removeCmd("wikipedia", text)
                            wiki = WikiApi({'locale':'id'})
                            results = wiki.find(search)
                            for a in results:
                                ret_ = "Wikipedia :\n"
                                article = wiki.get_article(a)
                                if article.image is not None: noobcoder.sendImageWithURL(to,str(article.image))
                                ret_ += "\nTitle : {}".format(str(article.heading))
                                ret_ += "\nURL : {}".format(str(article.url))
                                ret_ += "\nSummary\n{}".format(str(article.summary.replace("^","")))
                                sendFooter1(to,ret_)
                        elif cmd.startswith("githubprofile "):
                            username = removeCmd("githubprofile", text)
                            r = _session.get("https://api.github.com/users/" + username)
                            data = r.text
                            profile = json.loads(data)
                            if profile != [] and "message" not in profile:
                                ret_ = "「 Github 」\n"
                                ret_ += "\nType : Profile"
                                ret_ += "\nUsername : " + str(profile["login"])
                                ret_ += "\nFull Name : " + str(profile["name"])
                                ret_ += "\nType : " + str(profile["type"])
                                if profile["company"] is None:
                                    ret_ += "\nCompany : None"
                                else:
                                    ret_ += "\nCompany : " + str(profile["company"])
                                if profile["blog"] is None:
                                    ret_ += "\nWebsite : None"
                                else:
                                    ret_ += "\nWebsite : " + str(profile["blog"])
                                if profile["location"] is None:
                                    ret_ += "\nLocation : None"
                                else:
                                    ret_ += "\nLocation : " + str(profile["location"])
                                if profile["email"] is None:
                                    ret_ += "\nEmail : None"
                                else:
                                    ret_ += "\nEmail : " + str(profile["email"])
                                if profile["bio"] is None:
                                    ret_ += "\nBiography : None"
                                else:
                                    ret_ += "\nBiography : " + str(profile["bio"])
                                ret_ += "\nPublic Repository : " + format_number(str(profile["public_repos"]))
                                ret_ += "\nPublic Gists : " + format_number(str(profile["public_gists"]))
                                ret_ += "\nFollowers : " + format_number(str(profile["followers"]))
                                ret_ += "\nFollowing : " + format_number(str(profile["following"]))
                                ret_ += "\nCreated At : " + str(profile["created_at"])
                                ret_ += "\nUpdated At : " + str(profile["updated_at"])
                                links = "https://github.com/" + username
                                noobcoder.sendImageWithURL(to, str(profile["avatar_url"]))
                                noobcoder.sendMessage(to, str(ret_))
                            elif "message" in profile:
                                noobcoder.sendMessage(to, "╭─「 Github 」\n╰ Username not found")
                        elif cmd.startswith("githubfollowers "):
                            text = removeCmd("githubfollowers", text)
                            cond = text.split("|")
                            username = cond[0]
                            r = requests.get("https://api.github.com/users/{}/followers".format(username))
                            data = r.text
                            data = json.loads(data)
                            no = 0
                            if len(cond) == 1:
                                if data != [] and "message" not in data:
                                    ret_ = "「 Github Followers 」\n"
                                    for followers in data:
                                        no += 1
                                        ret_ += "\n" + str(no) + ". " + str(followers["login"])
                                    ret_ += "\n\n「 Total {} User 」".format(str(len(data)))
                                    ret_ += "\n\nUsage : GithubFollowers {}|「number」".format(text)
                                    noobcoder.sendMessage(to,ret_)
                                elif "message" in data:
                                    noobcoder.sendMessage(to,"User not found")
                                elif data == []:
                                    noobcoder.sendMessage(to,"User didn't have followers")
                            elif len(cond) == 2:
                                if data != [] and "message" not in data:
                                    if int(cond[1]) <= len(data):
                                        followers = data[int(cond[1])-1]
                                        ret_ = "「 Github Followers 」\n"
                                        ret_ += "\nUsername : " + str(followers["login"])
                                        ret_ += "\n\n「 https://github.com/{} 」".format(followers["login"])
                                        noobcoder.sendImageWithURL(to,str(followers["avatar_url"]))
                                        noobcoder.sendMessage(to,ret_)
                                    else:
                                        noobcoder.sendMessage(to,"Index out of range")
                                elif "message" in data:
                                    noobcoder.sendMessage(to,"User not found")
                                elif data == []:
                                    noobcoder.sendMessage(to,"User didn't have followers")
                        elif cmd.startswith("githubzip "):
                            try:
                                query = removeCmd("githubzip", text)
                                cond = query.split("|")
                                username = str(cond[0])
                                repository = str(cond[1])
                                r = requests.get("https://api.github.com/repos/{}/{}".format(str(username), str(repository)))
                                data = r.text
                                data = json.loads(data)
                                ret_ = "「 Github Zip 」\n"
                                ret_ += "\nName Owner : {}".format(str(data["owner"]["login"]))
                                ret_ += "\nId Owner : {}".format(str(data["owner"]["id"]))
                                ret_ += "\nLink Repo {} : {}".format(str(data["name"]), str(data["clone_url"]))
                                ret_ += "\nId Repo {} : {}".format(str(data["name"]), str(data["id"]))
                                ret_ += "\nProgramming Language : {}".format(str(data["language"]))
                                noobcoder.sendMessage(to, str(ret_))
                                noobcoder.sendImageWithURL(to, str(data["owner"]["avatar_url"]))
                                os.system("git clone {}".format(str(data["clone_url"])))
                                os.system("zip -r {}.zip {}".format(str(repository), str(repository)))
                                noobcoder.sendFile(to, "{}.zip".format(str(repository)))
                                time.sleep(2)
                                os.remove('{}.zip'.format(repository))
                                os.system('rm -r {}'.format(repository))
                            except Exception as error:
                                print("[ ERROR ] {} ~".format(error))
                                noobcoder.sendMessage(to, ' 「 ERROR 」')
                        elif cmd.startswith("githubrepo "):
                            text = removeCmd("githubrepo", text)
                            cond = text.split("|")
                            username = cond[0]
                            r = requests.get("https://api.github.com/users/{}/repos".format(username))
                            data = r.text
                            data = json.loads(data)
                            no = 0
                            if len(cond) == 1:
                                if data != [] and "message" not in data:
                                    ret_ = "「 Github RepoSitory 」\n"
                                    for repo in data:
                                        no += 1
                                        ret_ += "\n" + str(no) + ". " + str(repo["name"])
                                    ret_ += "\n\n「 Total {} User 」".format(str(len(data)))
                                    ret_ += "\n\nUsage : GithubRepo {}|「number」".format(text)
                                    noobcoder.sendMessage(to,ret_)
                                elif "message" in data:
                                    noobcoder.sendMessage(to,"User not found")
                                elif data == []:
                                    noobcoder.sendMessage(to,"User doesn't have any repository")
                            elif len(cond) == 2:
                                if data != [] and "message" not in data:
                                    if int(cond[1]) <= len(data):
                                        repo = data[int(cond[1])-1]
                                        ret_ = "「 Github RepoSitory 」\n"
                                        ret_ += "\nName Repository : " + str(repo["name"])
                                        ret_ += "\nOwner : " + str(repo["owner"]["login"])
                                        if repo["private"] == True:
                                            ret_ += "\nPrivate : Yes"
                                        else:
                                            ret_ += "\nPrivate : No"
                                        if repo["description"] is None:
                                            ret_ += "\nDescription : None"
                                        else:
                                            ret_ += "\nDescription : " + str(repo["description"])
                                        if repo["fork"] == True:
                                            ret_ += "\nFork : Yes"
                                        else:
                                            ret_ += "\nFork : No"
                                        ret_ += "\n URL : " + str(repo["svn_url"])
                                        ret_ += "\nGit URL : " + str(repo["git_url"])
                                        ret_ += "\nSSH URL : " + str(repo["ssh_url"])
                                        ret_ += "\nCreated On : " + str(repo["created_at"])
                                        ret_ += "\nUpdated On : " + str(repo["updated_at"])
                                        ret_ += "\nPushed On : " + str(repo["pushed_at"])
                                        ret_ += "\nSize Repository : ".format(str(repo["size"]))
                                        ret_ += "\nLanguage : " + str(repo["language"])
                                        ret_ += "\nTotal Forked : ".format(str(repo["forks_count"]))
                                        ret_ += "\nTotal Issues : ".format(str(repo["open_issues_count"]))
                                        ret_ += "\n\n「 https://github.com/{} 」".format(str(repo["owner"]["login"]))
                                        ret_ += "\n\nUsage : GithubFollowing {}".format(username)
                                        ret_ += "\nUsage : GithubFollowers {}".format(username)
                                        noobcoder.sendMessage(to, str(ret_))
                                    else:
                                        noobcoder.sendMessage(to,"Index out of range")
                                elif "message" in data:
                                    noobcoder.sendMessage(to,"User not found")
                                elif data == []:
                                    noobcoder.sendMessage(to,"User doesn't have any repository")
                        elif cmd.startswith("githubfollowing "):
                            text = removeCmd("githubfollowing", text)
                            cond = text.split("|")
                            username = cond[0]
                            r = requests.get("https://api.github.com/users/{}/following".format(username))
                            data = r.text
                            data = json.loads(data)
                            no = 0
                            if len(cond) == 1:
                                if data != [] and "message" not in data:
                                    ret_ = "「 Github Following 」\n"
                                    for following in data:
                                        no += 1
                                        ret_ += "\n " + str(no) + ". " + str(following["login"])
                                    ret_ += "\n\n「 Total {} User 」".format(str(len(data)))
                                    ret_ += "\n\nUsage : GithubFollowing {}|「number」".format(text)
                                    noobcoder.sendMessage(to,ret_)
                                elif "message" in data:
                                    noobcoder.sendMessage(to,"User not found")
                                elif data == []:
                                    noobcoder.sendMessage(to,"User didn't following anybody")
                            elif len(cond) == 2:
                                if data != [] and "message" not in data:
                                    if int(cond[1]) <= len(data):
                                        following = data[int(cond[1])-1]
                                        ret_ = "「 Github Following 」\n"
                                        ret_ += "\nUsername : " + str(following["login"])
                                        ret_ += "\n\n「 https://github.com/{} 」".format(following["login"])
                                        noobcoder.sendImageWithURL(to,str(following["avatar_url"]))
                                        noobcoder.sendMessage(to,ret_)
                                    else:
                                        noobcoder.sendMessage(to,"Index out of range")
                                elif "message" in data:
                                    noobcoder.sendMessage(to,"User not found")
                                elif data == []:
                                    noobcoder.sendMessage(to,"User didn't following anybody")
                    if text.lower().startswith("change:me "):
                        anu = text.lower().replace("change:me ","")
                        itu = str(settings["me"])
                        settings["me"] = str(anu).lower()
                        noobcoder.sendMessage(to, "Key me has been change...")
                    if text.lower().startswith("cpurge "):
                        anu = text.lower().replace("cpurge ","")
                        itu = str(settings["jskick1"])
                        settings["jskick1"] = str(anu).lower()
                        sendFooter(to, "Key has been change")
                    if text.lower().startswith("cbypass "):
                        anu = text.lower().replace("cbypass ","")
                        itu = str(settings["jskick"])
                        settings["jskick"] = str(anu).lower()
                        sendFooter(to, "Key has been change")
                    if text.lower().startswith("+ "):
                        if 'MENTION' in msg.contentMetadata.keys()!= None:
                            key = eval(msg.contentMetadata["MENTION"])
                            key1 = key["MENTIONEES"][0]["M"]
                            nama = str(text.split(' ')[1])
                            oa = "u8403c8be65015af7d29c5b69c91021ec"
                            noobcoder.sendMessage(oa, "Addmid {}|{}".format(nama, key1))
                            noobcoder.generateReplyMessage(msg.id)
                            noobcoder.sendReplyMessage(msg.id, to, "Done")
                            noobcoder.sendContact(to, "u8403c8be65015af7d29c5b69c91021ec")
                    if text.lower().startswith("- "):
                        if 'MENTION' in msg.contentMetadata.keys()!= None:
                            key = eval(msg.contentMetadata["MENTION"])
                            key1 = key["MENTIONEES"][0]["M"]
                            oa = "u8403c8be65015af7d29c5b69c91021ec"
                            noobcoder.sendMessage(oa, "Delmid {}".format(key1))
                            noobcoder.generateReplyMessage(msg.id)
                            noobcoder.sendReplyMessage(msg.id, to, "Done")
                    if cmd == "chatbot on":
                        if sender in noobcoderMID or sender in chatbot["admin"]:
                            if to in chatbot["botMute"] or to in chatbot["botOff"]:
                                if to in chatbot["botMute"]:
                                    chatbot["botMute"].remove(to)
                                if to in chatbot["botOff"]:
                                    chatbot["botOff"].remove(to)
                                sendFooter(to, "Switched to normal mode")
                            else:
                                sendFooter(to, "bots is already actived")
                        else:
                            if to in chatbot["botOff"] and to not in chatbot["botMute"]:
                                chatbot["botOff"].remove(to)
                                sendFooter(to, "Switched to normal mode")
                            else:
                                noobcoder.sendMessage(to, "Failed !")
                    if "/ti/g/" in msg.text.lower():
                        if settings["autoJoin"] == True or settings["autoJoin"] == False:
                            link_re = re.compile('(?:line\:\/|line\.me\/R)\/ti\/g\/([a-zA-Z0-9_-]+)?')
                            links = link_re.findall(text)
                            n_links = []
                            for l in links:
                                if l not in n_links:
                                   n_links.append(l)
                            for ticket_id in n_links:
                                group = noobcoder.findGroupByTicket(ticket_id)
                                noobcoder.acceptGroupInvitationByTicket(group.id,ticket_id)

                    for image in images:
                        if msg.text.lower() == image:
                            noobcoder.generateReplyMessage(msg.id)
                            noobcoder.sendReplyImage(msg.id, to, images[image])


                    for sticker in stickers:
                        if text.lower() == sticker:
                            sid = stickers[sticker]["STKID"]
                            spkg = stickers[sticker]["STKPKGID"]
                            sver = stickers[sticker]["STKVER"]
                            try:
                                sendSticker(to, msg._from, sver, spkg, sid)
                            except Exception as e:
                                sendSticker2(to, msg._from, sver, spkg, sid)

                    for contact in contacts:
                        if text.lower() == contact:
                            midd = contacts[contact]["mid"]
                            noobcoder.sendContact(to, midd)

                    for sticker in stickers2:
                        try:
                            if text.lower() == sticker:
                                sid = stickers2[sticker]["STKID"]
                                spkg = stickers2[sticker]["STKPKGID"]
                                sver = stickers2[sticker]["STKVER"]
                                a = noobcoder.shop.getProduct(packageID=int(spkg), language='ID', country='ID')
                                if a.hasAnimation == True:data = {"type": "template","altText": "{} sent a sticker.".format(noobcoder.getProfile().displayName),"template": {"type": "image_carousel","columns": [{"imageUrl": "https://stickershop.line-scdn.net/stickershop/v1/sticker/{}/IOS/sticker_animation@2x.png".format(sid),"size": "full","action": {"type": "uri","uri": "http://line.me/S/sticker/{}".format(spkg)}}]}}
                                else:data = {"type": "template","altText": "{} sent a sticker.".format(noobcoder.getProfile().displayName),"template": {"type": "image_carousel","columns": [{"imageUrl": "https://stickershop.line-scdn.net/stickershop/v1/sticker/{}/IOS/sticker@2x.png".format(sid),"size": "full","action": {"type": "uri","uri": "http://line.me/S/sticker/{}".format(spkg)}}]}}
                                sendTemplate(to,data)
                        except Exception as e:
                            print(e)

                    for sticker in stickers1:
                        if text.lower() == sticker:
                            sid = stickers1[sticker]["STKID"]
                            spkg = stickers1[sticker]["STKPKGID"]
                            data = {
                                "type": "flex",
                                "altText": "KhieWasHere",
                                "contents": {
                                   "type": "bubble",
                                   "hero": {
                                        "type": "image",
                                        "url": "https://stickershop.line-scdn.net/stickershop/v1/sticker/{}/IOS/sticker.png;compress=true".format(sid),
                                        "size": "full",
                                        "aspectRatio": "1:1",
                                        "aspectMode": "fit",
                                        "action": {
                                            "type": "uri",
                                            "uri": "http://line.me/S/sticker/{}".format(spkg)
                                        }
                                    }
                                }
                            }
                            sendTemplate(to, data)
                    for txt in textsadd:
                        if text.lower() == txt:
                            img = textsadd[text.lower()]['CHAT']
                            group = noobcoder.getGroup(to)
                            midMembers = [contact.mid for contact in group.members]
                            data = random.choice(midMembers)
                            noobcoder.sendMessage(to, "{}".format(img))
#=====================================================================
#=====================================================================
                elif msg.contentType == 1:
                    if settings["changePicture"] == True and sender == noobcoderMID:
                        path = noobcoder.downloadObjectMsg(msg_id, saveAs="tmp/pict.bin")
                        settings["changePicture"] = False
                        noobcoder.updateProfilePicture(path)
                        sendFooter(to, "Type: Profile\n • Detail: Change Profile Picture\n • Status: Succes..")
                    if settings["changeCoverProfile"] == True:
                        path = noobcoder.downloadObjectMsg(msg_id)
                        settings["changeCoverProfile"] = False
                        noobcoder.updateProfileCover(path)
                        sendFooter(to, "Type:Profile\n • Detail: Change Home Photos\n • Status: Succes..")
                    if settings['changeProfileVideo']['status'] == True and sender == noobcoderMID:
                        path = noobcoder.downloadObjectMsg(msg_id, saveAs="tmp/pict.bin")
                        if settings['changeProfileVideo']['stage'] == 1:
                            settings['changeProfileVideo']['picture'] = path
                            sendFooter(to, "Silahkan kirimkan video yang ingin anda jadikan profile")
                            settings['changeProfileVideo']['stage'] = 2
                        elif settings['changeProfileVideo']['stage'] == 2:
                            settings['changeProfileVideo']['picture'] = path
                            changeProfileVideo(to)
                            sendFooter(to, "Type: Profile\n • Detail: Change Video Profile\n • Status: Succes..")
                    if settings["addImage"]["status"] == True and sender == noobcoderMID:
                        path = noobcoder.downloadObjectMsg(msg_id)
                        images[settings["addImage"]["name"]] = str(path)
                        f = codecs.open("khie/image.json","w","utf-8")
                        json.dump(images, f, sort_keys=True, indent=4, ensure_ascii=False)
                        sendFooter(to, " 「 Picture 」\n • Detail: Add picture\n • Status: Succes added picture {} in list".format(str(settings["addImage"]["name"])))
                        settings["addImage"]["status"] = False
                        settings["addImage"]["name"] = ""
                    if msg.to in settings["fancy"]["foto1"]:
                        settings["fancy"]["foto1"] = noobcoder.downloadObjectMsg(msg_id)
                        sendFooter(to, "Picture uploaded to fancy picture 1")
                    if msg.to in settings["fancy"]["foto2"]:
                        settings["fancy"]["foto2"] = noobcoder.downloadObjectMsg(msg_id)
                        sendFooter(to, "Picture uploaded to fancy picture 2")
                    if msg.to in settings["fancy"]["foto3"]:
                        settings["fancy"]["foto3"] = noobcoder.downloadObjectMsg(msg_id)
                        sendFooter(to, "Succes added picture to fancy picture")
                        settings["fancy"]["status"] = True
                        sendFooter(to, " 「 Fancy Picture 」\nType: Profile\n • Status: Succes set picture\n • State: ENABLED..\nType: Fancypict off to DISABLED..")
                    if msg.toType == 2:
                        if to in settings["changeGroupPicture"]:
                            path = noobcoder.downloadObjectMsg(msg_id, saveAs="tmp/video.bin")
                            settings["changeGroupPicture"].remove(to)
                            noobcoder.updateGroupPicture(to, path)
                            sendFooter(to, "Type: Group\n • Detail: Update Group Picture\n • Status: Succes..")
                    if msg.toType == 2:
                        if to in settings["changeGroupPicture"]:
                            path = noobcoder.downloadObjectMsg(msg_id, saveAs="tmp/video.bin")
                            settings["changeGroupPicture"].remove(to)
                            noobcoder.updateGroupPicture(to, path)
                            sendFooter(to, "Type: Group\n • Detail: Update Group Picture\n • Status: Succes..")
                elif msg.contentType == 3:
                    if kimak["Addaudio"] == True and sender == noobcoderMID:
                      try:
                          print ("[ AUDIO ] SUCCES SAVE AUDIO")
                          fotoo = "https://obs.line-apps.com/talk/m/download.nhn?oid="+msg_id
                          r = noobcoder.server.getContent(fotoo)
                          if r.status_code == 200:
                              path = os.path.join(os.path.dirname(__file__), 'Alldata/%s.mp3' % kimak["Audio"])
                              with open(path, 'wb') as fp:
                                  shutil.copyfileobj(r.raw, fp)
                              sendFooter(to, "Type: Add Voice\nStatus: Succes add audio : {}".format(str(kimak["Audio"])))
                          kimak["Audio"] = {}
                          kimak["Addaudio"] = False
                      except Exception as e:
                          noobcoder.sendMessage(to, "ERROR\n{}".format(str(e)))
                elif msg.contentType == 2:
                    if settings['changeProfileVideo']['status'] == True and sender == noobcoderMID:
                        path = noobcoder.downloadObjectMsg(msg_id)
                        if settings['changeProfileVideo']['stage'] == 1:
                            settings['changeProfileVideo']['video'] = path
                            sendFooter(to, "Type: Profile\n • Detail: Change Video Profile\n • Status: Send picture ~")
                            settings['changeProfileVideo']['stage'] = 2
                        elif settings['changeProfileVideo']['stage'] == 2:
                            settings['changeProfileVideo']['video'] = path
                            changeProfileVideo(to)
                elif msg.contentType == 7:
                    a = noobcoder.shop.getProduct(packageID=int(msg.contentMetadata['STKPKGID']), language='ID', country='ID')
                    if settings["messageSticker"]["addStatus"] == True and sender == noobcoderMID:
                        name = settings["messageSticker"]["addName"]
                        if name != None and name in settings["messageSticker"]["listSticker"]:
                            settings["messageSticker"]["listSticker"][name] = {
                                "STKID": msg.contentMetadata["STKID"],
                                "STKVER": msg.contentMetadata["STKVER"],
                                "STKPKGID": msg.contentMetadata["STKPKGID"]
                            }
                            sendFooter(msg.to, " 「 Sticker 」\nName: "+a.title+"\nSTKID: "+msg.contentMetadata['STKID']+"\nSTKPKGID: "+msg.contentMetadata['STKPKGID']+"\nSTKVER: "+msg.contentMetadata['STKVER'])
                        settings["messageSticker"]["addStatus"] = False
                        settings["messageSticker"]["addName"] = None
                        settings["messageSticker"]["listSticker"]["addSticker"]["status"] = True
                        settings['messageSticker']['listSticker']['readerSticker']['status'] = True
                        settings['messageSticker']['listSticker']['replySticker']['status'] = True
                    if settings["addSticker"]["status"] == True and sender == noobcoderMID:
                        stickers[settings["addSticker"]["name"]]["STKVER"] = msg.contentMetadata["STKVER"]
                        stickers[settings["addSticker"]["name"]]["STKID"] = msg.contentMetadata["STKID"]
                        stickers[settings["addSticker"]["name"]]["STKPKGID"] = msg.contentMetadata["STKPKGID"]
                        f = codecs.open('khie/sticker.json','w','utf-8')
                        json.dump(stickers, f, sort_keys=True, indent=4, ensure_ascii=False)
                        sendFooter(to, "Succes Add Sticker {}".format(str(settings["addSticker"]["name"])))
                        settings["addSticker"]["status"] = False
                        settings["addSticker"]["name"] = ""
                    if sets["messageStickerz"]["addStatusz"] == True:
                        name = sets["messageStickerz"]["addNamez"]
                        if name != None and name in sets["messageStickerz"]["listStickerz"]:
                            sets["messageStickerz"]["listStickerz"][name] = {
                                "STKID": msg.contentMetadata["STKID"],
                                "STKVER": msg.contentMetadata["STKVER"],
                                "STKPKGID": msg.contentMetadata["STKPKGID"]
                            }
                            sendFooter(to, "Success Added " + name)
                        sets["messageStickerz"]["addStatusz"] = False
                        sets["messageStickerz"]["addNamez"] = None
                    if sets["addStickerz"]["status"] == True:
                        anumu[sets["addStickerz"]["name"]]["STKVER"] = msg.contentMetadata["STKVER"]
                        anumu[sets["addStickerz"]["name"]]["STKID"] = msg.contentMetadata["STKID"]
                        anumu[sets["addStickerz"]["name"]]["STKPKGID"] = msg.contentMetadata["STKPKGID"]
                        f = codecs.open('stickertemp.json','w','utf-8')
                        json.dump(stickers, f, sort_keys=True, indent=4, ensure_ascii=False)
                        sendFooter(to, "Success Added sticker {}".format(str(sets["addStickerz"]["name"])))
                        sets["addStickerz"]["status"] = False
                        sets["addStickerz"]["name"] = ""
                if msg.contentType == 7:
                    if anyun["addTikel"]["status"] == True:
                        stickers2[anyun["addTikel"]["name"]]["STKID"] = msg.contentMetadata["STKID"]
                        stickers2[anyun["addTikel"]["name"]]["STKPKGID"] = msg.contentMetadata["STKPKGID"]
                        stickers2[anyun["addTikel"]["name"]]["STKVER"] = msg.contentMetadata["STKVER"]
                        f = codecs.open('khie/sticker2.json','w','utf-8')
                        json.dump(stickers2, f, sort_keys=True, indent=4, ensure_ascii=False)
                        sendFooter(to, "Success add sticker {}".format(str(anyun["addTikel"]["name"])))
                        anyun["addTikel"]["status"] = False
                        anyun["addTikel"]["name"] = ""
                if msg.contentType == 7:
                    if nissa["addTikel2"]["status"] == True and sender == noobcoderMID:
                        stickers1[nissa["addTikel2"]["name"]]["STKID"] = msg.contentMetadata["STKID"]
                        stickers1[nissa["addTikel2"]["name"]]["STKPKGID"] = msg.contentMetadata["STKPKGID"]
                        f = codecs.open('khie/sticker1.json','w','utf-8')
                        json.dump(stickers1, f, sort_keys=True, indent=4, ensure_ascii=False)
                        sendFooter(to, "Success add sticker {}".format(str(nissa["addTikel2"]["name"])))
                        nissa["addTikel2"]["status"] = False
                        nissa["addTikel2"]["name"] = ""
                if msg.contentType == 7:
                    a = noobcoder.shop.getProduct(packageID=int(msg.contentMetadata['STKPKGID']), language='ID', country='ID')
                    if msg.to in wait["GROUP"]['AR']['S']:
                        if wait["GROUP"]['AR']['S'][msg.to]['AP'] == True:
                            wait["GROUP"]['AR']['S'][msg.to]['Sticker'] = msg.contentMetadata
                            sendFooter(msg.to, " 「 Autorespon Sticker 」\nName: "+a.title+"\nSTKID: "+msg.contentMetadata['STKID']+"\nSTKPKGID: "+msg.contentMetadata['STKPKGID']+"\nSTKVER: "+msg.contentMetadata['STKVER'])
                            wait["GROUP"]['AR']['S'][msg.to]['AP'] = False
                    if msg.to in wait["GROUP"]['WM']['S']:
                        if wait["GROUP"]['WM']['S'][msg.to]['AP'] == True:
                            wait["GROUP"]['WM']['S'][msg.to]['Sticker'] = msg.contentMetadata
                            sendFooter(msg.to, " 「 Welcome Sticker 」\nName: "+a.title+"\nSTKID: "+msg.contentMetadata['STKID']+"\nSTKPKGID: "+msg.contentMetadata['STKPKGID']+"\nSTKVER: "+msg.contentMetadata['STKVER'])
                            wait["GROUP"]['WM']['S'][msg.to]['AP'] = False
                    if msg.to in wait["GROUP"]['LM']['S']:
                        if wait["GROUP"]['LM']['S'][msg.to]['AP'] == True:
                            wait["GROUP"]['LM']['S'][msg.to]['Sticker'] = msg.contentMetadata
                            sendFooter(msg.to, " 「 Leave Sticker 」\nName: "+a.title+"\nSTKID: "+msg.contentMetadata['STKID']+"\nSTKPKGID: "+msg.contentMetadata['STKPKGID']+"\nSTKVER: "+msg.contentMetadata['STKVER'])
                            wait["GROUP"]['LM']['S'][msg.to]['AP'] = False
                elif msg.contentType == 13:
                    if settings["addContact"]["status"] == True:
                        contacts[settings["addContact"]["name"]]["mid"] = msg.contentMetadata["mid"]
                        backupData()
                        sendFooter(to,"Contact successfully added to command {}.".format(str(settings["addContact"]["name"])))
                        settings["addContact"]["status"] = False
                        settings["addContact"]["name"] = ""
                    if undang["invite"] == True:
                        wonge = msg.contentMetadata["mid"]
                        noobcoder.findAndAddContactsByMid(wonge)
                        noobcoder.inviteIntoGroup(to, [wonge])
                        undang["invite"] = False
                elif msg.contentType == 14:
                    if hoho["savefile"] == True and sender == noobcoderMID:
                        try:
                             namafile = hoho["namafile"]
                             noobcoder.downloadObjectMsg(msg_id,saveAs=namafile)
                             hoho["savefile"] = False
                             sendFooter(to, "Successful, the file has been uploaded")
                        except Exception as e:
                         	noobcoder.sendMessage(to, str(e))

        if op.type == 55:
            try:
                Name = noobcoder.getContact(op.param2).mid
                group = noobcoder.getGroup(op.param1).name
                tz = pytz.timezone("Asia/Jakarta")
                timeNow = datetime.now(tz=tz)
                day = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday","Friday", "Saturday"]
                hari = ["Minggu", "Senin", "Selasa", "Rabu", "Kamis", "Jumat", "Sabtu"]
                bulan = ["Januari", "Februari", "Maret", "April", "Mei", "Juni", "Juli", "Agustus", "September", "Oktober", "November", "Desember"]
                hr = timeNow.strftime("%A")
                bln = timeNow.strftime("%m")
                for i in range(len(day)):
                    if hr == day[i]: hasil = hari[i]
                for k in range(0, len(bulan)):
                    if bln == str(k): bln = bulan[k-1]
                readTime = timeNow.strftime('%H.%M')
                readTime2 = hr
                readTime3 = timeNow.strftime('%d') + "-" + bln + "-" + timeNow.strftime('%Y')
                seens["username"][Name] = "was lastseen\nin group ' " + group + " '\nat time " + readTime + " WIB\non " + readTime2 + ", " + readTime3
                seens['find'][op.param2] = True
            except:
                pass
        if op.type == 55:
            if op.param1 in tailah["siderTemp"] and op.param2 not in tailah["siderTemp"][op.param1]:
                tailah["siderTemp"][op.param1].append(op.param2)
                if "@!" in settings["readerPesan"]:
                    contact = noobcoder.getContact(op.param2)
                    pesan = tailah["siderPesan"]
                    data={"type":"flex","altText":"NOOB CODER™","contents":{
  "type": "bubble",
  "body": {
    "type": "box",
    "layout": "vertical",
    "contents": [
      {
        "type": "text",
        "text": "READER MESSAGE",
        "size": "md",
        "color": "{}".format(setbot["text"]),
        "weight": "bold",
        "align": "center"
      },
      {
        "type": "box",
        "layout": "vertical",
        "contents": [
          {
            "type": "spacer"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "separator",
                "color": "{}".format(setbot["separator"]),
                "margin": "md"
              },
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "image",
                    "url": "https://obs.line-scdn.net/{}".format(contact.pictureStatus),
                    "align": "center",
                    "size": "xxl",
                    "aspectMode": "fit",
                    "aspectRatio": "2:1",
                    "action": {
                      "type": "uri",
                      "label": "action",
                      "uri": "line://ti/p/~khiewuzzheree"
                    }
                  },
                  {
                    "type": "separator",
                    "color": "{}".format(setbot["background"]),
                    "margin": "lg"
                  },
                  {
                    "type": "box",
                    "layout": "horizontal",
                    "contents": [
                      {
                        "type": "text",
                        "text": "Hello , {}".format(contact.displayName),
                        "size": "sm",
                        "color": "{}".format(setbot["text"]),
                        "weight": "bold",
                        "flex": 0,
                        "align": "center",
                        "wrap": True
                      }
                    ],
                    "spacing": "sm"
                  },
                  {
                    "type": "box",
                    "layout": "horizontal",
                    "contents": [
                      {
                        "type": "text",
                        "text": "{}".format(pesan),
                        "size": "sm",
                        "color": "{}".format(setbot["text"]),
                        "weight": "bold",
                        "flex": 0,
                        "align": "center",
                        "wrap": True
                      }
                    ],
                    "spacing": "sm"
                  }
                ]
              },
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "separator",
                    "color": "{}".format(setbot["separator"]),
                    "margin": "lg"
                  },
                  {
                    "type": "box",
                    "layout": "horizontal",
                    "contents": [
                      {
                        "type": "box",
                        "layout": "horizontal",
                        "contents": [
                          {
                            "type": "image",
                            "url": "https://i.ibb.co/4mbftvy/IMG-20190809-211441.jpg",
                            "size": "xxs",
                            "align": "start"
                          }
                        ],
                        "width": "25px",
                        "height": "25px",
                        "borderWidth": "2px",
                        "borderColor": "{}".format(setbot["separator"]),
                        "cornerRadius": "xl"
                      },
                      {
                        "type": "box",
                        "layout": "vertical",
                        "spacing": "sm",
                        "contents": [
                          {
                            "type": "text",
                            "text": "FREE SELFBOT",
                            "size": "md",
                            "color": "{}".format(setbot["text"]),
                            "align": "center",
                            "margin": "sm",
                            "action": {
                              "type": "uri",
                              "label": "action",
                              "uri": "https://line.me/ti/p/~" + noobcoder.profile.userid
                            }
                          }
                        ]
                      }
                    ],
                    "margin": "lg"
                  }
                ],
                "spacing": "sm",
                "margin": "md"
              }
            ]
          }
        ],
        "margin": "sm"
      }
    ],
    "borderColor": "{}".format(setbot["separator"]),
    "cornerRadius": "xl",
    "borderWidth": "4px"
  },
  "styles": {
    "body": {
      "backgroundColor": "{}".format(setbot["background"])
    }
  }
}}
                    sendTemplate(op.param1,data)
                
            if op.param1 in read["readPoint"]:
                _name = noobcoder.getContact(op.param2).displayName
                tz = pytz.timezone("Asia/Jakarta")
                timeNow = datetime.now(tz=tz)
                timeHours = datetime.strftime(timeNow," (%H:%M)")
                read["readMember"][op.param1][op.param2] = str(_name) + str(timeHours)
        if op.type == 55:
            print("[ 55 ] NOTIFIED READ MESSAGE")
            try:
                if op.param1 in wait['readPoint']:
                    if op.param2 in wait['ROM1'][op.param1]:
                        wait['setTime'][op.param1][op.param2] = op.createdTime
                    else:
                        wait['ROM1'][op.param1][op.param2] = op.param2
                        wait['setTime'][op.param1][op.param2] = op.createdTime
                        try:
                            if wait['lurkauto'] == True:
                                if len(wait['setTime'][op.param1]) % 5 == 0:
                                    anulurk(op.param1,wait)
                        except:pass
                elif op.param2 in wait['readPoints']:
                    wait['lurkt'][op.param1][op.param2][op.param3] = op.createdTime
                    wait['lurkp'][op.param1][op.param2][op.param3] = op.param2
                else:pass
            except:
                pass
        if op.type == 65:
            if settings["unsendMessage"] == True:
                noobcoder.DetectUnsend(op, settings, chatbot)
        backupData()
    except Exception as error:
        logError(error)
        traceback.print_tb(error.__traceback__)


def run():
    while True:
        try:
#           delExpire()
            ops = noobcoderPoll.singleTrace(count=50)
            if ops != None:
                for op in ops:
                   loop.run_until_complete(noobcoderBot(op))
                   #noobcoderBot(op)
                   noobcoderPoll.setRevision(op.revision)
        except Exception as e:
            logError(e)
            
if __name__ == "__main__":
    run()